getglobal game
getfield -1 ReplicatedStorage
getfield -1 GameFunctions
getfield -1 AddCoins
getfield -1 InvokeServer
pushvalue -2
pushnumber 999999
pcall 2 1 0