getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 HumanoidRootPart
getglobal CFrame
getfield -1 new
pushnumber 2549
pushnumber -5
pushnumber -42
pcall 3 1 0
setfield -3 CFrame