loadstring(game:GetObjects("rbxassetid://995455735")[1].Source)()



