local tbl_main = 
{
     "GodenotGD"
}
game:GetService("ReplicatedStorage").Input.Code:FireServer(unpack(tbl_main))