game:GetService('RunService').RenderStepped:connect(function()
game:GetService("ReplicatedStorage").Events.ActivatedTool:FireServer("ss>lkiu")
end)