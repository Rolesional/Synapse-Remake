local _2019EggHuntHaxx = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local ScrollingFrame = Instance.new("ScrollingFrame")
local SpellBattle = Instance.new("TextButton")
local UIListLayout = Instance.new("UIListLayout")
local FantasticFrontier = Instance.new("TextButton")
local ProjectLazer = Instance.new("TextButton")
local NaturalDisasterSurvival = Instance.new("TextButton")
local TheGreatYolktales = Instance.new("TextButton")
local Labrinyth = Instance.new("TextButton")
local SuperHeroLife3 = Instance.new("TextButton")
local FairyWorld = Instance.new("TextButton")
local SpeedRun4 = Instance.new("TextButton")
local EscapeRoom = Instance.new("TextButton")
local BeeSwarmSimulator = Instance.new("TextButton")
local EpicMinigames = Instance.new("TextButton")
local Hackr = Instance.new("TextButton")
local DroneHeist = Instance.new("TextButton")
local NeighborhoodofRobloxia = Instance.new("TextButton")
local ZombieRush = Instance.new("TextButton")
local InnovationArtcic = Instance.new("TextButton")
local Sharkbite = Instance.new("TextButton")
local Backpacking = Instance.new("TextButton")
local Deathrun = Instance.new("TextButton")
local RobloxBattle = Instance.new("TextButton")
local RobloxPoint = Instance.new("TextButton")
local FreezeTag = Instance.new("TextButton")
local TalesFromTheValley = Instance.new("TextButton")
local Speedland = Instance.new("TextButton")
local Robot64 = Instance.new("TextButton")
local GravityShift = Instance.new("TextButton")
local Titanic = Instance.new("TextButton")
local DragonRage = Instance.new("TextButton")
local DisasterIsland = Instance.new("TextButton")
local Arsenal = Instance.new("TextButton")
local RobloxianHighSchool = Instance.new("TextButton")
local RobloxHighSchool2 = Instance.new("TextButton")
local DanceYourBloxOff = Instance.new("TextButton")
local DesignIt = Instance.new("TextButton")
local PickaSide = Instance.new("TextButton")
local CounterBlox = Instance.new("TextButton")
local WolvesLife3 = Instance.new("TextButton")
local KickOff = Instance.new("TextButton")
local SuperBombSurvival = Instance.new("TextButton")
local TempleTheives = Instance.new("TextButton")
local _000 = Instance.new("TextLabel")
local ERROR = Instance.new("Frame")
local TextLabel_2 = Instance.new("TextLabel")
local EXIT = Instance.new("TextButton")

_2019EggHuntHaxx.Name = "2019EggHuntHaxx"
_2019EggHuntHaxx.Parent = game.CoreGui

Frame.Parent = _2019EggHuntHaxx
Frame.BackgroundColor3 = Color3.new(0.392157, 0.392157, 0.392157)
Frame.BorderColor3 = Color3.new(1, 1, 1)
Frame.BorderSizePixel = 2
Frame.Position = UDim2.new(0.00457665883, 0, 0.201430276, 0)
Frame.Size = UDim2.new(0, 250, 0, 500)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel.BackgroundTransparency = 1
TextLabel.Position = UDim2.new(-0.000659057638, 0, -0.000393341063, 0)
TextLabel.Size = UDim2.new(0, 250, 0, 25)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "ROBLOX 2019 Egg Hunt Haxxx \n By: Bean07 & iTzSadButNotRad"
TextLabel.TextColor3 = Color3.new(1, 1, 1)
TextLabel.TextSize = 14

ScrollingFrame.Parent = Frame
ScrollingFrame.BackgroundColor3 = Color3.new(1, 1, 1)
ScrollingFrame.BackgroundTransparency = 1
ScrollingFrame.Position = UDim2.new(0.00400000019, 0, 0.165999994, 0)
ScrollingFrame.Size = UDim2.new(0, 249, 0, 416)
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 2.20000005, 0)

SpellBattle.Name = "Spell Battle"
SpellBattle.Parent = ScrollingFrame
SpellBattle.BackgroundColor3 = Color3.new(1, 1, 1)
SpellBattle.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
SpellBattle.Size = UDim2.new(0, 200, 0, 25)
SpellBattle.Font = Enum.Font.SourceSans
SpellBattle.Text = "Spell Battle "
SpellBattle.TextColor3 = Color3.new(0, 0, 0)
SpellBattle.TextSize = 14

UIListLayout.Parent = ScrollingFrame
UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
UIListLayout.Padding = UDim.new(0.00100000005, 1)

FantasticFrontier.Name = "Fantastic Frontier"
FantasticFrontier.Parent = ScrollingFrame
FantasticFrontier.BackgroundColor3 = Color3.new(1, 1, 1)
FantasticFrontier.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
FantasticFrontier.Size = UDim2.new(0, 200, 0, 25)
FantasticFrontier.Font = Enum.Font.SourceSans
FantasticFrontier.Text = "Fantastic Frontier"
FantasticFrontier.TextColor3 = Color3.new(0, 0, 0)
FantasticFrontier.TextSize = 14

ProjectLazer.Name = "Project Lazer"
ProjectLazer.Parent = ScrollingFrame
ProjectLazer.BackgroundColor3 = Color3.new(1, 1, 1)
ProjectLazer.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
ProjectLazer.Size = UDim2.new(0, 200, 0, 25)
ProjectLazer.Font = Enum.Font.SourceSans
ProjectLazer.Text = "Project Lazer"
ProjectLazer.TextColor3 = Color3.new(0, 0, 0)
ProjectLazer.TextSize = 14

NaturalDisasterSurvival.Name = "Natural Disaster Survival"
NaturalDisasterSurvival.Parent = ScrollingFrame
NaturalDisasterSurvival.BackgroundColor3 = Color3.new(1, 1, 1)
NaturalDisasterSurvival.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
NaturalDisasterSurvival.Size = UDim2.new(0, 200, 0, 25)
NaturalDisasterSurvival.Font = Enum.Font.SourceSans
NaturalDisasterSurvival.Text = "Natural Disaster Survival"
NaturalDisasterSurvival.TextColor3 = Color3.new(0, 0, 0)
NaturalDisasterSurvival.TextSize = 14

TheGreatYolktales.Name = "The Great Yolktales"
TheGreatYolktales.Parent = ScrollingFrame
TheGreatYolktales.BackgroundColor3 = Color3.new(1, 1, 1)
TheGreatYolktales.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
TheGreatYolktales.Size = UDim2.new(0, 200, 0, 25)
TheGreatYolktales.Font = Enum.Font.SourceSans
TheGreatYolktales.Text = "The Great Yolktales"
TheGreatYolktales.TextColor3 = Color3.new(0, 0, 0)
TheGreatYolktales.TextSize = 14

Labrinyth.Name = "Labrinyth"
Labrinyth.Parent = ScrollingFrame
Labrinyth.BackgroundColor3 = Color3.new(1, 1, 1)
Labrinyth.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
Labrinyth.Size = UDim2.new(0, 200, 0, 25)
Labrinyth.Font = Enum.Font.SourceSans
Labrinyth.Text = "Labrinyth "
Labrinyth.TextColor3 = Color3.new(0, 0, 0)
Labrinyth.TextSize = 14

SuperHeroLife3.Name = "Super Hero Life 3"
SuperHeroLife3.Parent = ScrollingFrame
SuperHeroLife3.BackgroundColor3 = Color3.new(1, 1, 1)
SuperHeroLife3.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
SuperHeroLife3.Size = UDim2.new(0, 200, 0, 25)
SuperHeroLife3.Font = Enum.Font.SourceSans
SuperHeroLife3.Text = "Super Hero Life 3"
SuperHeroLife3.TextColor3 = Color3.new(0, 0, 0)
SuperHeroLife3.TextSize = 14

FairyWorld.Name = "Fairy World"
FairyWorld.Parent = ScrollingFrame
FairyWorld.BackgroundColor3 = Color3.new(1, 1, 1)
FairyWorld.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
FairyWorld.Size = UDim2.new(0, 200, 0, 25)
FairyWorld.Font = Enum.Font.SourceSans
FairyWorld.Text = "Fairy World"
FairyWorld.TextColor3 = Color3.new(0, 0, 0)
FairyWorld.TextSize = 14

SpeedRun4.Name = "Speed Run 4"
SpeedRun4.Parent = ScrollingFrame
SpeedRun4.BackgroundColor3 = Color3.new(1, 1, 1)
SpeedRun4.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
SpeedRun4.Size = UDim2.new(0, 200, 0, 25)
SpeedRun4.Font = Enum.Font.SourceSans
SpeedRun4.Text = "Speed Run 4"
SpeedRun4.TextColor3 = Color3.new(0, 0, 0)
SpeedRun4.TextSize = 14

EscapeRoom.Name = "Escape Room"
EscapeRoom.Parent = ScrollingFrame
EscapeRoom.BackgroundColor3 = Color3.new(1, 1, 1)
EscapeRoom.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
EscapeRoom.Size = UDim2.new(0, 200, 0, 25)
EscapeRoom.Font = Enum.Font.SourceSans
EscapeRoom.Text = "Escape Room"
EscapeRoom.TextColor3 = Color3.new(0, 0, 0)
EscapeRoom.TextSize = 14

BeeSwarmSimulator.Name = "Bee Swarm Simulator"
BeeSwarmSimulator.Parent = ScrollingFrame
BeeSwarmSimulator.BackgroundColor3 = Color3.new(1, 1, 1)
BeeSwarmSimulator.Position = UDim2.new(2.84502769, 0, 0.590515733, 0)
BeeSwarmSimulator.Size = UDim2.new(0, 200, 0, 25)
BeeSwarmSimulator.Font = Enum.Font.SourceSans
BeeSwarmSimulator.Text = "Bee Swarm Simulator"
BeeSwarmSimulator.TextColor3 = Color3.new(0, 0, 0)
BeeSwarmSimulator.TextSize = 14

EpicMinigames.Name = "Epic Minigames"
EpicMinigames.Parent = ScrollingFrame
EpicMinigames.BackgroundColor3 = Color3.new(1, 1, 1)
EpicMinigames.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
EpicMinigames.Size = UDim2.new(0, 200, 0, 25)
EpicMinigames.Font = Enum.Font.SourceSans
EpicMinigames.Text = "Epic Minigames"
EpicMinigames.TextColor3 = Color3.new(0, 0, 0)
EpicMinigames.TextSize = 14

Hackr.Name = "Hackr"
Hackr.Parent = ScrollingFrame
Hackr.BackgroundColor3 = Color3.new(1, 1, 1)
Hackr.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
Hackr.Size = UDim2.new(0, 200, 0, 25)
Hackr.Font = Enum.Font.SourceSans
Hackr.Text = "Hackr"
Hackr.TextColor3 = Color3.new(0, 0, 0)
Hackr.TextSize = 14

DroneHeist.Name = "Drone Heist"
DroneHeist.Parent = ScrollingFrame
DroneHeist.BackgroundColor3 = Color3.new(1, 1, 1)
DroneHeist.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
DroneHeist.Size = UDim2.new(0, 200, 0, 25)
DroneHeist.Font = Enum.Font.SourceSans
DroneHeist.Text = "Drone Heist"
DroneHeist.TextColor3 = Color3.new(0, 0, 0)
DroneHeist.TextSize = 14

NeighborhoodofRobloxia.Name = "Neighborhood ofRobloxia"
NeighborhoodofRobloxia.Parent = ScrollingFrame
NeighborhoodofRobloxia.BackgroundColor3 = Color3.new(1, 1, 1)
NeighborhoodofRobloxia.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
NeighborhoodofRobloxia.Size = UDim2.new(0, 200, 0, 25)
NeighborhoodofRobloxia.Font = Enum.Font.SourceSans
NeighborhoodofRobloxia.Text = "Neighborhood of Robloxia"
NeighborhoodofRobloxia.TextColor3 = Color3.new(0, 0, 0)
NeighborhoodofRobloxia.TextSize = 14

ZombieRush.Name = "Zombie Rush"
ZombieRush.Parent = ScrollingFrame
ZombieRush.BackgroundColor3 = Color3.new(1, 1, 1)
ZombieRush.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
ZombieRush.Size = UDim2.new(0, 200, 0, 25)
ZombieRush.Font = Enum.Font.SourceSans
ZombieRush.Text = "Zombie Rush"
ZombieRush.TextColor3 = Color3.new(0, 0, 0)
ZombieRush.TextSize = 14

InnovationArtcic.Name = "Innovation Artcic"
InnovationArtcic.Parent = ScrollingFrame
InnovationArtcic.BackgroundColor3 = Color3.new(1, 1, 1)
InnovationArtcic.Position = UDim2.new(3.14221644, 0, 0.233243033, 0)
InnovationArtcic.Size = UDim2.new(0, 200, 0, 25)
InnovationArtcic.Font = Enum.Font.SourceSans
InnovationArtcic.Text = "Innovation Artcic"
InnovationArtcic.TextColor3 = Color3.new(0, 0, 0)
InnovationArtcic.TextSize = 14

Sharkbite.Name = "Sharkbite"
Sharkbite.Parent = ScrollingFrame
Sharkbite.BackgroundColor3 = Color3.new(1, 1, 1)
Sharkbite.Position = UDim2.new(3.14221644, 0, 0.233243033, 0)
Sharkbite.Size = UDim2.new(0, 200, 0, 25)
Sharkbite.Font = Enum.Font.SourceSans
Sharkbite.Text = "Sharkbite"
Sharkbite.TextColor3 = Color3.new(0, 0, 0)
Sharkbite.TextSize = 14

Backpacking.Name = "Backpacking"
Backpacking.Parent = ScrollingFrame
Backpacking.BackgroundColor3 = Color3.new(1, 1, 1)
Backpacking.Position = UDim2.new(0.419324875, 0, 0.466879398, 0)
Backpacking.Size = UDim2.new(0, 200, 0, 25)
Backpacking.Font = Enum.Font.SourceSans
Backpacking.Text = "Backpacking"
Backpacking.TextColor3 = Color3.new(0, 0, 0)
Backpacking.TextSize = 14

Deathrun.Name = "Deathrun"
Deathrun.Parent = ScrollingFrame
Deathrun.BackgroundColor3 = Color3.new(1, 1, 1)
Deathrun.Position = UDim2.new(3.64020848, 0, 0.692333937, 0)
Deathrun.Size = UDim2.new(0, 200, 0, 25)
Deathrun.Font = Enum.Font.SourceSans
Deathrun.Text = "Deathrun"
Deathrun.TextColor3 = Color3.new(0, 0, 0)
Deathrun.TextSize = 14

RobloxBattle.Name = "Roblox Battle"
RobloxBattle.Parent = ScrollingFrame
RobloxBattle.BackgroundColor3 = Color3.new(1, 1, 1)
RobloxBattle.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
RobloxBattle.Size = UDim2.new(0, 200, 0, 25)
RobloxBattle.Font = Enum.Font.SourceSans
RobloxBattle.Text = "Roblox Battle"
RobloxBattle.TextColor3 = Color3.new(0, 0, 0)
RobloxBattle.TextSize = 14

RobloxPoint.Name = "Roblox Point"
RobloxPoint.Parent = ScrollingFrame
RobloxPoint.BackgroundColor3 = Color3.new(1, 1, 1)
RobloxPoint.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
RobloxPoint.Size = UDim2.new(0, 200, 0, 25)
RobloxPoint.Font = Enum.Font.SourceSans
RobloxPoint.Text = "Roblox Point"
RobloxPoint.TextColor3 = Color3.new(0, 0, 0)
RobloxPoint.TextSize = 14

FreezeTag.Name = "Freeze Tag"
FreezeTag.Parent = ScrollingFrame
FreezeTag.BackgroundColor3 = Color3.new(1, 1, 1)
FreezeTag.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
FreezeTag.Size = UDim2.new(0, 200, 0, 25)
FreezeTag.Font = Enum.Font.SourceSans
FreezeTag.Text = "Freeze Tag"
FreezeTag.TextColor3 = Color3.new(0, 0, 0)
FreezeTag.TextSize = 14

TalesFromTheValley.Name = "Tales From The Valley"
TalesFromTheValley.Parent = ScrollingFrame
TalesFromTheValley.BackgroundColor3 = Color3.new(1, 1, 1)
TalesFromTheValley.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
TalesFromTheValley.Size = UDim2.new(0, 200, 0, 25)
TalesFromTheValley.Font = Enum.Font.SourceSans
TalesFromTheValley.Text = "Tales From The Valley"
TalesFromTheValley.TextColor3 = Color3.new(0, 0, 0)
TalesFromTheValley.TextSize = 14

Speedland.Name = "Speedland"
Speedland.Parent = ScrollingFrame
Speedland.BackgroundColor3 = Color3.new(1, 1, 1)
Speedland.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
Speedland.Size = UDim2.new(0, 200, 0, 25)
Speedland.Font = Enum.Font.SourceSans
Speedland.Text = "Speedland"
Speedland.TextColor3 = Color3.new(0, 0, 0)
Speedland.TextSize = 14

Robot64.Name = "Robot 64"
Robot64.Parent = ScrollingFrame
Robot64.BackgroundColor3 = Color3.new(1, 1, 1)
Robot64.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
Robot64.Size = UDim2.new(0, 200, 0, 25)
Robot64.Font = Enum.Font.SourceSans
Robot64.Text = "Robot 64"
Robot64.TextColor3 = Color3.new(0, 0, 0)
Robot64.TextSize = 14

GravityShift.Name = "Gravity Shift"
GravityShift.Parent = ScrollingFrame
GravityShift.BackgroundColor3 = Color3.new(1, 1, 1)
GravityShift.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
GravityShift.Size = UDim2.new(0, 200, 0, 25)
GravityShift.Font = Enum.Font.SourceSans
GravityShift.Text = "Gravity Shift"
GravityShift.TextColor3 = Color3.new(0, 0, 0)
GravityShift.TextSize = 14

Titanic.Name = "Titanic"
Titanic.Parent = ScrollingFrame
Titanic.BackgroundColor3 = Color3.new(1, 1, 1)
Titanic.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
Titanic.Size = UDim2.new(0, 200, 0, 25)
Titanic.Font = Enum.Font.SourceSans
Titanic.Text = "Titanic"
Titanic.TextColor3 = Color3.new(0, 0, 0)
Titanic.TextSize = 14

DragonRage.Name = "Dragon Rage"
DragonRage.Parent = ScrollingFrame
DragonRage.BackgroundColor3 = Color3.new(1, 1, 1)
DragonRage.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
DragonRage.Size = UDim2.new(0, 200, 0, 25)
DragonRage.Font = Enum.Font.SourceSans
DragonRage.Text = "Dragon Rage "
DragonRage.TextColor3 = Color3.new(0, 0, 0)
DragonRage.TextSize = 14

DisasterIsland.Name = "Disaster Island"
DisasterIsland.Parent = ScrollingFrame
DisasterIsland.BackgroundColor3 = Color3.new(1, 1, 1)
DisasterIsland.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
DisasterIsland.Size = UDim2.new(0, 200, 0, 25)
DisasterIsland.Font = Enum.Font.SourceSans
DisasterIsland.Text = "Disaster Island"
DisasterIsland.TextColor3 = Color3.new(0, 0, 0)
DisasterIsland.TextSize = 14

Arsenal.Name = "Arsenal"
Arsenal.Parent = ScrollingFrame
Arsenal.BackgroundColor3 = Color3.new(1, 1, 1)
Arsenal.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
Arsenal.Size = UDim2.new(0, 200, 0, 25)
Arsenal.Font = Enum.Font.SourceSans
Arsenal.Text = "Arsenal"
Arsenal.TextColor3 = Color3.new(0, 0, 0)
Arsenal.TextSize = 14

RobloxianHighSchool.Name = "Robloxian High School"
RobloxianHighSchool.Parent = ScrollingFrame
RobloxianHighSchool.BackgroundColor3 = Color3.new(1, 1, 1)
RobloxianHighSchool.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
RobloxianHighSchool.Size = UDim2.new(0, 200, 0, 25)
RobloxianHighSchool.Font = Enum.Font.SourceSans
RobloxianHighSchool.Text = "Robloxian High School"
RobloxianHighSchool.TextColor3 = Color3.new(0, 0, 0)
RobloxianHighSchool.TextSize = 14

RobloxHighSchool2.Name = "Roblox High School 2"
RobloxHighSchool2.Parent = ScrollingFrame
RobloxHighSchool2.BackgroundColor3 = Color3.new(1, 1, 1)
RobloxHighSchool2.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
RobloxHighSchool2.Size = UDim2.new(0, 200, 0, 25)
RobloxHighSchool2.Font = Enum.Font.SourceSans
RobloxHighSchool2.Text = "Roblox High School 2"
RobloxHighSchool2.TextColor3 = Color3.new(0, 0, 0)
RobloxHighSchool2.TextSize = 14

DanceYourBloxOff.Name = "Dance Your Blox Off"
DanceYourBloxOff.Parent = ScrollingFrame
DanceYourBloxOff.BackgroundColor3 = Color3.new(1, 1, 1)
DanceYourBloxOff.Position = UDim2.new(2.56390333, 0, 0.605061173, 0)
DanceYourBloxOff.Size = UDim2.new(0, 200, 0, 25)
DanceYourBloxOff.Font = Enum.Font.SourceSans
DanceYourBloxOff.Text = "Dance Your Blox Off"
DanceYourBloxOff.TextColor3 = Color3.new(0, 0, 0)
DanceYourBloxOff.TextSize = 14

DesignIt.Name = "Design It"
DesignIt.Parent = ScrollingFrame
DesignIt.BackgroundColor3 = Color3.new(1, 1, 1)
DesignIt.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
DesignIt.Size = UDim2.new(0, 200, 0, 25)
DesignIt.Font = Enum.Font.SourceSans
DesignIt.Text = "Design It "
DesignIt.TextColor3 = Color3.new(0, 0, 0)
DesignIt.TextSize = 14

PickaSide.Name = "Pick a Side"
PickaSide.Parent = ScrollingFrame
PickaSide.BackgroundColor3 = Color3.new(1, 1, 1)
PickaSide.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
PickaSide.Size = UDim2.new(0, 200, 0, 25)
PickaSide.Font = Enum.Font.SourceSans
PickaSide.Text = "Pick a Side"
PickaSide.TextColor3 = Color3.new(0, 0, 0)
PickaSide.TextSize = 14

CounterBlox.Name = "Counter Blox"
CounterBlox.Parent = ScrollingFrame
CounterBlox.BackgroundColor3 = Color3.new(1, 1, 1)
CounterBlox.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
CounterBlox.Size = UDim2.new(0, 200, 0, 25)
CounterBlox.Font = Enum.Font.SourceSans
CounterBlox.Text = "Counter Blox"
CounterBlox.TextColor3 = Color3.new(0, 0, 0)
CounterBlox.TextSize = 14

WolvesLife3.Name = "Wolves Life 3"
WolvesLife3.Parent = ScrollingFrame
WolvesLife3.BackgroundColor3 = Color3.new(1, 1, 1)
WolvesLife3.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
WolvesLife3.Size = UDim2.new(0, 200, 0, 25)
WolvesLife3.Font = Enum.Font.SourceSans
WolvesLife3.Text = "Wolves Life 3"
WolvesLife3.TextColor3 = Color3.new(0, 0, 0)
WolvesLife3.TextSize = 14

KickOff.Name = "Kick Off"
KickOff.Parent = ScrollingFrame
KickOff.BackgroundColor3 = Color3.new(1, 1, 1)
KickOff.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
KickOff.Size = UDim2.new(0, 200, 0, 25)
KickOff.Font = Enum.Font.SourceSans
KickOff.Text = "Kick Off"
KickOff.TextColor3 = Color3.new(0, 0, 0)
KickOff.TextSize = 14

SuperBombSurvival.Name = "Super Bomb Survival"
SuperBombSurvival.Parent = ScrollingFrame
SuperBombSurvival.BackgroundColor3 = Color3.new(1, 1, 1)
SuperBombSurvival.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
SuperBombSurvival.Size = UDim2.new(0, 200, 0, 25)
SuperBombSurvival.Font = Enum.Font.SourceSans
SuperBombSurvival.Text = "Super Bomb Survival"
SuperBombSurvival.TextColor3 = Color3.new(0, 0, 0)
SuperBombSurvival.TextSize = 14

TempleTheives.Name = "Temple Theives"
TempleTheives.Parent = ScrollingFrame
TempleTheives.BackgroundColor3 = Color3.new(1, 1, 1)
TempleTheives.Position = UDim2.new(0.423340946, 0, 0.469606668, 0)
TempleTheives.Size = UDim2.new(0, 200, 0, 25)
TempleTheives.Font = Enum.Font.SourceSans
TempleTheives.Text = "Temple Theives"
TempleTheives.TextColor3 = Color3.new(0, 0, 0)
TempleTheives.TextSize = 14

_000.Name = "000"
_000.Parent = Frame
_000.BackgroundColor3 = Color3.new(1, 1, 1)
_000.Position = UDim2.new(0.100000001, 0, 0.0480000004, 0)
_000.Size = UDim2.new(0, 200, 0, 50)
_000.Font = Enum.Font.SourceSans
_000.Text = "Press F9 to see the Console and follow instructions!!!"
_000.TextColor3 = Color3.new(0, 0, 0)
_000.TextSize = 15
_000.TextWrapped = true

ERROR.Name = "ERROR"
ERROR.Parent = _2019EggHuntHaxx
ERROR.BackgroundColor3 = Color3.new(0.392157, 0.392157, 0.392157)
ERROR.BorderColor3 = Color3.new(1, 1, 1)
ERROR.Position = UDim2.new(0.385202169, 0, 0.379022717, 0)
ERROR.Size = UDim2.new(0, 300, 0, 150)
ERROR.Visible = false

TextLabel_2.Parent = ERROR
TextLabel_2.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_2.BackgroundTransparency = 1
TextLabel_2.Position = UDim2.new(0.00130432134, 0, 0.178664953, 0)
TextLabel_2.Size = UDim2.new(0, 300, 0, 123)
TextLabel_2.Font = Enum.Font.SourceSans
TextLabel_2.Text = "WOW!\nBAD NEWS!\nThe script you're looking for HASN'T been added :o\nThis is due to:\n- Super high security\n- Haven't came around to it\nIf you have this script please give it to us! Thank You!"
TextLabel_2.TextColor3 = Color3.new(1, 1, 1)
TextLabel_2.TextSize = 15
TextLabel_2.TextWrapped = true

EXIT.Name = "EXIT"
EXIT.Parent = ERROR
EXIT.BackgroundColor3 = Color3.new(1, 0, 0.0156863)
EXIT.BorderColor3 = Color3.new(1, 1, 1)
EXIT.BorderSizePixel = 0
EXIT.Position = UDim2.new(0.00130432134, 0, 0, 0)
EXIT.Size = UDim2.new(0, 298, 0, 25)
EXIT.Font = Enum.Font.SourceSans
EXIT.Text = "Click me to close this box :o"
EXIT.TextColor3 = Color3.new(1, 1, 1)
EXIT.TextScaled = true
EXIT.TextSize = 25
EXIT.TextStrokeColor3 = Color3.new(0.392157, 0, 0.00392157)
EXIT.TextStrokeTransparency = 0.5
EXIT.TextWrapped = true

--Skriptz
--Error > Exit
EXIT.MouseButton1Click:Connect(function()
	button.Parent.Visible = false
end)

--Arsenal
Arsenal.MouseButton1Click:Connect(function()
if game.PlaceId == 510411669 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(510411669, p)
end
end)

--Backpacking
Backpacking.MouseButton1Click:Connect(function()
if game.PlaceId == 1997193809 then
print("Thank You sotp <3 ")
loadstring(game:HttpGet(('https://hastebin.com/raw/evayicomiz'),true))()
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1997193809, p)
end
end)

--Bee Swarm Simulator
BeeSwarmSimulator.MouseButton1Click:Connect(function()
if game.PlaceId == 1537690962 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1537690962, p)
end
end)

--Counter Blox
CounterBlox.MouseButton1Click:Connect(function()
if game.PlaceId == 301549746 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(301549746, p)
end
end)

--Dance Your Blox Off
DanceYourBloxOff.MouseButton1Click:Connect(function()
if game.PlaceId == 529077492 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(529077492, p)
end
end)

--DeathRun
Deathrun.MouseButton1Click:Connect(function()
if game.PlaceId == 206640076 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(206640076, p)
end
end)

--Design It
DesignIt.MouseButton1Click:Connect(function()
if game.PlaceId == 399595838 then
	print("This will teleport all 3 eggs to YOU, If you don't get all 3 then rejoin and do it agian.")
	print("You will have to equip the 3 items and i think you gotta be top 3 to get the egg")
for i,v in pairs(game.workspace.eggs:GetChildren()) do 
    v.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
    wait(0.1)
end
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(399595838, p)
end
end)

--Disaster Island
DisasterIsland.MouseButton1Click:Connect(function()
if game.PlaceId == 540738476 then
	while wait() do
    game.workspace.Map.Game.Disaster:WaitForChild("Egg")
    if game.workspace.Map.Game.Disaster.Egg.ClassName == "MeshPart" then 
        game.Players.LocalPlayers.Character.HumanoidRootPart.CFrame = game.workspace.Map.Game.Disaster.Egg.CFrame
    elseif game.workspace.Map.Game.Disaster.Egg.ClassName == "Model" then 
            game.Players.LocalPlayers.Character.HumanoidRootPart.CFrame = game.workspace.Map.Game.Disaster.Egg.Main.CFrame
    end
end
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(540738476, p)
end
end)

--Dragon Rage
DragonRage.MouseButton1Click:Connect(function()
if game.PlaceId == 65007797 then
	print("Once there is a Blue + Pink dragon that holds the egg it will teleport to it")
	print("Press WASD or Space to move around to get the egg if it doesn't work first time")
	print("Thank you Bean07 <3")
	local easterdragon;
for _,v in next, workspace:GetDescendants() do 
if v.Name == "Easter" then easterdragon = v.Parent end
end
game:service'RunService'.RenderStepped:Connect(function()
pcall(function()
game.Players.LocalPlayer.Character.HumanoidRootPart.Position = easterdragon.EggLegVisible.Egg.Position
end)
end)
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(65007797, p)
end
end)

--Drone Heist
DroneHeist.MouseButton1Click:Connect(function()
if game.PlaceId == 909386283 then
	print("DONE")
	print("Thank You Bean07 <3")
game.Players.LocalPlayer.Character:MoveTo(workspace["PressurePad (Egg)"].Pad.Position)
workspace["PressurePad (Egg)"].Weight.Position = Vector3.new(-113, 7, -197)
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(909386283, p)
end
end)

--Epic Minigames
EpicMinigames.MouseButton1Click:Connect(function()
if game.PlaceId == 277751860 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(277751860, p)
end
end)

--Escape Room
EscapeRoom.MouseButton1Click:Connect(function()
if game.PlaceId == 707652019 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(707652019, p)
end
end)

--Fairy World
FairyWorld.MouseButton1Click:Connect(function()
if game.PlaceId == 1817078882 then
	print("Thank you Bean07 <3")
	print("Just execute and you get Teleported to the Egg. Super simple")
	game.Players.LocalPlayer.Character.HumanoidRootPart.Position = workspace.Egg.Position
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1817078882, p)
end
end)

--Fantastic Frontier
FantasticFrontier.MouseButton1Click:Connect(function()
if game.PlaceId == 510411669 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(510411669, p)
end
end)

--Freeze Tag
FreezeTag.MouseButton1Click:Connect(function()
if game.PlaceId == 364802243 then
	print("Thank you Bean07 <3")
	print("Make sure it is the Egg Round")
	for _,v in next, workspace.Map:GetChildren()[1].EggSpawns:GetDescendants() do 
game.Players.LocalPlayer.Character:MoveTo(v.Position)
wait(.2)
end
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(364802243, p)
end
end)

--Gravity Shift
GravityShift.MouseButton1Click:Connect(function()
if game.PlaceId == 77899385 then
	print("Thank you Bean07 <3")
	print("Do nothing, Teleports to the egg")
	game.Players.LocalPlayer.Character:MoveTo(workspace.NonCollidable.TheEgg.Position)

else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(77899385, p)
end
end)

--Hackr
Hackr.MouseButton1Click:Connect(function()
if game.PlaceId == 1621830280 then
	print("Thank you Bean07 <3")
print("Just wait for it to collect all the letters")
print("If it doesn't work, Press the button again till it works")
local function tp(...)
game.Players.LocalPlayer.Character:MoveTo(Vector3.new(...))
end

tp(2648, 9, 589)
wait(.2)
tp(3378, 71, -2382)
wait(.2)
tp(-75, -145, -739)
wait(.2)
tp(1337, 26, -1056)
wait(.2)
tp(1604, 261, -287)
wait(.2)
tp(-879, 142, -2050)
wait(.2)

for _,v in next, workspace.Hackables.Matrix:GetDescendants() do 
if v.Name=="Matrix" and v:FindFirstChild"Hitbox"then
game.Players.LocalPlayer.Character:MoveTo(v.Hitbox.Position)
game.ReplicatedStorage.Events.RemoteEvents.ExecuteHack:FireServer(v, "Matrix")
game.ReplicatedStorage.Events.RemoteEvents.StopHack:FireServer()
wait(1)
end
end
wait(1)
game.Players.LocalPlayer.Character.HumanoidRootPart.Position = Vector3.new(3352.86255, 17.0360126, 928.042786)
wait(.2)
game.ReplicatedStorage.Events.RemoteEvents.ExecuteHack:FireServer(workspace.Hackables.MatrixEgg.MatrixEgg, "MatrixEgg")
game.ReplicatedStorage.Events.RemoteEvents.StopHack:FireServer()
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1621830280, p)
end
end)

--Innovation Artic
InnovationArtcic.MouseButton1Click:Connect(function()
if game.PlaceId == 1033860623 then
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace.EGGHITBOX.CFrame
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1033860623, p)
end
end)

--Sharkbite
Sharkbite.MouseButton1Click:Connect(function()
if game.PlaceId == 734159876 then
print("Thank You sotp <3")
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace.EGGHITBOX.CFrame
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(734159876, p)
end
end)

--Kick Off
KickOff.MouseButton1Click:Connect(function()
if game.PlaceId == 318978013 then
	print("Thank You Bean07 <3")
while wait() do
    workspace.MapHolder:GetChildren()[1].BlueGoal.Position = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
    workspace.MapHolder:GetChildren()[1].RedGoal.Position = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
    workspace.SoccerBall.Position = game.Players.LocalPlayer.Character["Right Leg"].Position
    game.Players.LocalPlayer.Character.Humanoid.Jump = true
end
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(318978013, p)
end
end)

--Labrinth
Labrinyth.MouseButton1Click:Connect(function()
if game.PlaceId == 534701013 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(534701013, p)
end
end)

--Natural Disaster Survival
NaturalDisasterSurvival.MouseButton1Click:Connect(function()
if game.PlaceId == 189707 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(189707, p)
end
end)

--Neighborhood of Robloxia
NeighborhoodofRobloxia.MouseButton1Click:Connect(function()
if game.PlaceId == 92898409 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
	
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(92898409, p)
end
end)

--Pick a side
PickaSide.MouseButton1Click:Connect(function()
if game.PlaceId == 663655429 then
	print("wait for it to be dropping eggs")
	print("Thank you Bean07 <3")
while wait() do 
pcall(function()
game.Players.LocalPlayer.Character:MoveTo(workspace.Terrain.Egg.Position)
end)
end
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(663655429, p)
end
end)

--Project Lazer
ProjectLazer.MouseButton1Click:Connect(function()
if game.PlaceId == 3017381882 then
while wait() do 
UrName = game.Players.LocalPlayer.Name
game.Workspace:WaitForChild(UrName)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.workspace.HillPoint.CFrame
end
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(3017381882, p)
end
end)

--ROBLOX Battle
RobloxBattle.MouseButton1Click:Connect(function()
if game.PlaceId == 2061194359 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(2061194359, p)
end
end)

--Roblox High School 2
RobloxHighSchool2.MouseButton1Click:Connect(function()
if game.PlaceId == 2098516465 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(2098516465, p)
end
end)

--ROBLOX Point
RobloxPoint.MouseButton1Click:Connect(function()
if game.PlaceId == 909791583 then
	print("Thank you Bean07 <3")
	print("Just wait for it to finish")
	local function tp(...)
game.Players.LocalPlayer.Character:MoveTo(...)
end
tp(workspace.AnEvent.Keys.Key1.Position)
wait(.5)
tp(workspace.AnEvent.Keys.Key2.Position)
wait(.5)
tp(workspace.AnEvent.Keys.Key3.Position)
wait(.5)
tp(workspace.AnEvent.EggBox.Eguuu.Position)
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(909791583, p)
end
end)

--Robloxian High School
RobloxianHighSchool.MouseButton1Click:Connect(function()
if game.PlaceId == 447452406 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(447452406, p)
end
end)

--ROBOT 64
Robot64.MouseButton1Click:Connect(function()
if game.PlaceId == 1111083356 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1111083356, p)
end
end)

--SPEED RUN 4
SpeedRun4.MouseButton1Click:Connect(function()
if game.PlaceId == 183364845 then
	print("Thank you Bean07 <3")
	print("Simple teleport, Do nothing")
	game.Players.LocalPlayer.Character:MoveTo(workspace.EasterEgg.Position)

else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(183364845, p)
end
end)

--SpeedLand
Speedland.MouseButton1Click:Connect(function()
if game.PlaceId == 909791583 then
	print("Thank you Bean07 <3")
	print("Execute and there you go")
	game.Players.LocalPlayer.Character:MoveTo(workspace.Track["Main Parts"].Finish.Position)
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(909791583, p)
end
end)

--Spell Battle
SpellBattle.MouseButton1Click:Connect(function()
if game.PlaceId == 2171044156 then
game.ReplicatedStorage.RemoteEvent:FireServer("usePotion", "Egg", game.Players.LocalPlayer:GetMouse().Hit)
wait(1)
for _,v in next,workspace:GetDescendants() do 
if v.Name == "egg" then 
v.Position = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
end
end
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(2171044156, p)
end
end)

--Super Bomb Survival
SuperBombSurvival.MouseButton1Click:Connect(function()
if game.PlaceId == 164051105 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(164051105, p)
end
end)

--Super Hero Life 3
SuperHeroLife3.MouseButton1Click:Connect(function()
if game.PlaceId == 2015093382 then
local A_1 = BrickColor.new("Really red")
local Event = game:GetService("ReplicatedStorage").Remotes.Misc.TeamChange2
Event:InvokeServer(A_1)
wait(2.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.workspace.Map.Buildings.Museum.EggThing.Egg.CFrame
wait(0.25)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(1110.88989, 1001.72278, 849.534485) -- Teleport


else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(2015093382, p)
end
end)


--Tales From The Valley
TalesFromTheValley.MouseButton1Click:Connect(function()
if game.PlaceId == 503506257 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(503506257, p)
end
end)

--Temple Theives
TempleTheives.MouseButton1Click:Connect(function()
if game.PlaceId == 1987001769 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1987001769, p)
end
end)

--The Great Yolktales
TheGreatYolktales.MouseButton1Click:Connect(function()
if game.PlaceId == 1441335069 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1441335069, p)
end
end)

--Titanic
Titanic.MouseButton1Click:Connect(function()
if game.PlaceId == 294790062 then
	print("Thank You Bean07 <3 ")
	repeat wait() until workspace.TitanicFolder.SinkingMilestones.EggHuntStart.Value
game.ReplicatedStorage.EggHuntStorageShared['TouchedStartEggHuntQuest']:FireServer()
local function change(...)
game.Players.LocalPlayer.EggHuntValues.MissionStage.Value = ...
game.ReplicatedStorage.EggHuntStorageShared['ChangeMissionStage']:FireServer(...)
end
change(1)
wait(.5)
change(2)
wait(.5)

game.Players.LocalPlayer.EggHuntValues.MissionStage.Value = 10
game.ReplicatedStorage.EggHuntStorageShared['ChangeMissionStage']:FireServer(10, 3, 3)
local tempc = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
for _,v in next, workspace.LuggagePlacement:GetDescendants() do
pcall(function()
game.Players.LocalPlayer.Character.HumanoidRootPart.Position = v.Position
wait(.2)
end)
end
game.Players.LocalPlayer.Character.HumanoidRootPart.Position = tempc
change(50)
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(294790062, p)
end
end)

--Wolves Life 3
WolvesLife3.MouseButton1Click:Connect(function()
if game.PlaceId == 1204965839 then
	print("Thank You Bean07 <3")
	workspace.EggHunt.EggHunt:FireServer("Yes")
workspace.EggHunt.EggHunt:FireServer("EggReward")
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(1204965839, p)
end
end)

--Zombie Rush
ZombieRush.MouseButton1Click:Connect(function()
if game.PlaceId == 286090429 then
	print("We are sorry. This game is a big no no. We cannot make a script. WOW being a noob dev is sad isnt it?")
	ERROR.Visible = true
else
	local ts = game:GetService("TeleportService")
	local p = game:GetService("Players").LocalPlayer
	ts:Teleport(286090429, p)
end
end)