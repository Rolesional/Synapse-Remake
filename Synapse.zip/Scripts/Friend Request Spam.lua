--WARNING IF YOUR FRIENDS IN GAME THEY WILL UNFRIEND YOU
game:GetObjects("rbxassetid://558658046")[1].Parent=game.Players.LocalPlayer.PlayerGui