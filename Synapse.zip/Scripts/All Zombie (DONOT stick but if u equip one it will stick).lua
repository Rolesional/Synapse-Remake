getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Purchased
getfield -1 CombatZombie
pushstring true
setfield -2 Value
emptystack
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Purchased
getfield -1 CombustionZombie
pushstring true
setfield -2 Value
emptystack
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Purchased
getfield -1 GhostZombie
pushstring true
setfield -2 Value
emptystack
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Purchased
getfield -1 LightweightZombie
pushstring true
setfield -2 Value
emptystack
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Purchased
getfield -1 MageZombie
pushstring true
setfield -2 Value
emptystack
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Purchased
getfield -1 SpeedyZombie
pushstring true
setfield -2 Value
emptystack
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Purchased
getfield -1 ToxicZombie
pushstring true
setfield -2 Value
emptystack