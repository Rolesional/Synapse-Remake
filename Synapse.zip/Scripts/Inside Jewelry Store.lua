getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 HumanoidRootPart
getglobal CFrame
getfield -1 new
pushnumber 124
pushnumber 17
pushnumber 1350
pcall 3 1 0
setfield -3 CFrame