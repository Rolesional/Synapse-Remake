local pe = Instance.new("ParticleEmitter",game.Players.LocalPlayer.Character.Torso)
pe.Texture = "http://roblox.com/asset/?id=127476787"
pe.VelocitySpread = 50