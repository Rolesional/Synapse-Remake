getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Humanoid
pushnumber 2000000000
setfield -2 MaxHealth
emptystack
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Humanoid
pushnumber 2000000000
setfield -2 Health
emptystack