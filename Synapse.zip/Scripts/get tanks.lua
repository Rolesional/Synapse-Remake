----------script----------
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 TankChoice
pushnumber TANK NAME HERE!!!!!!!
setfield -2 Value
emptystack
----------tank names---------
T67
PantherM10
M4
Vk3001
Valentine
UC2pdr
Tiger1
T95E6
M60SS
T54
T44