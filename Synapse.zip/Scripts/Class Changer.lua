getglobal game
getfield -1 Players
getfield -1 YourNameHere
getfield -1 CurrentClass
pushstring ClassNameHere
setfield -2 Value
emptystack