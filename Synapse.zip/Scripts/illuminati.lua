pe = Instance.new("ParticleEmitter",game.Players.LocalPlayer.Character.Torso)
pe.Texture = "http://roblox.com/asset/?id=362575925"
pe.VelocitySpread = 50