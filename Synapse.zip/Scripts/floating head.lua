getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Head
getglobal Vector3
getfield -1 new
pushnumber 5
pushnumber 5
pushnumber 5
pcall 3 1 0
setfield -3 Size
emptystack