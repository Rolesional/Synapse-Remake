getglobal game
getfield -1 Workspace
getfield -1 resources
getfield -1 RemoteFunction
getfield -1 InvokeServer
pushvalue -2
pushstring giveItem
pushstring Fake ID Card
pcall 3 0 0