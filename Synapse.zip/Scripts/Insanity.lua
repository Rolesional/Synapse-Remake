getglobal game
getfield -1 ReplicatedStorage
getfield -1 Perks
getfield -1 insanity_perk
getfield -1 InvokeServer
pushvalue -2
pushstring NameHere
pcall 2 1 0
emptystack