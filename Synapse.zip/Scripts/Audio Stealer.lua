local audio = game.Workspace.PLAYERNAMEHERE.Torso.Song.SoundId
print(audio)