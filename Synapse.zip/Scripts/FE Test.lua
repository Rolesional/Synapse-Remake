--[A                                        sshole
if game.Workspace.FilteringEnabled == true then
  print("Filtering Disabled") 
else
  print("Filtering Enabled")
end


