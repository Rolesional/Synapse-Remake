--Made by Drexsploits
loadstring(game:HttpGet("https://pastebin.com/raw/maCqrW0g", true))()
