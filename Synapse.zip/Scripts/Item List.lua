aea - Glass Table (Blue)
afz - Medium Wooden Table
aga - Large Glass Table (Blue)
ahm - Chinese Clothed Table (White)
aim - Square Clothed Table (White)
aja - Large Wood Table
aka - Modern Chair (Blue)
akk - Modern Chair (Black)
akm - Modern Chair (White)
avz - Basic Table
caa - Low quality Counter
cba - Average Counter
cca - High quality Counter
cda - Best quality Counter
cdz - Best of the Best quality Counter
cez - Milkshake Bar
cfz - Hit Drinks Bar
daz - Catzario Statue
dbz - Mightty Statue
dcz - Ultraw Statue
ddz - DerpyMcDerpell Statue
dez - AtomixKing Statue
dfz - Kindoodle Statue
dgz - Twenty-One Pilots (Premium Radio)
dhz - Spanish (Premium Radio)
djz - Rap (Premium Radio)
diz - Cyaim Statue
dkz - Blocksky Statue
dlz - Tiki Smoothie Bar
gbw - Welcome Chalkboard (Sand)
gjz - Reeds
gpk - Tall Lamp (Black)
gpm - Tall Lamp (White)
grz - Food Signs
gsz - Boat
maz - Electronic Radio
mbz - Jazz Radio
mcz - Cheerful Radio
mdz - Electronic Dance DJ Table
raz - Japanese Arch
rbz - Italian Arch
rez - Golden Arch
w2z - TV
w4z - Modern Shelf
woz - Blocksky Painting(editado)