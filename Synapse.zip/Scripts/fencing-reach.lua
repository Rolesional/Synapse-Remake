getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Backpack
getfield -1 Foil
getfield -1 Handle
getglobal Vector3
getfield -1 new
pushnumber 1
pushnumber 1
pushnumber 30
pcall 3 1 0
setfield -3 Size
emptystack