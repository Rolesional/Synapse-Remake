for i , v in pairs(game.Players.LocalPlayer.Gamepasses:GetChildren()) do 
    v.Value = true
end