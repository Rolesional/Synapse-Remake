getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Backpack
getfield -1 GunName
getfield -1 Configuration
getfield -1 Firerate
pushstring 999999999
setfield -2 Value
emptystack