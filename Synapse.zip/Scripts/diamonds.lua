getglobal game
getfield -1 ReplicatedStorage
getfield -1 Give_Quest_Money
getfield -1 FireServer
pushvalue -2
pushnumber 500
pcall 2 1 0
emptystack