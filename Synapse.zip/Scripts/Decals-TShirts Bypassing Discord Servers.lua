--------------------------------------------------------------------------------------------------------------------------
                       Join Bypass Realm's and $pace's discord for bypassed Decals/Audios/T-Shirts
--------------------------------------------------------------------------------------------------------------------------
               


                          
                 Bypass Realm:   https://discord.gg/PYJTdTs < Bypassed Decals < Bypassed Audios < Bypassed Places < Bypassed Shirts

--------------------------------------------------------------------------------------------------------------------------

                 Frog Bypasses:   https://discord.gg/P3jGpmY < Bypassed Decals < Bypassed T-Shirts < Bypassed Audios

--------------------------------------------------------------------------------------------------------------------------

                 K-9 Unit: https://discord.gg/xwF83 < Super Bypassed TShirts [Note: Every TShirt costs 2R$]

--------------------------------------------------------------------------------------------------------------------------