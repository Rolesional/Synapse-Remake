getglobal for Get,Players in ipairs(game
getfield -1 Players
getfield -1 GetPlayers do
pushvalue -2
pcall 1 1 0
getglobal if (Players
getfield -1 Character ~= (nil)) then
pushvalue -2
pcall 1 1 0
getglobal if (Players
pushstring (nil))then
setfield -2 Character~
getglobal Players
getfield -1 leaderstat
getfield -1 Banned
getfield -1 Value = ("true");
pushstring true
pushvalue -2
pcall 1 1 0
getglobal Players
getfield -1 leaderstat
getfield -1 Banned
pushstring (true);
setfield -2 Value
getglobal end
getfield -1 end
pushvalue -2
pcall 0 1 0
getglobal end
getfield -1 end
pushstring end
setfield -2 
getglobal end
getfield -1 end
pushvalue -2
pcall 0 1 0
getglobal end
getfield -1 end
pushstring end
setfield -2 
emptystack