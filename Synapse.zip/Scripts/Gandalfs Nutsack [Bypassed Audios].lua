Gandalfs Nutsack
headassbrokeassmexicanassorangeassdeportedassuglyassantlerassmooseaasslookinassnigga

IDs to Catagorize



Gandalfs Decals


1019032269 Fuck it
1019082391 Fuck Love
1019032758 Fuck Off
1103375877 Squiger


Gandalfs Bass Slips


1102031628 4:30 AM

1096405091 Bruce

1099958422 Bobby Bitch

1102139484 Boyz in tha Hood

1096520271 Drowning & Work

1101584693 D(r)own

1099965075 Eclipse

1102018450 Hits from the Bong

1093461691 Hella Hoes

1096469931 Juicy J Mix

1096448807 Leegit Mix

1100236364 Maan

1103797764 Nigger Remix

1096480266 One Mo Drank

1099969703 Rag Round my Skull

1093277232 Runnin Through the 7th

1102071757 Scrubs

1099921365 Shabazz

1098303290 Ski Mask

1100019722 Sold my Soul to Satan While Waiting in Line at the Mall

1099952550 Still Cold

1109717309 Suicide Pit

1105581968 Tentacion Mix

1102057498 That Time we went to Walmart to Steal Shit before we Met up with TA

1093375132 Thot Detcted

1096671606 Wishy Washy


Modslips Gandalf didnt make


332525646 ???

912553438 ???

755623951 1051510610 1-800-273-8255

570413946 Alexander

357580144 Ayy Mami

941039396 Bad & Boujee

841887920 Bad Habits

1078122235 Bass

903284990 Bleakery/Tentacion

1071867273 Blood Thirsty

294274117 Booty

626012063 Can I Kick it?

611133423 Can of Worms

485766954 Changes

845159787 Courage

888604817 Creature

563041269 Damien Roast

875970015 Dat Stick

296001073 Death Trap

1092129322 Eminem

541322518 Foreign Girl Boomin

819012082 Garettes Revenge

668784674 Gay

302662929 Gay Fam

267689680 Get Low

822028711 Goseple 

836374954 Heartbroken

288945955 Hell Naw

897468827 Hey You

525497453 High for This

848251374 Hitler

659006527 Hurt me

446939492 I Want U

802247078 In Trouble

857595668 Jaw of the Hounds

728004790 Kek

771740748 Killed Kenny

577330529 Kybalion

490300639 Lackin

612277829 Land of the Snakes

1082058686 Lick my Balls

745467096 Like a Bitch

439964096 Lil Wayne

868695625 Look at me

524622995 Luv

462537667 Memoirs of Gorilla

971597071 Nigga?

465532407 Money Longer

260845388 Myself

787343345 Nigga With a Rocket Launcher

707688145 No Filter

476862449 Northside

174676373 Nothing

532408614 Nutshack

1093256848 Paparazzi

886781422 Paris

862546618 Pipe Up

1098281032 PhepMau

852862158 Protect

745360241 Pussy Nigga

223125257 Pyscho

853340094 Pyscho is my Mind

505034293 Rip Roach

673552036 Rucka Rucka Ali

668451618 Ryska Pengar

1092204769 1093720889 Scar

1097280327 Slob on my Knob

852135067 Spaceship

635539828 Star Boy

320809161 Stiff Face

232891151 Super Mario

693208977 Take it Off

262234566 Teeny Weeny String Bikini

196735878 These Racks

567812942 Tired of This

596091465 521933851 Turnt Up

473325209 Ultimate

737329872 Under Water

704506609 Victory Screech

844465416 Waifu

752356970 Waste my Time

1021645802 Whats Going on Niggers 

996185528 Wing Ridden Angel

548067976 Wow

709437403 XO Tour Lif3

832547893 Yeah

1016303717 You a Hoe