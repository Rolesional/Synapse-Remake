--[[
	Credits : 
	TitaniumDeveloper#7719 (Made Autofarm)
	ak47 (https://v3rmillion.net/member.php?action=profile&uid=441593) (Made TP scripts)
	Hawt Dawg (https://v3rmillion.net/member.php?action=profile&uid=234837) (Made Unlock areas script)
	ZFrogger#6467 (Compiled all scripts and modified them to optimize usage)
--]]

local hahabenis = Instance.new("ScreenGui")
local idcaboutthename = Instance.new("Frame")
local youdontneedtoreadthis = Instance.new("TextLabel")
local Gefvf96ve2r59zed5 = Instance.new("TextButton")
local Goxcef20b5y9j4g8959 = Instance.new("TextButton")
local Aflo2ik96jn2b9gr45 = Instance.new("TextButton")
local Accb41f6dv1z46b86t2 = Instance.new("TextButton")
local Arjrenzd2n9zjf5ze6f = Instance.new("TextButton")
hahabenis.Name = "haha benis"
hahabenis.Parent = game.CoreGui
idcaboutthename.Name = "idcaboutthename"
idcaboutthename.Parent = hahabenis
idcaboutthename.Active = true
idcaboutthename.Draggable = true
idcaboutthename.BackgroundColor3 = Color3.new(1, 0, 0)
idcaboutthename.BackgroundTransparency = 0.80000001192093
idcaboutthename.BorderColor3 = Color3.new(0, 0, 0)
idcaboutthename.Position = UDim2.new(0.400473922, 0, 0.297168463, 0)
idcaboutthename.Size = UDim2.new(0, 251, 0, 251)
youdontneedtoreadthis.Name = "youdontneedtoreadthis"
youdontneedtoreadthis.Parent = idcaboutthename
youdontneedtoreadthis.Active = true
youdontneedtoreadthis.BackgroundColor3 = Color3.new(1, 0.784314, 0)
youdontneedtoreadthis.BackgroundTransparency = 0.5
youdontneedtoreadthis.Size = UDim2.new(0, 251, 0, 53)
youdontneedtoreadthis.Font = Enum.Font.SourceSans
youdontneedtoreadthis.Text = "ThisDoesn'tNeedATitleAlsoIt'sDraggable"
youdontneedtoreadthis.TextColor3 = Color3.new(0, 0, 0)
youdontneedtoreadthis.TextScaled = true
youdontneedtoreadthis.TextSize = 15
youdontneedtoreadthis.TextWrapped = true
Gefvf96ve2r59zed5.Name = "Gefvf96ve2r59zed5"
Gefvf96ve2r59zed5.Parent = idcaboutthename
Gefvf96ve2r59zed5.BackgroundColor3 = Color3.new(1, 0, 0.0156863)
Gefvf96ve2r59zed5.BackgroundTransparency = 0.5
Gefvf96ve2r59zed5.BorderColor3 = Color3.new(0, 0, 0)
Gefvf96ve2r59zed5.Position = UDim2.new(0, 0, 0.211155385, 0)
Gefvf96ve2r59zed5.Size = UDim2.new(0, 125, 0, 50)
Gefvf96ve2r59zed5.Font = Enum.Font.SourceSans
Gefvf96ve2r59zed5.Text = "Farm gems : OOF (TP to gem chest/safe/...)"
Gefvf96ve2r59zed5.TextColor3 = Color3.new(0, 0, 0)
Gefvf96ve2r59zed5.TextScaled = true
Gefvf96ve2r59zed5.TextSize = 12
Gefvf96ve2r59zed5.TextWrapped = true
Goxcef20b5y9j4g8959.Name = "Goxcef20b5y9j4g8959"
Goxcef20b5y9j4g8959.Parent = idcaboutthename
Goxcef20b5y9j4g8959.BackgroundColor3 = Color3.new(1, 0, 0.0156863)
Goxcef20b5y9j4g8959.BackgroundTransparency = 0.5
Goxcef20b5y9j4g8959.BorderColor3 = Color3.new(0, 0, 0)
Goxcef20b5y9j4g8959.Position = UDim2.new(0.501992047, 0, 0.211155385, 0)
Goxcef20b5y9j4g8959.Size = UDim2.new(0, 125, 0, 50)
Goxcef20b5y9j4g8959.Font = Enum.Font.SourceSans
Goxcef20b5y9j4g8959.Text = "Farm gold : OOF (TP to gold chest/stack/...)"
Goxcef20b5y9j4g8959.TextColor3 = Color3.new(0, 0, 0)
Goxcef20b5y9j4g8959.TextScaled = true
Goxcef20b5y9j4g8959.TextSize = 12
Goxcef20b5y9j4g8959.TextWrapped = true
Aflo2ik96jn2b9gr45.Name = "Aflo2ik96jn2b9gr45"
Aflo2ik96jn2b9gr45.Parent = idcaboutthename
Aflo2ik96jn2b9gr45.BackgroundColor3 = Color3.new(0.933333, 0, 1)
Aflo2ik96jn2b9gr45.BackgroundTransparency = 0.5
Aflo2ik96jn2b9gr45.BorderColor3 = Color3.new(0, 0, 0)
Aflo2ik96jn2b9gr45.Position = UDim2.new(0, 0, 0.410358578, 0)
Aflo2ik96jn2b9gr45.Size = UDim2.new(0, 251, 0, 49)
Aflo2ik96jn2b9gr45.Font = Enum.Font.SourceSans
Aflo2ik96jn2b9gr45.Text = "Autofarm : OOF"
Aflo2ik96jn2b9gr45.TextColor3 = Color3.new(0, 0, 0)
Aflo2ik96jn2b9gr45.TextScaled = true
Aflo2ik96jn2b9gr45.TextSize = 12
Aflo2ik96jn2b9gr45.TextWrapped = true
Accb41f6dv1z46b86t2.Name = "Accb41f6dv1z46b86t2"
Accb41f6dv1z46b86t2.Parent = idcaboutthename
Accb41f6dv1z46b86t2.BackgroundColor3 = Color3.new(0.0823529, 0, 1)
Accb41f6dv1z46b86t2.BackgroundTransparency = 0.5
Accb41f6dv1z46b86t2.BorderColor3 = Color3.new(0, 0, 0)
Accb41f6dv1z46b86t2.Position = UDim2.new(0, 0, 0.605577707, 0)
Accb41f6dv1z46b86t2.Size = UDim2.new(0, 251, 0, 49)
Accb41f6dv1z46b86t2.Font = Enum.Font.SourceSans
Accb41f6dv1z46b86t2.Text = "Take Cooldown Chests (Idk the names)"
Accb41f6dv1z46b86t2.TextColor3 = Color3.new(0, 0, 0)
Accb41f6dv1z46b86t2.TextScaled = true
Accb41f6dv1z46b86t2.TextSize = 12
Accb41f6dv1z46b86t2.TextWrapped = true
Arjrenzd2n9zjf5ze6f.Name = "Arjrenzd2n9zjf5ze6f"
Arjrenzd2n9zjf5ze6f.Parent = idcaboutthename
Arjrenzd2n9zjf5ze6f.BackgroundColor3 = Color3.new(0, 0.984314, 1)
Arjrenzd2n9zjf5ze6f.BackgroundTransparency = 0.5
Arjrenzd2n9zjf5ze6f.BorderColor3 = Color3.new(0, 0, 0)
Arjrenzd2n9zjf5ze6f.Position = UDim2.new(0, 0, 0.800796866, 0)
Arjrenzd2n9zjf5ze6f.Size = UDim2.new(0, 251, 0, 49)
Arjrenzd2n9zjf5ze6f.Font = Enum.Font.SourceSans
Arjrenzd2n9zjf5ze6f.Text = "Unlock All Areas"
Arjrenzd2n9zjf5ze6f.TextColor3 = Color3.new(0, 0, 0)
Arjrenzd2n9zjf5ze6f.TextScaled = true
Arjrenzd2n9zjf5ze6f.TextSize = 12
Arjrenzd2n9zjf5ze6f.TextWrapped = true
Arjrenzd2n9zjf5ze6f.MouseButton1Down:connect(function()
for _,FloatingIsland in pairs (workspace.FloatingIslands:GetChildren()) do
wait(1)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(FloatingIsland.Collision.Position)
end
end)
Accb41f6dv1z46b86t2.MouseButton1Down:connect(function()
for _,v in pairs(game:GetDescendants()) do 
if string.find(v.Name, "Chest Collect ") and v:IsA("Model") and v:FindFirstChild("Root") then 
v.Root.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
end
end
end)
Aflo2ik96jn2b9gr45.MouseButton1Down:connect(function()
if _G.autofarm then
Aflo2ik96jn2b9gr45.Text = "Autofarm : OOF"
_G.autofarm = false
else
Aflo2ik96jn2b9gr45.Text = "Autofarm : OON"
_G.autofarm = true
end
local RemotesTable = {}
local TRUEREMOTE
for _,Remote in pairs (game.ReplicatedStorage:GetChildren()) do
if Remote:IsA("RemoteEvent") or Remote:IsA("RemoteFunction") and Remote.Name ~= "Network" then
Remote.Name = #RemotesTable + 1
RemotesTable[#RemotesTable + 1] = Remote
end
end
spawn(function()
while _G.autofarm do
wait()
if TRUEREMOTE then
TRUEREMOTE:FireServer("BlowBubble")
TRUEREMOTE:FireServer("SellBubble", "Sell")
TRUEREMOTE:FireServer("SellBubble", "TwilightSell")
TRUEREMOTE:FireServer("ClaimAchievement", 1)
TRUEREMOTE:FireServer("ClaimAchievement", 2)
TRUEREMOTE:FireServer("ClaimAchievement", 3)
TRUEREMOTE:FireServer("ClaimAchievement", 4)
end
end
end)
Detect = {
RemoteEvent = true;
RemoteFunction = true;
}
local MT = getrawmetatable(game)
if setreadonly then 
setreadonly(MT,false)
end
if make_writeable then 
make_writeable(MT)
end
local oldNamecall = MT.__namecall
MT.__namecall = function(instance,...)
local args = {...}
local Check = args[#args]
if (Check=="FireServer" or Check=="Fire" or Check=="InvokeServer" or Check=="Invoke") and Detect[instance.ClassName] then
if args[1] == "BlowBubble" then
TRUEREMOTE = instance
return {oldNamecall(instance,...)} 
end
end
return oldNamecall(instance,...)
end
end)
Goxcef20b5y9j4g8959.MouseButton1Down:connect(function()
if _G.gold then
Goxcef20b5y9j4g8959.Text = "Farm gold : OOF (TP to gold chest/safe/...)"
_G.gold = false
else
Gefvf96ve2r59zed5.Text = "Farm gems : OOF (TP to gem chest/safe/...)"
_G.gem = false
Goxcef20b5y9j4g8959.Text = "Farm gold : OON (TP to gold chest/safe/...)"
_G.gold = true
end
while _G.gold do
wait()
if workspace.Pickups:FindFirstChild("Coin") then 
for _,v in pairs(workspace.Pickups["Coin"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Cash Stack") then 
for _,v in pairs(workspace.Pickups["Cash Stack"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Money Bag") then 
for _,v in pairs(workspace.Pickups["Money Bag"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Wood Chest") then 
for _,v in pairs(workspace.Pickups["Wood Chest"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Silver Chest") then 
for _,v in pairs(workspace.Pickups["Silver Chest"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Gold Chest") then 
for _,v in pairs(workspace.Pickups["Gold Chest"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Mythical Chest") then 
for _,v in pairs(workspace.Pickups["Mythical Chest"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
end
end)
Gefvf96ve2r59zed5.MouseButton1Down:connect(function()
if _G.gem then
Gefvf96ve2r59zed5.Text = "Farm gems : OOF (TP to gem chest/safe/...)"
_G.gem = false
else
Goxcef20b5y9j4g8959.Text = "Farm gold : OOF (TP to gold chest/safe/...)"
_G.gold = false
Gefvf96ve2r59zed5.Text = "Farm gems : OON (TP to gem chest/safe/...)"
_G.gem = true
end
while _G.gem do
wait()
if workspace.Pickups:FindFirstChild("Gem") then 
for _,v in pairs(workspace.Pickups["Gem"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Gem Box") then 
for _,v in pairs(workspace.Pickups["Gem Box"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Small Gem Chest") then 
for _,v in pairs(workspace.Pickups["Small Gem Chest"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Gem Safe") then 
for _,v in pairs(workspace.Pickups["Gem Safe"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
if workspace.Pickups:FindFirstChild("Gem Chest") then 
for _,v in pairs(workspace.Pickups["Gem Chest"]:GetDescendants()) do
if v.Name == "Root" then
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
end
end
end
end
end)
while true do
wait(10)
local Explosion = Instance.new("Explosion", game.Workspace)
Explosion.Position = Vector3.new(-193, 46, -345.25)
Explosion.BlastPressure = 1
Explosion.DestroyJointRadiusPercent = 0.5
Explosion.ExplosionType = "Craters"
Explosion.BlastRadius = 50
Explosion.Hit:connect(function(Part, Distance)
Part:Destroy()
end)
end