local plrName = game.Players.LocalPlayer.Name
local A_1 = plrName
local Event = game:GetService("ReplicatedStorage").SaleItem.AC
Event:InvokeServer(A_1)
local NewLevel = 248
local Event = game:GetService("ReplicatedStorage").SaleItem.AL
Event:InvokeServer(NewLevel)
local Kills = 13419
local Event = game:GetService("ReplicatedStorage").SaleItem.AK
Event:InvokeServer(Kills)
local Gold = 999999999999
local Event = game:GetService("ReplicatedStorage").SaleItem.AG
Event:InvokeServer(Gold)
local Shadows = 999999999999
local Event = game:GetService("ReplicatedStorage").SaleItem.AS
Event:InvokeServer(Shadows)