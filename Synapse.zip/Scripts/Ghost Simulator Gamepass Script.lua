game.Players.LocalPlayer.Stats.AppliedPasses.DoubleTokens.Value = true
game.Players.LocalPlayer.Stats.AppliedPasses.Agility.Value = true
game.Players.LocalPlayer.Stats.AppliedPasses.DoubleRange.Value = true
game.Players.LocalPlayer.Stats.AppliedPasses.MorePetStorage.Value = true
game.Players.LocalPlayer.Stats.AppliedPasses.MorePetSlots.Value = true
game.Players.LocalPlayer.Stats.AppliedPasses.DoubleGems.Value = true
game.Players.LocalPlayer.Stats.AppliedPasses.DoubleLuck.Value = true
game.Players.LocalPlayer.Stats.AppliedPasses.QuickUnbox.Value = true