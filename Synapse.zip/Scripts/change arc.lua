getglobal  game
getfield -1 ReplicatedStorage
getfield -1 Connections
getfield -1 StatConnections
getfield -1 SetStat
getfield -1 FireServer
pushvalue -2
pushstring Arc
pushstring Arc you want here
pcall 3 1 0