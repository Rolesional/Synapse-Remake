getglobal game
getfield -1 GetService
pushvalue -2
pushstring Workspace
pcall 2 1 0
getfield -1 ServerStats
getfield -1 ExpScale
pushnumber 9999
setfield -2 Value
emptystack