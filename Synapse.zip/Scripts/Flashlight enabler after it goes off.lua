getglobal while wait(000
getfield -1 1) do
getglobal game
getfield -1 Workspace
getfield -1 light
getfield -1 PointLight
pushboolean true
setfield -2 Enabled
getglobal end