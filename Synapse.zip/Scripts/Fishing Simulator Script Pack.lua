Fishing Simulator


--INF Money Copy Below:

game.ReplicatedStorage.ADDCASH:FireServer(amount)


- Change/Set Rank:

game.ReplicatedStorage.SetRank:FireServer("What rank you want.")


- Add Catches

game.ReplicatedStorage.DropFishAddCT:FireServer(1000000)

- Add InBucket

game.ReplicatedStorage.DropFishAddIB:FireServer(1000000)