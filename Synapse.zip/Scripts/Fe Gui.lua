-- Objects

local FEScriptHub = Instance.new("ScreenGui")
local MainFrame = Instance.new("Frame")
local LabelClose = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local Close = Instance.new("TextButton")
local Scripts = Instance.new("ScrollingFrame")
local chatspam = Instance.new("TextButton")
local clicktp = Instance.new("TextButton")
local FEAnimations = Instance.new("TextButton")
local minekraftfan = Instance.new("TextButton")
local bloks = Instance.new("TextButton")
local btools = Instance.new("TextButton")
local giantassaxe = Instance.new("TextButton")
local godxd = Instance.new("TextButton")
local grab = Instance.new("TextButton")
local raep = Instance.new("TextButton")
local kill = Instance.new("TextButton")
local topqueque = Instance.new("TextButton")
local runingoutofideas = Instance.new("TextButton")
local oof = Instance.new("TextButton")
local whydoustillreadthis = Instance.new("TextButton")
local Frame = Instance.new("Frame")
local TextBox69 = Instance.new("TextBox")
local TextButton = Instance.new("TextButton")
local TextButton_2 = Instance.new("TextButton")
local kys = Instance.new("TextButton")
local feadmin = Instance.new("TextButton")
local shutdown = Instance.new("TextButton")
local bomb = Instance.new("TextButton")
local spamarrest = Instance.new("TextButton")
local killaura = Instance.new("TextButton")
local tpgunsmelees = Instance.new("TextButton")
local tpto = Instance.new("TextButton")
local bring = Instance.new("TextButton")
local torturebaby = Instance.new("TextButton")
local explode = Instance.new("TextButton")
local frspam = Instance.new("TextButton")
local isis = Instance.new("TextButton")
local botesp = Instance.new("TextButton")
local push = Instance.new("TextButton")
local LimbMerger = Instance.new("TextButton")
local hatspin = Instance.new("TextButton")
local Fling = Instance.new("TextButton")
local Blackhole = Instance.new("TextButton")
local earraep = Instance.new("TextButton")
local lol = Instance.new("Frame")
local TextLabel2 = Instance.new("TextLabel")
local sadas = Instance.new("TextLabel")

-- Properties

if game.PlaceId == "843495510,843468296" then
FEScriptHub.Parent = game.Players.LocalPlayer.PlayerGui
FEScriptHub.ResetOnSpawn = false
else
FEScriptHub.Parent = game.CoreGui
end

if game.Players.LocalPlayer.Name == "GoingT400,ILikeToHaveDock" then
	game.Players.LocalPlayer:Kick("BEGONE SCRIPT STEALER")
end

lol.Name = "lol"
lol.Parent = FEScriptHub
lol.Active = true
lol.BackgroundColor3 = Color3.new(0.156863, 0.156863, 0.156863)
lol.BackgroundTransparency = 1
lol.Draggable = false
lol.Selectable = false
lol.Position = UDim2.new(0, 605, 0, 245)
lol.Size = UDim2.new(0, 151, 0, 151)
wait(0.1)
lol.BackgroundTransparency = 0.9
wait(0.1)
lol.BackgroundTransparency = 0.8
wait(0.1)
lol.BackgroundTransparency = 0.7
wait(0.1)
lol.BackgroundTransparency = 0.6
wait(0.1)
lol.BackgroundTransparency = 0.5
wait(0.1)
lol.BackgroundTransparency = 0.4
wait(0.1)
lol.BackgroundTransparency = 0.3
wait(0.1)
lol.BackgroundTransparency = 0.2
wait(0.1)
lol.BackgroundTransparency = 0.1
wait(0.1)
lol.BackgroundTransparency = 0

TextLabel2.Parent = lol
TextLabel2.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel2.BackgroundTransparency = 1
TextLabel2.Size = UDim2.new(0, 151, 0, 151)
TextLabel2.Font = Enum.Font.SourceSans
TextLabel2.Text = ""
TextLabel2.TextColor3 = Color3.new(1, 1, 1)
TextLabel2.TextScaled = true
TextLabel2.TextSize = 14
TextLabel2.TextWrapped = true
wait(0.1)
TextLabel2.Text = "F"
wait(0.1)
TextLabel2.Text = "FE"
wait(0.1)
TextLabel2.Text = "FE S"
wait(0.1)
TextLabel2.Text = "FE Sc"
wait(0.1)
TextLabel2.Text = "FE Scr"
wait(0.1)
TextLabel2.Text = "FE Scri"
wait(0.1)
TextLabel2.Text = "FE Scrip"
wait(0.1)
TextLabel2.Text = "FE Script"
wait(0.1)
TextLabel2.Text = "FE Script H"
wait(0.1)
TextLabel2.Text = "FE Script Hu"
wait(0.1)
TextLabel2.Text = "FE Script Hub"
sadas.Name = "sadas"
sadas.Parent = lol
sadas.BackgroundColor3 = Color3.new(1, 1, 1)
sadas.BackgroundTransparency = 1
sadas.Position = UDim2.new(0, -24, 0, 151)
sadas.Size = UDim2.new(0, 200, 0, 50)
sadas.Font = Enum.Font.SourceSans
sadas.Text = "Loading."
sadas.TextColor3 = Color3.new(1, 1, 1)
sadas.TextScaled = true
sadas.TextSize = 14
sadas.TextWrapped = true
wait(0.5)
sadas.Text = "Loading.."
wait(0.5)
sadas.Text = "Loading..."
wait(0.5)
sadas.Text = "Loading."
wait(0.5)
sadas.Text = "Loading.."
wait(0.5)
sadas.Text = "Loading..."
wait(0.5)
sadas.Text = "Loading."
wait(0.5)
sadas.Text = "Loading.."
wait(0.5)
sadas.Text = "Loading..."
wait( )
sadas.Text = "Loaded"
wait( )
TextLabel2.Text = "FE Script Hu"
wait(0.1)
TextLabel2.Text = "FE Script H"
wait(0.1)
TextLabel2.Text = "FE Script"
wait(0.1)
TextLabel2.Text = "FE Scrip"
wait(0.1)
TextLabel2.Text = "FE Scri"
wait(0.1)
TextLabel2.Text = "FE Scr"
wait(0.1)
TextLabel2.Text = "FE Sc"
wait(0.1)
TextLabel2.Text = "FE S"
wait(0.1)
TextLabel2.Text = "FE"
wait(0.1)
TextLabel2.Text = "F"
wait(0.1)
TextLabel2.Text = ""
wait(0.1)
lol.BackgroundTransparency = 0
wait(0.1)
lol.BackgroundTransparency = 0.1
wait(0.1)
lol.BackgroundTransparency = 0.2
wait(0.1)
lol.BackgroundTransparency = 0.3
wait(0.1)
lol.BackgroundTransparency = 0.4
wait(0.1)
lol.BackgroundTransparency = 0.5
wait(0.1)
lol.BackgroundTransparency = 0.6
wait(0.1)
lol.BackgroundTransparency = 0.7
wait(0.1)
lol.BackgroundTransparency = 0.8
wait(0.1)
lol.BackgroundTransparency = 0.9
wait(0.1)
lol.BackgroundTransparency = 1
wait(0.1)
lol:Destroy()
wait(0.1)

MainFrame.Name = "MainFrame"
MainFrame.Parent = FEScriptHub
MainFrame.Active = true
MainFrame.BackgroundColor3 = Color3.new(1, 1, 1)
MainFrame.BackgroundTransparency = 1
MainFrame.Draggable = true
MainFrame.Selectable = true
MainFrame.Size = UDim2.new(0, 200, 0, 31)

LabelClose.Name = "Label/Close"
LabelClose.Parent = MainFrame
LabelClose.BackgroundColor3 = Color3.new(1, 1, 1)
LabelClose.BackgroundTransparency = 1
LabelClose.Size = UDim2.new(0, 100, 0, 100)

TextLabel.Parent = LabelClose
TextLabel.BackgroundColor3 = Color3.new(0, 0, 0)
TextLabel.BackgroundTransparency = 0.20000000298023
TextLabel.Size = UDim2.new(0, 200, 0, 31)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.FontSize = Enum.FontSize.Size14
TextLabel.Text = "FE Script Hub"
TextLabel.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
TextLabel.TextScaled = true
TextLabel.TextSize = 14
TextLabel.TextWrapped = true

Close.Name = "Close"
Close.Parent = LabelClose
Close.BackgroundColor3 = Color3.new(0, 0, 0)
Close.BackgroundTransparency = 1
Close.Position = UDim2.new(0, 171, 0, 0)
Close.Size = UDim2.new(0, 29, 0, 30)
Close.Font = Enum.Font.SourceSans
Close.FontSize = Enum.FontSize.Size14
Close.Text = "+"
Close.TextColor3 = Color3.new(1, 1, 1)
Close.TextScaled = true
Close.TextSize = 14
Close.TextWrapped = true

Close.MouseButton1Down:connect(function()
    if Scripts.Visible == false then
        Scripts.Visible = true
		Close.Text = "-"
    else
        Scripts.Visible = false
		Close.Text = "+"
    end
end)

Scripts.Name = "Scripts"
Scripts.Parent = MainFrame
Scripts.BackgroundColor3 = Color3.new(0, 0, 0)
Scripts.BackgroundTransparency = 0.20000000298023
Scripts.Position = UDim2.new(0, 0, 0, 29)
Scripts.Size = UDim2.new(0, 200, 0, 150)
Scripts.Visible = false
Scripts.CanvasSize = UDim2.new(0, 0, 56.7, 0)

chatspam.Name = "chatspam"
chatspam.Parent = Scripts
chatspam.BackgroundColor3 = Color3.new(0, 0, 0)
chatspam.BackgroundTransparency = 0.5
chatspam.Size = UDim2.new(0, 200, 0, 50)
chatspam.Font = Enum.Font.SourceSans
chatspam.FontSize = Enum.FontSize.Size14
chatspam.Text = "Chat Spam"
chatspam.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
chatspam.TextSize = 14

clicktp.Name = "clicktp"
clicktp.Parent = Scripts
clicktp.BackgroundColor3 = Color3.new(0, 0, 0)
clicktp.BackgroundTransparency = 0.5
clicktp.Position = UDim2.new(0, 0, 0, 49)
clicktp.Size = UDim2.new(0, 200, 0, 50)
clicktp.Font = Enum.Font.SourceSans
clicktp.FontSize = Enum.FontSize.Size14
clicktp.Text = "FE Click TP Tool"
clicktp.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
clicktp.TextSize = 14

clicktp.MouseButton1Down:connect(function()
local Player = game.Players.LocalPlayer
local Mouse = Player:GetMouse()
local UserInputService = game:GetService('UserInputService')

local HoldingControl = false

Mouse.Button1Down:connect(function()
if HoldingControl then
Player.Character:MoveTo(Mouse.Hit.p)
end
end)

UserInputService.InputBegan:connect(function(Input, Processed)
if Input.UserInputType == Enum.UserInputType.Keyboard then
if Input.KeyCode == Enum.KeyCode.LeftControl then
HoldingControl = true
elseif Input.KeyCode == Enum.KeyCode.RightControl then
HoldingControl = true 
end
end
end)

UserInputService.InputEnded:connect(function(Input, Processed)
if Input.UserInputType == Enum.UserInputType.Keyboard then
if Input.KeyCode == Enum.KeyCode.LeftControl then
HoldingControl = false
elseif Input.KeyCode == Enum.KeyCode.RightControl then
HoldingControl = false
end
end
end)
end)

FEAnimations.Name = "FEAnimations"
FEAnimations.Parent = Scripts
FEAnimations.BackgroundColor3 = Color3.new(0, 0, 0)
FEAnimations.BackgroundTransparency = 0.5
FEAnimations.Position = UDim2.new(0, 0, 0, 98)
FEAnimations.Size = UDim2.new(0, 200, 0, 50)
FEAnimations.Font = Enum.Font.SourceSans
FEAnimations.FontSize = Enum.FontSize.Size14
FEAnimations.Text = "FE Animations GUI"
FEAnimations.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
FEAnimations.TextSize = 14

FEAnimations.MouseButton1Down:connect(function()
-- Energize by illremember, fe animations
-- DO NOT COPY AND CLAIM AS OWN, if you are using some of the script for your own, credit is highly appreciated!
-- Thank you, and enjoy.

-- Objects

game.StarterGui:SetCore("SendNotification", {Title = "Energize Loaded:";Text = "Credits to illremember";Icon = "rbxassetid://920542878";Duration = 2})

local Energize = Instance.new("ScreenGui") -- The actual GUI
local SideFrame = Instance.new("Frame") -- Visible when GUI is closed
local OpenGUI = Instance.new("TextButton") -- Part of SideFrame
local SideFrameTitle = Instance.new("TextLabel") -- Part of SideFrame
local MainFrame = Instance.new("Frame") -- All of the stuff on the main frame
local GuiBottomFrame = Instance.new("Frame") -- Part of Active Frame
local Credits = Instance.new("TextLabel") -- Credits to illremember, hello there
local ScrollingFrame = Instance.new("ScrollingFrame") -- The scrolling frame of animations
local CheckR = Instance.new("TextLabel") -- Check if R15 or R6
local ScrollingFrameR15 = Instance.new("ScrollingFrame") -- The scrolling frame of R15 animations

local CrazySlash = Instance.new("TextButton")--COMPLETE
local Open = Instance.new("TextButton")--COMPLETE
local R15Spinner = Instance.new("TextButton")--COMPLETE
local ArmsOut = Instance.new("TextButton")--COMPLETE
local FloatSlash = Instance.new("TextButton")--COMPLETE
local WeirdZombie = Instance.new("TextButton")--COMPLETE
local DownSlash = Instance.new("TextButton")--COMPLETE
local Pull = Instance.new("TextButton")--COMPLETE
local CircleArm = Instance.new("TextButton")--COMPLETE
local Bend = Instance.new("TextButton")--COMPLETE
local RotateSlash = Instance.new("TextButton")--COMPLETE
local FlingArms = Instance.new("TextButton")--COMPLETE

local FullSwing = Instance.new("TextButton")--COMPLETE
local GlitchLevitate = Instance.new("TextButton")--COMPLETE
local MoonDance = Instance.new("TextButton")--COMPLETE
local FullPunch = Instance.new("TextButton")--COMPLETE
local Crouch = Instance.new("TextButton")--COMPLETE
local SpinDance = Instance.new("TextButton")--COMPLETE
local FloorFaint = Instance.new("TextButton")--COMPLETE
local JumpingJacks = Instance.new("TextButton")--COMPLETE
local Spinner = Instance.new("TextButton")--COMPLETE
local MegaInsane = Instance.new("TextButton")--COMPLETE
local ArmDetach = Instance.new("TextButton")--COMPLETE
local WeirdMove = Instance.new("TextButton")--COMPLETE
local Faint = Instance.new("TextButton")--COMPLETE
local CloneIllusion = Instance.new("TextButton")--COMPLETE
local Levitate = Instance.new("TextButton")--COMPLETE
local DinoWalk = Instance.new("TextButton")--COMPLETE
local FloorCrawl = Instance.new("TextButton")--COMPLETE
local SwordSlam = Instance.new("TextButton")--COMPLETE
local LoopHead = Instance.new("TextButton")--COMPLETE
local HeroJump = Instance.new("TextButton")--COMPLETE
local Insane = Instance.new("TextButton")--COMPLETE
local FloatingHead = Instance.new("TextButton")--COMPLETE
local HeadThrow = Instance.new("TextButton")--COMPLETE
local MovingDance = Instance.new("TextButton")--COMPLETE
local SuperPunch = Instance.new("TextButton")--COMPLETE
local ArmTurbine = Instance.new("TextButton")--COMPLETE
local Dab = Instance.new("TextButton")--COMPLETE
local FloatSit = Instance.new("TextButton")--COMPLETE
local SuperFaint = Instance.new("TextButton")--COMPLETE
local BarrelRoll = Instance.new("TextButton")--COMPLETE
local Scared = Instance.new("TextButton")--COMPLETE
local InsaneArms = Instance.new("TextButton")--COMPLETE
local SwordSlice = Instance.new("TextButton")--COMPLETE
local SpinDance2 = Instance.new("TextButton")--COMPLETE
local BowDown = Instance.new("TextButton")--COMPLETE
local LoopSlam = Instance.new("TextButton")--COMPLETE

local GuiTopFrame = Instance.new("Frame") -- Top of the main frame
local CloseGUI = Instance.new("TextButton") -- To close the GUI
local Title = Instance.new("TextLabel") -- Actual title of GUI, Energize

-- Properties

Energize.Name = "Energize"
Energize.Parent = game.Players.LocalPlayer.PlayerGui

SideFrame.Name = "SideFrame"
SideFrame.Parent = Energize
SideFrame.Active = true
SideFrame.BackgroundColor3 = Color3.new(1, 0.329412, 0.329412)
SideFrame.Draggable = true
SideFrame.Position = UDim2.new(0, 376, 0, 125)
SideFrame.Size = UDim2.new(0, 460, 0, 32)
SideFrame.Visible = false

OpenGUI.Name = "OpenGUI"
OpenGUI.Parent = SideFrame
OpenGUI.BackgroundColor3 = Color3.new(1, 1, 1)
OpenGUI.BackgroundTransparency = 1
OpenGUI.Position = UDim2.new(0, 426, 0, 0)
OpenGUI.Size = UDim2.new(0, 34, 0, 32)
OpenGUI.Font = Enum.Font.SourceSans
OpenGUI.FontSize = Enum.FontSize.Size48
OpenGUI.Text = "X"
OpenGUI.TextColor3 = Color3.new(0.333333, 0, 0)
OpenGUI.TextSize = 40
OpenGUI.TextWrapped = true

SideFrameTitle.Name = "SideFrameTitle"
SideFrameTitle.Parent = SideFrame
SideFrameTitle.BackgroundColor3 = Color3.new(1, 1, 1)
SideFrameTitle.BackgroundTransparency = 1
SideFrameTitle.Position = UDim2.new(0, 170, 0, 0)
SideFrameTitle.Size = UDim2.new(0, 119, 0, 31)
SideFrameTitle.Font = Enum.Font.Arial
SideFrameTitle.FontSize = Enum.FontSize.Size24
SideFrameTitle.Text = "-Energize-"
SideFrameTitle.TextSize = 21
SideFrameTitle.TextStrokeColor3 = Color3.new(0.27451, 0.92549, 0.905882)
SideFrameTitle.TextStrokeTransparency = 0.69999998807907

MainFrame.Name = "MainFrame"
MainFrame.Parent = Energize
MainFrame.Active = true
MainFrame.BackgroundColor3 = Color3.new(1, 1, 1)
MainFrame.BackgroundTransparency = 1
MainFrame.Draggable = true
MainFrame.Position = UDim2.new(0, 376, 0, 125)
MainFrame.Size = UDim2.new(0, 444, 0, 280)

GuiBottomFrame.Name = "Gui BottomFrame"
GuiBottomFrame.Parent = MainFrame
GuiBottomFrame.BackgroundColor3 = Color3.new(1, 0.329412, 0.329412)
GuiBottomFrame.BorderColor3 = Color3.new(0.243137, 0.243137, 0.243137)
GuiBottomFrame.Position = UDim2.new(0, 0, 0, 247)
GuiBottomFrame.Size = UDim2.new(0, 460, 0, 32)

Credits.Name = "Credits"
Credits.Parent = GuiBottomFrame
Credits.BackgroundColor3 = Color3.new(1, 1, 1)
Credits.BackgroundTransparency = 1
Credits.Size = UDim2.new(0, 460, 0, 32)
Credits.FontSize = Enum.FontSize.Size14
Credits.Text = "By illremember -FE Animations Gui"
Credits.TextColor3 = Color3.new(0.219608, 0.219608, 0.219608)
Credits.TextSize = 14
Credits.TextStrokeColor3 = Color3.new(0.141176, 0.870588, 0.713726)
Credits.TextStrokeTransparency = 0.69999998807907
Credits.TextWrapped = true

ScrollingFrame.Parent = MainFrame
ScrollingFrame.BackgroundColor3 = Color3.new(1, 0.564706, 0.564706)
ScrollingFrame.Position = UDim2.new(0, 0, 0, 32)
ScrollingFrame.Size = UDim2.new(0, 460, 0, 215)
ScrollingFrame.ScrollBarThickness = 13

FullSwing.Name = "FullSwing"
FullSwing.Parent = ScrollingFrame
FullSwing.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
FullSwing.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FullSwing.Position = UDim2.new(0, 17, 0, 322)
FullSwing.Size = UDim2.new(0, 119, 0, 34)
FullSwing.Font = Enum.Font.Highway
FullSwing.FontSize = Enum.FontSize.Size24
FullSwing.Text = "Full Swing"
FullSwing.TextSize = 20
FullSwing.TextWrapped = true

GlitchLevitate.Name = "GlitchLevitate"
GlitchLevitate.Parent = ScrollingFrame
GlitchLevitate.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
GlitchLevitate.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
GlitchLevitate.Position = UDim2.new(0, 319, 0, 322)
GlitchLevitate.Size = UDim2.new(0, 119, 0, 34)
GlitchLevitate.Font = Enum.Font.Highway
GlitchLevitate.FontSize = Enum.FontSize.Size24
GlitchLevitate.Text = "Glitch Levitate"
GlitchLevitate.TextSize = 20
GlitchLevitate.TextWrapped = true

MoonDance.Name = "MoonDance"
MoonDance.Parent = ScrollingFrame
MoonDance.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
MoonDance.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
MoonDance.Position = UDim2.new(0, 319, 0, 280)
MoonDance.Size = UDim2.new(0, 119, 0, 34)
MoonDance.Font = Enum.Font.Highway
MoonDance.FontSize = Enum.FontSize.Size24
MoonDance.Text = "Moon Dance"
MoonDance.TextSize = 20
MoonDance.TextWrapped = true

FullPunch.Name = "FullPunch"
FullPunch.Parent = ScrollingFrame
FullPunch.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
FullPunch.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FullPunch.Position = UDim2.new(0, 17, 0, 280)
FullPunch.Size = UDim2.new(0, 119, 0, 34)
FullPunch.Font = Enum.Font.Highway
FullPunch.FontSize = Enum.FontSize.Size24
FullPunch.Text = "Full Punch"
FullPunch.TextSize = 20
FullPunch.TextWrapped = true

Crouch.Name = "Crouch"
Crouch.Parent = ScrollingFrame
Crouch.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
Crouch.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Crouch.Position = UDim2.new(0, 168, 0, 280)
Crouch.Size = UDim2.new(0, 119, 0, 34)
Crouch.Font = Enum.Font.Highway
Crouch.FontSize = Enum.FontSize.Size24
Crouch.Text = "Crouch"
Crouch.TextSize = 20
Crouch.TextWrapped = true

SpinDance.Name = "SpinDance"
SpinDance.Parent = ScrollingFrame
SpinDance.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
SpinDance.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
SpinDance.Position = UDim2.new(0, 168, 0, 236)
SpinDance.Size = UDim2.new(0, 119, 0, 34)
SpinDance.Font = Enum.Font.Highway
SpinDance.FontSize = Enum.FontSize.Size24
SpinDance.Text = "Spin Dance"
SpinDance.TextSize = 20
SpinDance.TextWrapped = true

FloorFaint.Name = "FloorFaint"
FloorFaint.Parent = ScrollingFrame
FloorFaint.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
FloorFaint.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FloorFaint.Position = UDim2.new(0, 17, 0, 236)
FloorFaint.Size = UDim2.new(0, 119, 0, 34)
FloorFaint.Font = Enum.Font.Highway
FloorFaint.FontSize = Enum.FontSize.Size24
FloorFaint.Text = "Floor Faint"
FloorFaint.TextSize = 20
FloorFaint.TextWrapped = true

JumpingJacks.Name = "JumpingJacks"
JumpingJacks.Parent = ScrollingFrame
JumpingJacks.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
JumpingJacks.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
JumpingJacks.Position = UDim2.new(0, 319, 0, 236)
JumpingJacks.Size = UDim2.new(0, 119, 0, 34)
JumpingJacks.Font = Enum.Font.Highway
JumpingJacks.FontSize = Enum.FontSize.Size24
JumpingJacks.Text = "Jumping Jacks"
JumpingJacks.TextSize = 20
JumpingJacks.TextWrapped = true

Spinner.Name = "Spinner"
Spinner.Parent = ScrollingFrame
Spinner.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
Spinner.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Spinner.Position = UDim2.new(0, 17, 0, 192)
Spinner.Size = UDim2.new(0, 119, 0, 34)
Spinner.Font = Enum.Font.Highway
Spinner.FontSize = Enum.FontSize.Size24
Spinner.Text = "Spinner"
Spinner.TextSize = 20
Spinner.TextWrapped = true

MegaInsane.Name = "MegaInsane"
MegaInsane.Parent = ScrollingFrame
MegaInsane.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
MegaInsane.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
MegaInsane.Position = UDim2.new(0, 168, 0, 192)
MegaInsane.Size = UDim2.new(0, 119, 0, 34)
MegaInsane.Font = Enum.Font.Highway
MegaInsane.FontSize = Enum.FontSize.Size24
MegaInsane.Text = "Mega Insane"
MegaInsane.TextSize = 20
MegaInsane.TextWrapped = true

ArmDetach.Name = "ArmDetach"
ArmDetach.Parent = ScrollingFrame
ArmDetach.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
ArmDetach.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
ArmDetach.Position = UDim2.new(0, 319, 0, 192)
ArmDetach.Size = UDim2.new(0, 119, 0, 34)
ArmDetach.Font = Enum.Font.Highway
ArmDetach.FontSize = Enum.FontSize.Size24
ArmDetach.Text = "Arm Detach"
ArmDetach.TextSize = 20
ArmDetach.TextWrapped = true

WeirdMove.Name = "WeirdMove"
WeirdMove.Parent = ScrollingFrame
WeirdMove.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
WeirdMove.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
WeirdMove.Position = UDim2.new(0, 168, 0, 148)
WeirdMove.Size = UDim2.new(0, 119, 0, 34)
WeirdMove.Font = Enum.Font.Highway
WeirdMove.FontSize = Enum.FontSize.Size24
WeirdMove.Text = "Weird Move"
WeirdMove.TextSize = 20
WeirdMove.TextWrapped = true

Faint.Name = "Faint"
Faint.Parent = ScrollingFrame
Faint.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
Faint.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Faint.Position = UDim2.new(0, 17, 0, 148)
Faint.Size = UDim2.new(0, 119, 0, 34)
Faint.Font = Enum.Font.Highway
Faint.FontSize = Enum.FontSize.Size24
Faint.Text = "Faint"
Faint.TextSize = 20
Faint.TextWrapped = true

CloneIllusion.Name = "CloneIllusion"
CloneIllusion.Parent = ScrollingFrame
CloneIllusion.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
CloneIllusion.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
CloneIllusion.Position = UDim2.new(0, 319, 0, 148)
CloneIllusion.Size = UDim2.new(0, 119, 0, 34)
CloneIllusion.Font = Enum.Font.Highway
CloneIllusion.FontSize = Enum.FontSize.Size24
CloneIllusion.Text = "Clone Illusion"
CloneIllusion.TextSize = 20
CloneIllusion.TextWrapped = true

Levitate.Name = "Levitate"
Levitate.Parent = ScrollingFrame
Levitate.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
Levitate.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Levitate.Position = UDim2.new(0, 17, 0, 104)
Levitate.Size = UDim2.new(0, 119, 0, 34)
Levitate.Font = Enum.Font.Highway
Levitate.FontSize = Enum.FontSize.Size24
Levitate.Text = "Levitate"
Levitate.TextSize = 20
Levitate.TextWrapped = true

DinoWalk.Name = "DinoWalk"
DinoWalk.Parent = ScrollingFrame
DinoWalk.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
DinoWalk.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
DinoWalk.Position = UDim2.new(0, 168, 0, 104)
DinoWalk.Size = UDim2.new(0, 119, 0, 34)
DinoWalk.Font = Enum.Font.Highway
DinoWalk.FontSize = Enum.FontSize.Size24
DinoWalk.Text = "Dino Walk"
DinoWalk.TextSize = 20
DinoWalk.TextWrapped = true

FloorCrawl.Name = "FloorCrawl"
FloorCrawl.Parent = ScrollingFrame
FloorCrawl.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
FloorCrawl.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FloorCrawl.Position = UDim2.new(0, 319, 0, 104)
FloorCrawl.Size = UDim2.new(0, 119, 0, 34)
FloorCrawl.Font = Enum.Font.Highway
FloorCrawl.FontSize = Enum.FontSize.Size24
FloorCrawl.Text = "Floor Crawl"
FloorCrawl.TextSize = 20
FloorCrawl.TextWrapped = true

SwordSlam.Name = "SwordSlam"
SwordSlam.Parent = ScrollingFrame
SwordSlam.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
SwordSlam.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
SwordSlam.Position = UDim2.new(0, 319, 0, 60)
SwordSlam.Size = UDim2.new(0, 119, 0, 34)
SwordSlam.Font = Enum.Font.Highway
SwordSlam.FontSize = Enum.FontSize.Size24
SwordSlam.Text = "Sword Slam"
SwordSlam.TextSize = 20
SwordSlam.TextWrapped = true

LoopHead.Name = "LoopHead"
LoopHead.Parent = ScrollingFrame
LoopHead.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
LoopHead.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
LoopHead.Position = UDim2.new(0, 168, 0, 60)
LoopHead.Size = UDim2.new(0, 119, 0, 34)
LoopHead.Font = Enum.Font.Highway
LoopHead.FontSize = Enum.FontSize.Size24
LoopHead.Text = "Loop Head"
LoopHead.TextSize = 20
LoopHead.TextWrapped = true

HeroJump.Name = "HeroJump"
HeroJump.Parent = ScrollingFrame
HeroJump.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
HeroJump.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
HeroJump.Position = UDim2.new(0, 17, 0, 60)
HeroJump.Size = UDim2.new(0, 119, 0, 34)
HeroJump.Font = Enum.Font.Highway
HeroJump.FontSize = Enum.FontSize.Size24
HeroJump.Text = "Hero Jump"
HeroJump.TextSize = 20
HeroJump.TextWrapped = true

Insane.Name = "Insane"
Insane.Parent = ScrollingFrame
Insane.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
Insane.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Insane.Position = UDim2.new(0, 319, 0, 16)
Insane.Size = UDim2.new(0, 119, 0, 34)
Insane.Font = Enum.Font.Highway
Insane.FontSize = Enum.FontSize.Size24
Insane.Text = "Insane"
Insane.TextSize = 20
Insane.TextWrapped = true

FloatingHead.Name = "FloatingHead"
FloatingHead.Parent = ScrollingFrame
FloatingHead.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
FloatingHead.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FloatingHead.Position = UDim2.new(0, 168, 0, 16)
FloatingHead.Size = UDim2.new(0, 119, 0, 34)
FloatingHead.Font = Enum.Font.Highway
FloatingHead.FontSize = Enum.FontSize.Size24
FloatingHead.Text = "Floating Head"
FloatingHead.TextSize = 20
FloatingHead.TextWrapped = true

HeadThrow.Name = "HeadThrow"
HeadThrow.Parent = ScrollingFrame
HeadThrow.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
HeadThrow.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
HeadThrow.Position = UDim2.new(0, 17, 0, 16)
HeadThrow.Size = UDim2.new(0, 119, 0, 34)
HeadThrow.Font = Enum.Font.Highway
HeadThrow.FontSize = Enum.FontSize.Size24
HeadThrow.Text = "Head Throw"
HeadThrow.TextSize = 20
HeadThrow.TextWrapped = true

MovingDance.Name = "MovingDance"
MovingDance.Parent = ScrollingFrame
MovingDance.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
MovingDance.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
MovingDance.Position = UDim2.new(0, 168, 0, 324)
MovingDance.Size = UDim2.new(0, 119, 0, 34)
MovingDance.Font = Enum.Font.Highway
MovingDance.FontSize = Enum.FontSize.Size24
MovingDance.Text = "Moving Dance"
MovingDance.TextSize = 20
MovingDance.TextWrapped = true

SuperPunch.Name = "SuperPunch"
SuperPunch.Parent = ScrollingFrame
SuperPunch.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
SuperPunch.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
SuperPunch.Position = UDim2.new(0, 168, 0, 366)
SuperPunch.Size = UDim2.new(0, 119, 0, 34)
SuperPunch.Font = Enum.Font.Highway
SuperPunch.FontSize = Enum.FontSize.Size24
SuperPunch.Text = "Super Punch"
SuperPunch.TextSize = 20
SuperPunch.TextWrapped = true

ArmTurbine.Name = "ArmTurbine"
ArmTurbine.Parent = ScrollingFrame
ArmTurbine.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
ArmTurbine.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
ArmTurbine.Position = UDim2.new(0, 319, 0, 366)
ArmTurbine.Size = UDim2.new(0, 119, 0, 34)
ArmTurbine.Font = Enum.Font.Highway
ArmTurbine.FontSize = Enum.FontSize.Size24
ArmTurbine.Text = "Arm Turbine"
ArmTurbine.TextSize = 20
ArmTurbine.TextWrapped = true

Dab.Name = "Dab"
Dab.Parent = ScrollingFrame
Dab.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
Dab.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Dab.Position = UDim2.new(0, 17, 0, 366)
Dab.Size = UDim2.new(0, 119, 0, 34)
Dab.Font = Enum.Font.Highway
Dab.FontSize = Enum.FontSize.Size24
Dab.Text = "Dab"
Dab.TextSize = 20
Dab.TextWrapped = true

FloatSit.Name = "FloatSit"
FloatSit.Parent = ScrollingFrame
FloatSit.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
FloatSit.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FloatSit.Position = UDim2.new(0, 168, 0, 410)
FloatSit.Size = UDim2.new(0, 119, 0, 34)
FloatSit.Font = Enum.Font.Highway
FloatSit.FontSize = Enum.FontSize.Size24
FloatSit.Text = "Float Sit"
FloatSit.TextSize = 20
FloatSit.TextWrapped = true

SuperFaint.Name = "SuperFaint"
SuperFaint.Parent = ScrollingFrame
SuperFaint.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
SuperFaint.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
SuperFaint.Position = UDim2.new(0, 17, 0, 498)
SuperFaint.Size = UDim2.new(0, 119, 0, 34)
SuperFaint.Font = Enum.Font.Highway
SuperFaint.FontSize = Enum.FontSize.Size24
SuperFaint.Text = "Super Faint"
SuperFaint.TextSize = 20
SuperFaint.TextWrapped = true

BarrelRoll.Name = "BarrelRoll"
BarrelRoll.Parent = ScrollingFrame
BarrelRoll.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
BarrelRoll.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
BarrelRoll.Position = UDim2.new(0, 319, 0, 410)
BarrelRoll.Size = UDim2.new(0, 119, 0, 34)
BarrelRoll.Font = Enum.Font.Highway
BarrelRoll.FontSize = Enum.FontSize.Size24
BarrelRoll.Text = "Barrel Roll"
BarrelRoll.TextSize = 20
BarrelRoll.TextWrapped = true

Scared.Name = "Scared"
Scared.Parent = ScrollingFrame
Scared.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
Scared.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Scared.Position = UDim2.new(0, 319, 0, 454)
Scared.Size = UDim2.new(0, 119, 0, 34)
Scared.Font = Enum.Font.Highway
Scared.FontSize = Enum.FontSize.Size24
Scared.Text = "Scared"
Scared.TextSize = 20
Scared.TextWrapped = true

InsaneArms.Name = "InsaneArms"
InsaneArms.Parent = ScrollingFrame
InsaneArms.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
InsaneArms.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
InsaneArms.Position = UDim2.new(0, 17, 0, 454)
InsaneArms.Size = UDim2.new(0, 119, 0, 34)
InsaneArms.Font = Enum.Font.Highway
InsaneArms.FontSize = Enum.FontSize.Size24
InsaneArms.Text = "Insane Arms"
InsaneArms.TextSize = 20
InsaneArms.TextWrapped = true

SwordSlice.Name = "SwordSlice"
SwordSlice.Parent = ScrollingFrame
SwordSlice.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
SwordSlice.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
SwordSlice.Position = UDim2.new(0, 168, 0, 454)
SwordSlice.Size = UDim2.new(0, 119, 0, 34)
SwordSlice.Font = Enum.Font.Highway
SwordSlice.FontSize = Enum.FontSize.Size24
SwordSlice.Text = "Sword Slice"
SwordSlice.TextSize = 20
SwordSlice.TextWrapped = true

SpinDance2.Name = "SpinDance2"
SpinDance2.Parent = ScrollingFrame
SpinDance2.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
SpinDance2.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
SpinDance2.Position = UDim2.new(0, 168, 0, 498)
SpinDance2.Size = UDim2.new(0, 119, 0, 34)
SpinDance2.Font = Enum.Font.Highway
SpinDance2.FontSize = Enum.FontSize.Size24
SpinDance2.Text = "Spin Dance 2"
SpinDance2.TextSize = 20
SpinDance2.TextWrapped = true

BowDown.Name = "BowDown"
BowDown.Parent = ScrollingFrame
BowDown.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
BowDown.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
BowDown.Position = UDim2.new(0, 319, 0, 498)
BowDown.Size = UDim2.new(0, 119, 0, 34)
BowDown.Font = Enum.Font.Highway
BowDown.FontSize = Enum.FontSize.Size24
BowDown.Text = "Bow Down"
BowDown.TextSize = 20
BowDown.TextWrapped = true

LoopSlam.Name = "LoopSlam"
LoopSlam.Parent = ScrollingFrame
LoopSlam.BackgroundColor3 = Color3.new(0.886275, 0.776471, 0.368627)
LoopSlam.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
LoopSlam.Position = UDim2.new(0, 17, 0, 410)
LoopSlam.Size = UDim2.new(0, 119, 0, 34)
LoopSlam.Font = Enum.Font.Highway
LoopSlam.FontSize = Enum.FontSize.Size24
LoopSlam.Text = "Loop Slam"
LoopSlam.TextSize = 20
LoopSlam.TextWrapped = true

GuiTopFrame.Name = "Gui TopFrame"
GuiTopFrame.Parent = MainFrame
GuiTopFrame.BackgroundColor3 = Color3.new(1, 0.329412, 0.329412)
GuiTopFrame.BorderColor3 = Color3.new(0.243137, 0.243137, 0.243137)
GuiTopFrame.Size = UDim2.new(0, 460, 0, 32)

CloseGUI.Name = "CloseGUI"
CloseGUI.Parent = GuiTopFrame
CloseGUI.BackgroundColor3 = Color3.new(1, 1, 1)
CloseGUI.BackgroundTransparency = 1
CloseGUI.Position = UDim2.new(0, 426, 0, 0)
CloseGUI.Size = UDim2.new(0, 34, 0, 32)
CloseGUI.Font = Enum.Font.SourceSans
CloseGUI.FontSize = Enum.FontSize.Size48
CloseGUI.Text = "X"
CloseGUI.TextColor3 = Color3.new(0.333333, 0, 0)
CloseGUI.TextSize = 40
CloseGUI.TextWrapped = true

Title.Name = "Title"
Title.Parent = GuiTopFrame
Title.BackgroundColor3 = Color3.new(1, 1, 1)
Title.BackgroundTransparency = 1
Title.Size = UDim2.new(0, 460, 0, 32)
Title.FontSize = Enum.FontSize.Size14
Title.Text = "-Energize-"
Title.TextColor3 = Color3.new(0.164706, 0.164706, 0.164706)
Title.TextSize = 14
Title.TextStrokeColor3 = Color3.new(0.384314, 0.917647, 1)
Title.TextStrokeTransparency = 0.69999998807907
Title.TextWrapped = true

CheckR.Name = "CheckR"
CheckR.Parent = GuiTopFrame
CheckR.BackgroundColor3 = Color3.new(1, 1, 1)
CheckR.BackgroundTransparency = 1
CheckR.Size = UDim2.new(0, 171, 0, 32)
CheckR.Font = Enum.Font.SourceSansBold
CheckR.FontSize = Enum.FontSize.Size14
CheckR.Text = "Text"
CheckR.TextScaled = true
CheckR.TextSize = 14
CheckR.TextWrapped = true

ScrollingFrameR15.Name = "ScrollingFrameR15"
ScrollingFrameR15.Parent = MainFrame
ScrollingFrameR15.BackgroundColor3 = Color3.new(1, 0.564706, 0.564706)
ScrollingFrameR15.Position = UDim2.new(0, 0, 0, 32)
ScrollingFrameR15.Size = UDim2.new(0, 460, 0, 215)
ScrollingFrameR15.Visible = false
ScrollingFrameR15.ScrollBarThickness = 13

CrazySlash.Name = "CrazySlash"
CrazySlash.Parent = ScrollingFrameR15
CrazySlash.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
CrazySlash.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
CrazySlash.Position = UDim2.new(0, 17, 0, 16)
CrazySlash.Size = UDim2.new(0, 119, 0, 34)
CrazySlash.Font = Enum.Font.Highway
CrazySlash.FontSize = Enum.FontSize.Size24
CrazySlash.Text = "CrazySlash"
CrazySlash.TextSize = 20
CrazySlash.TextWrapped = true

Open.Name = "Open"
Open.Parent = ScrollingFrameR15
Open.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
Open.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Open.Position = UDim2.new(0, 168, 0, 16)
Open.Size = UDim2.new(0, 119, 0, 34)
Open.Font = Enum.Font.Highway
Open.FontSize = Enum.FontSize.Size24
Open.Text = "Open"
Open.TextSize = 20
Open.TextWrapped = true

R15Spinner.Name = "R15Spinner"
R15Spinner.Parent = ScrollingFrameR15
R15Spinner.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
R15Spinner.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
R15Spinner.Position = UDim2.new(0, 17, 0, 60)
R15Spinner.Size = UDim2.new(0, 119, 0, 34)
R15Spinner.Font = Enum.Font.Highway
R15Spinner.FontSize = Enum.FontSize.Size24
R15Spinner.Text = "Spinner"
R15Spinner.TextSize = 20
R15Spinner.TextWrapped = true

ArmsOut.Name = "ArmsOut"
ArmsOut.Parent = ScrollingFrameR15
ArmsOut.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
ArmsOut.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
ArmsOut.Position = UDim2.new(0, 319, 0, 16)
ArmsOut.Size = UDim2.new(0, 119, 0, 34)
ArmsOut.Font = Enum.Font.Highway
ArmsOut.FontSize = Enum.FontSize.Size24
ArmsOut.Text = "ArmsOut"
ArmsOut.TextSize = 20
ArmsOut.TextWrapped = true

FloatSlash.Name = "FloatSlash"
FloatSlash.Parent = ScrollingFrameR15
FloatSlash.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
FloatSlash.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FloatSlash.Position = UDim2.new(0, 168, 0, 148)
FloatSlash.Size = UDim2.new(0, 119, 0, 34)
FloatSlash.Font = Enum.Font.Highway
FloatSlash.FontSize = Enum.FontSize.Size24
FloatSlash.Text = "FloatSlash"
FloatSlash.TextSize = 20
FloatSlash.TextWrapped = true

WeirdZombie.Name = "WeirdZombie"
WeirdZombie.Parent = ScrollingFrameR15
WeirdZombie.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
WeirdZombie.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
WeirdZombie.Position = UDim2.new(0, 17, 0, 148)
WeirdZombie.Size = UDim2.new(0, 119, 0, 34)
WeirdZombie.Font = Enum.Font.Highway
WeirdZombie.FontSize = Enum.FontSize.Size24
WeirdZombie.Text = "WeirdZombie"
WeirdZombie.TextSize = 20
WeirdZombie.TextWrapped = true

DownSlash.Name = "DownSlash"
DownSlash.Parent = ScrollingFrameR15
DownSlash.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
DownSlash.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
DownSlash.Position = UDim2.new(0, 319, 0, 148)
DownSlash.Size = UDim2.new(0, 119, 0, 34)
DownSlash.Font = Enum.Font.Highway
DownSlash.FontSize = Enum.FontSize.Size24
DownSlash.Text = "DownSlash"
DownSlash.TextSize = 20
DownSlash.TextWrapped = true

Pull.Name = "Pull"
Pull.Parent = ScrollingFrameR15
Pull.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
Pull.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Pull.Position = UDim2.new(0, 17, 0, 104)
Pull.Size = UDim2.new(0, 119, 0, 34)
Pull.Font = Enum.Font.Highway
Pull.FontSize = Enum.FontSize.Size24
Pull.Text = "Pull"
Pull.TextSize = 20
Pull.TextWrapped = true

CircleArm.Name = "CircleArm"
CircleArm.Parent = ScrollingFrameR15
CircleArm.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
CircleArm.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
CircleArm.Position = UDim2.new(0, 168, 0, 104)
CircleArm.Size = UDim2.new(0, 119, 0, 34)
CircleArm.Font = Enum.Font.Highway
CircleArm.FontSize = Enum.FontSize.Size24
CircleArm.Text = "CircleArm"
CircleArm.TextSize = 20
CircleArm.TextWrapped = true

Bend.Name = "Bend"
Bend.Parent = ScrollingFrameR15
Bend.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
Bend.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
Bend.Position = UDim2.new(0, 319, 0, 104)
Bend.Size = UDim2.new(0, 119, 0, 34)
Bend.Font = Enum.Font.Highway
Bend.FontSize = Enum.FontSize.Size24
Bend.Text = "Bend"
Bend.TextSize = 20
Bend.TextWrapped = true

RotateSlash.Name = "RotateSlash"
RotateSlash.Parent = ScrollingFrameR15
RotateSlash.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
RotateSlash.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
RotateSlash.Position = UDim2.new(0, 319, 0, 60)
RotateSlash.Size = UDim2.new(0, 119, 0, 34)
RotateSlash.Font = Enum.Font.Highway
RotateSlash.FontSize = Enum.FontSize.Size24
RotateSlash.Text = "RotateSlash"
RotateSlash.TextSize = 20
RotateSlash.TextWrapped = true

FlingArms.Name = "FlingArms"
FlingArms.Parent = ScrollingFrameR15
FlingArms.BackgroundColor3 = Color3.new(0.682353, 0.701961, 0.792157)
FlingArms.BorderColor3 = Color3.new(0.313726, 0.313726, 0.313726)
FlingArms.Position = UDim2.new(0, 168, 0, 60)
FlingArms.Size = UDim2.new(0, 119, 0, 34)
FlingArms.Font = Enum.Font.Highway
FlingArms.FontSize = Enum.FontSize.Size24
FlingArms.Text = "FlingArms"
FlingArms.TextSize = 20
FlingArms.TextWrapped = true

-- Buttons
col = Color3.new(0.886275, 0.776471, 0.368627)
loc = Color3.new(1, 0.906471, 0.568627)
rcol = Color3.new(0.682353, 0.701961, 0.792157)
rloc = Color3.new(0.882353, 0.901961, 0.992157)

CloseGUI.MouseButton1Click:connect(function()
MainFrame.Visible = false
SideFrame.Visible = true
SideFrame.Position = MainFrame.Position
end)

OpenGUI.MouseButton1Click:connect(function()
MainFrame.Visible = true
SideFrame.Visible = false
MainFrame.Position = SideFrame.Position
end)

if (game:GetService"Players".LocalPlayer.Character:WaitForChild("Humanoid").RigType == Enum.HumanoidRigType.R15) then
	ScrollingFrame.Visible = false
	ScrollingFrameR15.Visible = true
	CheckR.Text = "Showing R15 Animations"
else
	ScrollingFrame.Visible = true
	ScrollingFrameR15.Visible = false
	CheckR.Text = "Showing R6 Animations"
end

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://35154961"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local HeadThrowACTIVE = false
HeadThrow.MouseButton1Click:connect(function()
	HeadThrowACTIVE = not HeadThrowACTIVE
	if HeadThrowACTIVE then
		HeadThrow.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if HeadThrowACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		HeadThrow.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://121572214"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FloatingHeadACTIVE = false
FloatingHead.MouseButton1Click:connect(function()
	FloatingHeadACTIVE = not FloatingHeadACTIVE
	if FloatingHeadACTIVE then
		track:Play(.1, 1, 1)
		FloatingHead.BackgroundColor3 = loc
	else
		track:Stop()
		FloatingHead.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://182724289"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local CrouchACTIVE = false
Crouch.MouseButton1Click:connect(function()
	CrouchACTIVE = not CrouchACTIVE
	if CrouchACTIVE then
		track:Play(.1, 1, 1)
		Crouch.BackgroundColor3 = loc
	else
		track:Stop()
		Crouch.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://282574440"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FloorCrawlACTIVE = false
FloorCrawl.MouseButton1Click:connect(function()
	FloorCrawlACTIVE = not FloorCrawlACTIVE
	if FloorCrawlACTIVE then
		track:Play(.1, 1, 1)
		FloorCrawl.BackgroundColor3 = loc
	else
		track:Stop()
		FloorCrawl.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://204328711"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local DinoWalkACTIVE = false
DinoWalk.MouseButton1Click:connect(function()
	DinoWalkACTIVE = not DinoWalkACTIVE
	if DinoWalkACTIVE then
		track:Play(.1, 1, 1)
		DinoWalk.BackgroundColor3 = loc
	else
		track:Stop()
		DinoWalk.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://429681631"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local JumpingJacksACTIVE = false
JumpingJacks.MouseButton1Click:connect(function()
	JumpingJacksACTIVE = not JumpingJacksACTIVE
	if JumpingJacksACTIVE then
		track:Play(.1, 1, 1)
		JumpingJacks.BackgroundColor3 = loc
	else
		track:Stop()
		JumpingJacks.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://35154961"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local LoopHeadACTIVE = false
LoopHead.MouseButton1Click:connect(function()
	LoopHeadACTIVE = not LoopHeadACTIVE
	if LoopHeadACTIVE then
		LoopHead.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if LoopHeadACTIVE then
				track:Play(.5, 1, 1e6)
			end
		 end
		end
	else
		track:Stop()
		LoopHead.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://184574340"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local HeroJumpACTIVE = false
HeroJump.MouseButton1Click:connect(function()
	HeroJumpACTIVE = not HeroJumpACTIVE
	if HeroJumpACTIVE then
		HeroJump.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if HeroJumpACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		HeroJump.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://181526230"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FaintACTIVE = false
Faint.MouseButton1Click:connect(function()
	FaintACTIVE = not FaintACTIVE
	if FaintACTIVE then
		track:Play(.1, 1, 1)
		Faint.BackgroundColor3 = loc
	else
		track:Stop()
		Faint.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://181525546"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FloorFaintACTIVE = false
FloorFaint.MouseButton1Click:connect(function()
	FloorFaintACTIVE = not FloorFaintACTIVE
	if FloorFaintACTIVE then
		FloorFaint.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if FloorFaintACTIVE then
				track:Play(.1, 1, 2)
			end
		 end
		end
	else
		track:Stop()
		FloorFaint.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://181525546"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SuperFaintACTIVE = false
SuperFaint.MouseButton1Click:connect(function()
	SuperFaintACTIVE = not SuperFaintACTIVE
	if SuperFaintACTIVE then
		SuperFaint.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if SuperFaintACTIVE then
				track:Play(.1, 0.5, 40)
			end
		 end
		end
	else
		track:Stop()
		SuperFaint.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://313762630"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local LevitateACTIVE = false
Levitate.MouseButton1Click:connect(function()
	LevitateACTIVE = not LevitateACTIVE
	if LevitateACTIVE then
		track:Play(.1, 1, 1)
		Levitate.BackgroundColor3 = loc
	else
		track:Stop()
		Levitate.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://183412246"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local DabACTIVE = false
Dab.MouseButton1Click:connect(function()
	DabACTIVE = not DabACTIVE
	if DabACTIVE then
		Dab.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if DabACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Dab.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://188632011"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SpinACTIVE = false
Spinner.MouseButton1Click:connect(function()
	SpinACTIVE = not SpinACTIVE
	if SpinACTIVE then
		Spinner.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if SpinACTIVE then
				track:Play(.1, 1, 2)
			end
		 end
		end
	else
		track:Stop()
		Spinner.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://179224234"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FloatSitACTIVE = false
FloatSit.MouseButton1Click:connect(function()
	FloatSitACTIVE = not FloatSitACTIVE
	if FloatSitACTIVE then
		track:Play(.1, 1, 1)
		FloatSit.BackgroundColor3 = loc
	else
		track:Stop()
		FloatSit.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://429703734"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local MovingDanceACTIVE = false
MovingDance.MouseButton1Click:connect(function()
	MovingDanceACTIVE = not MovingDanceACTIVE
	if MovingDanceACTIVE then
		MovingDance.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if MovingDanceACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		MovingDance.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://215384594"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local WeirdMoveACTIVE = false
WeirdMove.MouseButton1Click:connect(function()
	WeirdMoveACTIVE = not WeirdMoveACTIVE
	if WeirdMoveACTIVE then
		track:Play(.1, 1, 1)
		WeirdMove.BackgroundColor3 = loc
	else
		track:Stop()
		WeirdMove.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://215384594"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local CloneIllusionACTIVE = false
CloneIllusion.MouseButton1Click:connect(function()
	CloneIllusionACTIVE = not CloneIllusionACTIVE
	if CloneIllusionACTIVE then
		track:Play(.5, 1, 1e7)
		CloneIllusion.BackgroundColor3 = loc
	else
		track:Stop()
		CloneIllusion.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://313762630"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local GlitchLevitateACTIVE = false
GlitchLevitate.MouseButton1Click:connect(function()
	GlitchLevitateACTIVE = not GlitchLevitateACTIVE
	if GlitchLevitateACTIVE then
		track:Play(.5, 1, 1e7)
		GlitchLevitate.BackgroundColor3 = loc
	else
		track:Stop()
		GlitchLevitate.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://429730430"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SpinDanceACTIVE = false
SpinDance.MouseButton1Click:connect(function()
	SpinDanceACTIVE = not SpinDanceACTIVE
	if SpinDanceACTIVE then
		SpinDance.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if SpinDanceACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		SpinDance.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://45834924"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local MoonDanceACTIVE = false
MoonDance.MouseButton1Click:connect(function()
	MoonDanceACTIVE = not MoonDanceACTIVE
	if MoonDanceACTIVE then
		MoonDance.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if MoonDanceACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		MoonDance.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://204062532"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FullPunchACTIVE = false
FullPunch.MouseButton1Click:connect(function()
	FullPunchACTIVE = not FullPunchACTIVE
	if FullPunchACTIVE then
		FullPunch.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if FullPunchACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		FullPunch.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://186934910"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SpinDance2ACTIVE = false
SpinDance2.MouseButton1Click:connect(function()
	SpinDance2ACTIVE = not SpinDance2ACTIVE
	if SpinDance2ACTIVE then
		SpinDance2.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if SpinDance2ACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		SpinDance2.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://204292303"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local BowDownACTIVE = false
BowDown.MouseButton1Click:connect(function()
	BowDownACTIVE = not BowDownACTIVE
	if BowDownACTIVE then
		BowDown.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if BowDownACTIVE then
				track:Play(.1, 1, 3)
			end
		 end
		end
	else
		track:Stop()
		BowDown.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://204295235"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SwordSlamACTIVE = false
SwordSlam.MouseButton1Click:connect(function()
	SwordSlamACTIVE = not SwordSlamACTIVE
	if SwordSlamACTIVE then
		SwordSlam.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if SwordSlamACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		SwordSlam.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://204295235"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local LoopSlamACTIVE = false
LoopSlam.MouseButton1Click:connect(function()
	LoopSlamACTIVE = not LoopSlamACTIVE
	if LoopSlamACTIVE then
		LoopSlam.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if LoopSlamACTIVE then
				track:Play(.1, 1, 1e4)
			end
		 end
		end
	else
		track:Stop()
		LoopSlam.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://184574340"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local MegaInsaneACTIVE = false
MegaInsane.MouseButton1Click:connect(function()
	MegaInsaneACTIVE = not MegaInsaneACTIVE
	if MegaInsaneACTIVE then
		MegaInsane.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if MegaInsaneACTIVE then
				track:Play(.1, 0.5, 40)
			end
		 end
		end
	else
		track:Stop()
		MegaInsane.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://126753849"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SuperPunchACTIVE = false
SuperPunch.MouseButton1Click:connect(function()
	SuperPunchACTIVE = not SuperPunchACTIVE
	if SuperPunchACTIVE then
		SuperPunch.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if SuperPunchACTIVE then
				track:Play(.1, 1, 3)
			end
		 end
		end
	else
		track:Stop()
		SuperPunch.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://218504594"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FullSwingACTIVE = false
FullSwing.MouseButton1Click:connect(function()
	FullSwingACTIVE = not FullSwingACTIVE
	if FullSwingACTIVE then
		FullSwing.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if FullSwingACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		FullSwing.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://259438880"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local ArmTurbineACTIVE = false
ArmTurbine.MouseButton1Click:connect(function()
	ArmTurbineACTIVE = not ArmTurbineACTIVE
	if ArmTurbineACTIVE then
		track:Play(.1, 1, 1e3)
		ArmTurbine.BackgroundColor3 = loc
	else
		track:Stop()
		ArmTurbine.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://136801964"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local BarrelRollACTIVE = false
BarrelRoll.MouseButton1Click:connect(function()
	BarrelRollACTIVE = not BarrelRollACTIVE
	if BarrelRollACTIVE then
		BarrelRoll.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if BarrelRollACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		BarrelRoll.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://180612465"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local ScaredACTIVE = false
Scared.MouseButton1Click:connect(function()
	ScaredACTIVE = not ScaredACTIVE
	if ScaredACTIVE then
		Scared.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if ScaredACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Scared.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://33796059"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local InsaneACTIVE = false
Insane.MouseButton1Click:connect(function()
	InsaneACTIVE = not InsaneACTIVE
	if InsaneACTIVE then
		track:Play(.1, 1, 1e8)
		Insane.BackgroundColor3 = loc
	else
		track:Stop()
		Insane.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://33169583"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local ArmDetachACTIVE = false
ArmDetach.MouseButton1Click:connect(function()
	ArmDetachACTIVE = not ArmDetachACTIVE
	if ArmDetachACTIVE then
		ArmDetach.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if ArmDetachACTIVE then
				track:Play(.1, 1, 1e6)
			end
		 end
		end
	else
		track:Stop()
		ArmDetach.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://35978879"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SwordSliceACTIVE = false
SwordSlice.MouseButton1Click:connect(function()
	SwordSliceACTIVE = not SwordSliceACTIVE
	if SwordSliceACTIVE then
		track:Play(.1, 1, 1)
		SwordSlice.BackgroundColor3 = loc
	else
		track:Stop()
		SwordSlice.BackgroundColor3 = col
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://27432691"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local InsaneArmsACTIVE = false
InsaneArms.MouseButton1Click:connect(function()
	InsaneArmsACTIVE = not InsaneArmsACTIVE
	if InsaneArmsACTIVE then
		InsaneArms.BackgroundColor3 = loc
		while wait() do
		 if track.IsPlaying == false then
			if InsaneArmsACTIVE then
				track:Play(.1, 1, 1e4)
			end
		 end
		end
	else
		track:Stop()
		InsaneArms.BackgroundColor3 = col
	end
end)
-- R15
local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://674871189"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local CrazySlashACTIVE = false
CrazySlash.MouseButton1Click:connect(function()
	CrazySlashACTIVE = not CrazySlashACTIVE
	if CrazySlashACTIVE then
		CrazySlash.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if CrazySlashACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		CrazySlash.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://582855105"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local OpenACTIVE = false
Open.MouseButton1Click:connect(function()
	OpenACTIVE = not OpenACTIVE
	if OpenACTIVE then
		Open.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if OpenACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Open.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://754658275"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local R15SpinnerACTIVE = false
R15Spinner.MouseButton1Click:connect(function()
	R15SpinnerACTIVE = not R15SpinnerACTIVE
	if R15SpinnerACTIVE then
		R15Spinner.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if R15SpinnerACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		R15Spinner.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://582384156"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local ArmsOutACTIVE = false
ArmsOut.MouseButton1Click:connect(function()
	ArmsOutACTIVE = not ArmsOutACTIVE
	if ArmsOutACTIVE then
		ArmsOut.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if ArmsOutACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		ArmsOut.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://717879555"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FloatSlashACTIVE = false
FloatSlash.MouseButton1Click:connect(function()
	FloatSlashACTIVE = not FloatSlashACTIVE
	if FloatSlashACTIVE then
		FloatSlash.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if FloatSlashACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		FloatSlash.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://708553116"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
WeirdZombieACTIVE = false
WeirdZombie.MouseButton1Click:connect(function()
	WeirdZombieACTIVE = not WeirdZombieACTIVE
	if WeirdZombieACTIVE then
		WeirdZombie.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if WeirdZombieACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		WeirdZombie.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://746398327"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
DownSlashACTIVE = false
DownSlash.MouseButton1Click:connect(function()
	DownSlashACTIVE = not DownSlashACTIVE
	if DownSlashACTIVE then
		DownSlash.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if DownSlashACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		DownSlash.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://675025795"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
PullACTIVE = false
Pull.MouseButton1Click:connect(function()
	PullACTIVE = not PullACTIVE
	if PullACTIVE then
		Pull.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if PullACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Pull.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://698251653"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
CircleArmACTIVE = false
CircleArm.MouseButton1Click:connect(function()
	CircleArmACTIVE = not CircleArmACTIVE
	if CircleArmACTIVE then
		CircleArm.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if CircleArmACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		CircleArm.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://696096087"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
BendACTIVE = false
Bend.MouseButton1Click:connect(function()
	BendACTIVE = not BendACTIVE
	if BendACTIVE then
		Bend.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if BendACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Bend.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://675025570"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
RotateSlashACTIVE = false
RotateSlash.MouseButton1Click:connect(function()
	RotateSlashACTIVE = not RotateSlashACTIVE
	if RotateSlashACTIVE then
		RotateSlash.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if RotateSlashACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		RotateSlash.BackgroundColor3 = rcol
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://754656200"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
FlingArmsACTIVE = false
FlingArms.MouseButton1Click:connect(function()
	FlingArmsACTIVE = not FlingArmsACTIVE
	if FlingArmsACTIVE then
		FlingArms.BackgroundColor3 = rloc
		while wait() do
		 if track.IsPlaying == false then
			if FlingArmsACTIVE then
				track:Play(.1, 1, 10)
			end
		 end
		end
	else
		track:Stop()
		FlingArms.BackgroundColor3 = rcol
	end
end)

-- Finished update!
end)

minekraftfan.Name = "minekraftfan"
minekraftfan.Parent = Scripts
minekraftfan.BackgroundColor3 = Color3.new(0, 0, 0)
minekraftfan.BackgroundTransparency = 0.5
minekraftfan.Position = UDim2.new(0, 0, 0, 148)
minekraftfan.Size = UDim2.new(0, 200, 0, 50)
minekraftfan.Font = Enum.Font.SourceSans
minekraftfan.FontSize = Enum.FontSize.Size14
minekraftfan.Text = "Creeper(R6/R15)"
minekraftfan.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
minekraftfan.TextSize = 14

minekraftfan.MouseButton1Down:connect(function()
if (game:GetService"Players".LocalPlayer.Character:WaitForChild("Humanoid").RigType == Enum.HumanoidRigType.R6) then
game.Players.LocalPlayer.Character.Head.Mesh:Destroy()
game.Players.LocalPlayer.Character["Left Arm"]:Destroy()
game.Players.LocalPlayer.Character["Right Arm"]:Destroy()
end
if (game:GetService"Players".LocalPlayer.Character:WaitForChild("Humanoid").RigType == Enum.HumanoidRigType.R15) then
game.Players.LocalPlayer.Character.Head.Mesh:Destroy()
game.Players.LocalPlayer.Character.LeftHand:Destroy()
game.Players.LocalPlayer.Character.LeftLowerArm:Destroy()
game.Players.LocalPlayer.Character.LeftUpperArm:Destroy()
game.Players.LocalPlayer.Character.RightHand:Destroy()
game.Players.LocalPlayer.Character.RightLowerArm:Destroy()
game.Players.LocalPlayer.Character.RightUpperArm:Destroy()
end
end)

bloks.Name = "bloks"
bloks.Parent = Scripts
bloks.BackgroundColor3 = Color3.new(0, 0, 0)
bloks.BackgroundTransparency = 0.5
bloks.Position = UDim2.new(0, 0, 0, 197)
bloks.Size = UDim2.new(0, 200, 0, 50)
bloks.Font = Enum.Font.SourceSans
bloks.FontSize = Enum.FontSize.Size14
bloks.Text = "Spam Blocks"
bloks.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
bloks.TextSize = 14

bloks.MouseButton1Down:connect(function()
if game.PlaceId == "920587237" then
for i = 1,200 do
game.ReplicatedStorage.API["ClothingAPI/WearAccessory"]:FireServer(215724072, "tried on")
wait(0.1)
for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if v:IsA('Accessory') then
v.Handle.Mesh:Destroy()
wait(0.1)
v.Parent = workspace
end
end
end
end
if game.PlaceId == "367959224" then
local value = 2000
for i = 1,value do
game.ReplicatedStorage.ClothingService:FireServer("Hat", 140469731)
wait(0.1)
for i,v in pairs(game:GetService('Players').LocalPlayer.Character:GetChildren()) do
if v.ClassName == "Accessory" then
v.Handle.Mesh:Destroy()
v.Parent = workspace
end
end
end
end
if game.PlaceId == "597114278" then
for i=1,100 do
print(i)
game.ReplicatedStorage.UpdateClothes:FireServer({[1]= "Outfit1", [2]= "151784320", [3]= "none", [4]= "none", [5]= "none", [6]= "none", [7]= "none"})
game.ReplicatedStorage.Clothes:FireServer({[1]= "331486631", [2]= "none", [3]= "none", [4]= "none", [5]= "none", [6]= "none"})
wait(0.1)
for index, child in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if child.ClassName == "Hat" or child.ClassName == "Accessory" then
if child.Handle:FindFirstChild("Mesh") then
child.Handle.Mesh.Parent = nil
end
child.Parent = game.Workspace
end
end
end
end
if game.PlaceId == "92604236" then
for i=1,100 do
print(i)
game.ReplicatedStorage.Events.OutfitChang:FireServer("Hat", "158066212")
wait(0.1)
for index, child in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if child.ClassName == "Hat" or child.ClassName == "Accessory" then
if child.Handle:FindFirstChild("Mesh") then
child.Handle.Mesh.Parent = nil
end
child.Parent = game.Workspace
end
end
end
end
end)

btools.Name = "btools"
btools.Parent = Scripts
btools.BackgroundColor3 = Color3.new(0, 0, 0)
btools.BackgroundTransparency = 0.5
btools.Position = UDim2.new(0, 0, 0, 247)
btools.Size = UDim2.new(0, 200, 0, 50)
btools.Font = Enum.Font.SourceSans
btools.FontSize = Enum.FontSize.Size14
btools.Text = "BTools for cafes"
btools.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
btools.TextSize = 14

btools.MouseButton1Down:connect(function()
maind = nil
if workspace:FindFirstChild'GiveSystem' then
 if workspace.GiveSystem:FindFirstChild'GiveItem' then
  maind = workspace.GiveSystem.GiveItem
 end
end
if workspace:FindFirstChild'HandToCentre' then
 if workspace.HandToCentre:FindFirstChild'SendItem' then
  maind = workspace.HandToCentre.SendItem
 end
end
if maind == nil then
 print'could not find give event :('
 return
end
tool = Instance.new'Tool'
me = game:GetService'Players'.LocalPlayer
tool.RequiresHandle = false
tool.TextureId = 'http://www.roblox.com/asset/?id=12223874'
tool.Name = 'ya like jazz?'
tool.Parent = me.Backpack
buttonf = nil
tool.Equipped:connect(function()
 local m = game:GetService'Players'.LocalPlayer:GetMouse()
 m.Icon = 'rbxasset://textures/HammerCursor.png'
 buttonf = m.Button1Down:connect(function()
  if m.Target == nil then return end
  local ob = m.Target
  if ob:IsA'BasePart' or ob:IsA'WedgePart' then
   if ob:IsDescendantOf(me.Character) then return end
   m.Icon = 'rbxasset://textures/HammerOverCursor.png'
   local ex = Instance.new'Explosion'
   ex.BlastRadius = 0
   ex.Position = ob.Position
   ex.Parent = workspace
   maind:FireServer(workspace, ob)
   wait(0.3)
   m.Icon = 'rbxasset://textures/HammerCursor.png'
  end
 end)
end)
tool.Unequipped:connect(function()
 if buttonf ~= nil then
  buttonf:Disconnect()
  buttonf = nil
 end
 local m = game:GetService'Players'.LocalPlayer:GetMouse()
 m.Icon = ''
end)
end)

giantassaxe.Name = "giantassaxe"
giantassaxe.Parent = Scripts
giantassaxe.BackgroundColor3 = Color3.new(0, 0, 0)
giantassaxe.BackgroundTransparency = 0.5
giantassaxe.Position = UDim2.new(0, 0, 0, 298)
giantassaxe.Size = UDim2.new(0, 200, 0, 50)
giantassaxe.Font = Enum.Font.SourceSans
giantassaxe.FontSize = Enum.FontSize.Size14
giantassaxe.Text = "Hammer"
giantassaxe.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
giantassaxe.TextSize = 14

giantassaxe.MouseButton1Down:connect(function()
if game.PlaceId == "647711404" then
--how to hammer 101 this only works for city life--
plr = "LocalPlayer" --player to give tool to


plr = game:GetService'Players'[plr]
game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('meme', '7', '1055299')
lp = game:GetService'Players'.LocalPlayer
hat = lp.Character:WaitForChild'meme'
hammer = hat.GravityHammer
hammer.Parent = lp:FindFirstChildOfClass'Backpack'
--DIRTY HACKS TO PARENT HAT/TOOLS WITH REPLICATION ON FE--
hat.Parent = nil
hammer.Parent = lp.Character
game:GetService'RunService'.Stepped:wait()
hammer.Parent = plr.Character
for i = 1,3 do
local lol = lp:FindFirstChildOfClass'Backpack':FindFirstChildOfClass'HopperBin'
if lol:FindFirstChild'LocalScript' then lol:Destroy() end
end
end

if game.PlaceId == "367959224" then
game.ReplicatedStorage.ClothingService:FireServer("Hat", 001055299)
end

if game.PlaceId == "92604236" then
game.ReplicatedStorage.Events.OutfitChang:FireServer("Hat", "1055299")
end
end)

godxd.Name = "godxd"
godxd.Parent = Scripts
godxd.BackgroundColor3 = Color3.new(0, 0, 0)
godxd.BackgroundTransparency = 0.5
godxd.Position = UDim2.new(0, 0, 0, 349)
godxd.Size = UDim2.new(0, 200, 0, 50)
godxd.Font = Enum.Font.SourceSans
godxd.FontSize = Enum.FontSize.Size14
godxd.Text = "God"
godxd.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
godxd.TextSize = 14

godxd.MouseButton1Down:connect(function()
local player=game.Players.LocalPlayer.Character
player.Humanoid:Remove()
Instance.new('Humanoid',player)
end)

grab.Name = "grab"
grab.Parent = Scripts
grab.BackgroundColor3 = Color3.new(0, 0, 0)
grab.BackgroundTransparency = 0.5
grab.Position = UDim2.new(0, 0, 0, 399)
grab.Size = UDim2.new(0, 200, 0, 50)
grab.Font = Enum.Font.SourceSans
grab.FontSize = Enum.FontSize.Size14
grab.Text = "Grab Knife (City Life)"
grab.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
grab.TextSize = 14
grab.TextScaled = false

grab.MouseButton1Down:connect(function()
-- made by harkinian and moon
-- jk its actually a edit by FroggysFriend#7364 lol
-- fuck off if u think this is skidded :P
-- extremely rare so dont leak :U
me = game.Players.LocalPlayer
char = me.Character
selected = false
attacking = false
hurt = false
grabbed = nil
mode = "drop"
bloodcolors = {"Bright red", "Really red"}


function prop(part, parent, collide, tran, ref, x, y, z, color, anchor, form)
part.Parent = parent
part.formFactor = form
part.CanCollide = collide
part.Transparency = tran
part.Reflectance = ref
part.Size = Vector3.new(x,y,z)
part.BrickColor = BrickColor.new(color)
part.TopSurface = 0
part.BottomSurface = 0
part.Anchored = anchor
part.Locked = true
part:BreakJoints()
end

function weld(w, p, p1, a, b, c, x, y, z)
w.Parent = p
w.Part0 = p
w.Part1 = p1
w.C1 = CFrame.fromEulerAnglesXYZ(a,b,c) * CFrame.new(x,y,z)
end

function mesh(mesh, parent, x, y, z, type)
mesh.Parent = parent
mesh.Scale = Vector3.new(x, y, z)
mesh.MeshType = type
end

function remgui()
	for _,v in pairs(me.PlayerGui:GetChildren()) do
		if v.Name == "Modeshow" then
			v:remove()
		end
	end
end

function inform(text,delay)
	remgui()
	local sc = Instance.new("ScreenGui")
	sc.Parent = me.PlayerGui
	sc.Name = "Modeshow"
	local bak = Instance.new("Frame",sc)
	bak.BackgroundColor3 = Color3.new(1,1,1)
	bak.Size = UDim2.new(0.94,0,0.1,0)
	bak.Position = UDim2.new(0.03,0,0.037,0)
	bak.BorderSizePixel = 0
	local gi = Instance.new("TextLabel",sc)
	gi.Size = UDim2.new(0.92,0,0.09,0)
	gi.BackgroundColor3 = Color3.new(0,0,0)
	gi.Position = UDim2.new(0.04,0,0.042,0)
	gi.TextColor3 = Color3.new(1,1,1)
	gi.FontSize = "Size12"
	gi.Text = text
	coroutine.resume(coroutine.create(function()
		wait(delay)
		sc:remove()
	end))
end

if char:findFirstChild("Bricks",true) then
	char:findFirstChild("Bricks",true):remove()
end

bricks = Instance.new("Model",me.Character)
bricks.Name = "Bricks"

--Parts-------------------------Parts-------------------------Parts-------------------------Parts----------------------

rarm = char:findFirstChild("Right Arm")
larm = char:findFirstChild("Left Arm")
lleg = char:findFirstChild("Left Leg")
torso = char:findFirstChild("Torso")
hum = char:findFirstChild("Humanoid")

righthold = Instance.new("Part")
prop(righthold, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, "Custom")
w11 = Instance.new("Weld")
weld(w11, rarm, righthold, 0, 0, 0, 0, 1, 0)

lefthold = Instance.new("Part")
prop(lefthold, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, "Custom")
w12 = Instance.new("Weld")
weld(w12, larm, lefthold, 0, 0, 0, 0, 1, 0)

hold = Instance.new("Part")
prop(hold, bricks, false, 0, 0, 0.2, 0.4, 0.7, "Black", false, "Custom")
oh = Instance.new("Weld")
weld(oh, lleg, hold, -math.pi/1.4, 0, math.rad(35), 0.55, -0.9, 0.3)

knife = Instance.new("Part")
prop(knife, bricks, false, 0, 0, 0.35, 1.1, 0.5, "Reddish brown", false, "Custom")
orr = Instance.new("Weld")
weld(orr, hold, knife, 0, 0, 0, 0, 0.7, 0)
ar = Instance.new("Weld")
weld(ar, lefthold, nil, math.pi/2, 0, math.pi, 0, 0, 0)


blade = Instance.new("Part")
prop(blade, bricks, false, 0, 0, 0.1, 1.5, 0.4, "Medium grey", false, "Custom")
Instance.new("BlockMesh",blade).Scale = Vector3.new(0.3,1,1)
w2 = Instance.new("Weld")
weld(w2, knife, blade, 0, 0, 0, 0, -1.2, 0)

blade2 = Instance.new("Part")
prop(blade2, bricks, false, 0, 0, 0.1, 0.5, 0.4, "Medium grey", false, "Custom")
local mew = Instance.new("SpecialMesh",blade2)
mew.MeshType = "Wedge"
mew.Scale = Vector3.new(0.3,1,1)
w3 = Instance.new("Weld")
weld(w3, blade, blade2, 0, 0, 0, 0, -1, 0)




rb = Instance.new("Part")
prop(rb, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, "Custom")
w13 = Instance.new("Weld")
weld(w13, torso, rb, 0, 0, 0, -1.5, -0.5, 0)

lb = Instance.new("Part")
prop(lb, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, "Custom")
w14 = Instance.new("Weld")
weld(w14, torso, lb, 0, 0, 0, 1.5, -0.5, 0)

rw = Instance.new("Weld")
weld(rw, rb, nil, 0, 0, 0, 0, 0.5, 0)

lw = Instance.new("Weld")
weld(lw, lb, nil, 0, 0, 0, 0, 0.5, 0)

grabweld = nil
platlol = nil
lolhum = nil

function touch(h)
	if hurt then
		if grabbed == nil then
			local hu = h.Parent:findFirstChild("Humanoid")
			local head = h.Parent:findFirstChild("Head")
			local torz = h.Parent:findFirstChild("Torso")
			if hu ~= nil and head ~= nil and torz ~= nil and h.Parent.Name ~= name then
				if hu.Health > 0 then
				grabbed = torz
				hu.PlatformStand = true
				local w = Instance.new("Weld")
				weld(w,righthold,grabbed,math.pi/2,0.2,0,0.7,-0.9,-0.6)
				grabweld = w
				lolhum = hu
				local lolxd = true
				platlol = lolxd
				hu.Changed:connect(function(prop)
					if prop == "PlatformStand" and platlol then
						hu.PlatformStand = true
					end
				end)
				end
			end
		end
	end
end

righthold.Touched:connect(touch)
lefthold.Touched:connect(touch)

function bleed(part,po)
	local lol1 = math.random(5,30)/100
	local lol2 = math.random(5,30)/100
	local lol3 =math.random(5,30)/100
	local lol4 = math.random(1,#bloodcolors)
	local p = Instance.new("Part")
	prop(p,part.Parent,false,0,0,lol1,lol2,lol3,bloodcolors[lol4],false,"Custom")
	p.CFrame = part.CFrame * CFrame.new(math.random(-5,5)/10,po,math.random(-5,5)/10)
	p.Velocity = Vector3.new(math.random(-190,190)/10,math.random(-190,190)/10,math.random(-190,190)/10)
	p.RotVelocity = Vector3.new(math.random(-400,400)/10,math.random(-400,400)/10,math.random(-400,400)/10)
	coroutine.resume(coroutine.create(function()
		wait(3)
		p:remove()
	end))
end

if script.Parent.className ~= "HopperBin" then
	_G.h = Instance.new("HopperBin",me.Backpack)
	_G.h.Name = "Grab"
	script.Parent = _G.h
end

bin = script.Parent

function select(mouse)
	orr.Part1 = nil
	ar.Part1 = knife
	mouse.Button1Down:connect(function()
		if attacking == false then
			attacking = true
			lw.Part1 = larm
			rw.Part1 = rarm
			hurt = true
			for i=1, 8 do
				rw.C0 = rw.C0 * CFrame.new(-0.03,0,-0.08) * CFrame.fromEulerAnglesXYZ(0.18,0.04,0)
				lw.C0 = lw.C0 * CFrame.new(0.06,0,-0.06) * CFrame.fromEulerAnglesXYZ(0.15,-0.11,-0.05)
				wait()
			end
			wait(1)
			hurt = false
			if grabbed == nil then
				for i=1, 4 do
					rw.C0 = rw.C0 * CFrame.new(0.06,0,0.16) * CFrame.fromEulerAnglesXYZ(-0.36,-0.08,0)
					lw.C0 = lw.C0 * CFrame.new(-0.12,0,0.12) * CFrame.fromEulerAnglesXYZ(-0.3,0.22,0.05)
					wait()
				end
				lw.C0 = CFrame.new(0,0,0)
				rw.C0 = CFrame.new(0,0,0)
				lw.Part1 = nil
				rw.Part1 = nil
				attacking = false
			end
		elseif hurt == false and grabbed ~= nil and mode == "drop" then
			grabweld:remove()
			grabweld = nil
			platlol = false
			grabbed = nil
			lolhum.PlatformStand = false
			lolhum = nil
			for i=1, 4 do
				rw.C0 = rw.C0 * CFrame.new(0.06,0,0.16) * CFrame.fromEulerAnglesXYZ(-0.36,-0.08,0)
				lw.C0 = lw.C0 * CFrame.new(-0.12,0,0.16) * CFrame.fromEulerAnglesXYZ(-0.3,0.2,0)
				wait()
			end
			lw.C0 = CFrame.new(0,0,0)
			rw.C0 = CFrame.new(0,0,0)
			lw.Part1 = nil
			rw.Part1 = nil
			attacking = false
			platlol = nil
		elseif hurt == false and grabbed ~= nil and grabweld ~= nil and mode == "throw" then
			grabweld:remove()
			grabweld = nil
			local bf = Instance.new("BodyForce",grabbed)
			bf.force = torso.CFrame.lookVector * 8500
			bf.force = bf.force + Vector3.new(0,7400,0)
			coroutine.resume(coroutine.create(function()
				wait(0.12)
				bf:remove()
			end))
			for i=1, 6 do
				rw.C0 = rw.C0 * CFrame.new(0,0,0) * CFrame.fromEulerAnglesXYZ(0.35,0,0)
				lw.C0 = lw.C0 * CFrame.new(0,0,0) * CFrame.fromEulerAnglesXYZ(-0.18,0,0)
				wait()
			end
			for i=1, 4 do
				rw.C0 = rw.C0 * CFrame.new(0,0,0) * CFrame.fromEulerAnglesXYZ(-0.47,0,0)
				lw.C0 = lw.C0 * CFrame.new(0,0,0) * CFrame.fromEulerAnglesXYZ(0.2,0,0)
				wait()
			end
			wait(0.2)
			platlol = false
			grabbed = nil
			lolhum.PlatformStand = false
			lolhum = nil
			for i=1, 4 do
				rw.C0 = rw.C0 * CFrame.new(0.06,0,0.16) * CFrame.fromEulerAnglesXYZ(-0.36,-0.08,0)
				lw.C0 = lw.C0 * CFrame.new(-0.12,0,0.16) * CFrame.fromEulerAnglesXYZ(-0.3,0.2,0)
				wait()
			end
			lw.C0 = CFrame.new(0,0,0)
			rw.C0 = CFrame.new(0,0,0)
			lw.Part1 = nil
			rw.Part1 = nil
			attacking = false
			platlol = nil
		elseif hurt == false and grabbed ~= nil and lolhum ~= nil and grabweld ~= nil and mode == "kill" then
			for i=1, 5 do
				lw.C0 = lw.C0 * CFrame.new(0.02,0.12,0.1) * CFrame.fromEulerAnglesXYZ(-0.05,0,-0.03)
				wait()
			end
			local ne = grabbed:findFirstChild("Neck")
			coroutine.resume(coroutine.create(function()
				local duh = grabbed
				local duh2 = grabbed.Parent.Head
				local lolas = lolhum
				duh.RotVelocity = Vector3.new(math.random(-20,20),math.random(-20,20),math.random(-20,20))
				for i=1, 60 do
					wait()
					local hm = math.random(1,9)
					pcall(function()
						if hm == 1 then
							duh2.Sound.Pitch = math.random(90,110)/100
							duh2.Sound:play()
						end
					end)
					if hm > 0 and hm < 3 then
						bleed(duh,1)
						bleed(duh2,-0.5)
					end
				end
                                                                        kill(lolas.Parent.Name)
Wait(5)
                                                                       _G.h:Remove()
				for i=1, 85 do
					wait()
					local hm = math.random(1,9)
					pcall(function()
						if hm == 1 then
							duh2.Sound.Pitch = math.random(90,110)/100
							duh2.Sound:play()
						end
					end)
					if hm > 0 and hm < 3 then
						bleed(duh,1)
						bleed(duh2,-0.5)
					end
				end
			end))
			for i=1, 3 do
				lw.C0 = lw.C0 * CFrame.new(0.02,0.12,0.1) * CFrame.fromEulerAnglesXYZ(-0.05,0,-0.03)
				if ne ~= nil then
					grabbed.Neck.C0 = grabbed.Neck.C0 * CFrame.fromEulerAnglesXYZ(-0.35,0,0)
				end
				wait()
			end
			grabweld:remove()
			grabweld = nil
			for i=1, 4 do
				lw.C0 = lw.C0 * CFrame.new(-0.04,-0.24,-0.2) * CFrame.fromEulerAnglesXYZ(0.1,0,0.06)
				wait()
			end
			for i=1, 4 do
				rw.C0 = rw.C0 * CFrame.new(0.06,0,0.16) * CFrame.fromEulerAnglesXYZ(-0.36,-0.08,0)
				lw.C0 = lw.C0 * CFrame.new(-0.12,0,0.12) * CFrame.fromEulerAnglesXYZ(-0.3,0.22,0.05)
				wait()
			end
			lw.C0 = CFrame.new(0,0,0)
			rw.C0 = CFrame.new(0,0,0)
			lw.Part1 = nil
			rw.Part1 = nil
			platlol = false
			grabbed = nil
			lolhum = nil
			attacking = false
			platlol = nil
		end
	end)
	mouse.KeyDown:connect(function(kai)
		key = kai:lower()
		if key == "q" then
			mode = "drop"
			inform("Mode: Drop",2)
		elseif key == "e" then
			mode = "throw"
			inform("Mode: Throw",2)
		elseif key == "f" then
			mode = "kill"
			inform("Mode: Kill",2)
		end
	end)
end

function desel()
	repeat wait() until attacking == false
	orr.Part1 = knife
	ar.Part1 = nil
end

bin.Selected:connect(select)
bin.Deselected:connect(desel)

char.Humanoid.Died:connect(function()
	pcall(function()
		grabweld:remove()
		grabweld = nil
		grabbed = nil
		platlol = false
		platlol = nil
	end)
end)

inform("Grab script loaded succesfully.",2)

local grabknife = h
function kill(plrtokill)
--boom--
assets = {540034631, 178993946, 461493477, 110288809}
me = game:GetService'Players'.LocalPlayer.Character:FindFirstChildOfClass'Humanoid'
for i,v in pairs(me.Parent:GetChildren()) do
if v:IsA'Accoutrement' then v.Parent = nil end
end
for i,v in pairs(assets) do
  game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('xdd', tostring(game:GetService'MarketplaceService':GetProductInfo(v).AssetTypeId), v)
end
game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('boom', '8', '1527622')
game.Players.LocalPlayer.Character.boom.BootScript.Parent=workspace[plrtokill]
print(workspace[plrtokill] .. " has been killed")

end
game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('meme', '8', '1527622')
lp = game:GetService'Players'.LocalPlayer
hat = lp.Character:WaitForChild'meme'
hat.Handle.Transparency=1
hat.Handle.Mesh:Remove()
--DIRTY HACKS TO PARENT HAT/TOOLS WITH REPLICATION ON FE--
game:GetService'RunService'.Stepped:wait()
grabknife.Parent = plr.Character
for i = 1,3 do
local lol = lp:FindFirstChildOfClass'Backpack':FindFirstChildOfClass'HopperBin'
if lol:FindFirstChild'LocalScript' then lol:Destroy() end
end
-- made by harkinian!!
end)

raep.Name = "raep"
raep.Parent = Scripts
raep.BackgroundColor3 = Color3.new(0, 0, 0)
raep.BackgroundTransparency = 0.5
raep.Position = UDim2.new(0, 0, 0, 450)
raep.Size = UDim2.new(0, 200, 0, 50)
raep.Font = Enum.Font.SourceSans
raep.FontSize = Enum.FontSize.Size14
raep.Text = "Rape"
raep.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
raep.TextSize = 14

raep.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton.Text = "Rape"
end)

kill.Name = "kill"
kill.Parent = Scripts
kill.BackgroundColor3 = Color3.new(0, 0, 0)
kill.BackgroundTransparency = 0.5
kill.Position = UDim2.new(0, 0, 0, 500)
kill.Size = UDim2.new(0, 200, 0, 50)
kill.Font = Enum.Font.SourceSans
kill.FontSize = Enum.FontSize.Size14
kill.Text = "Kill (tools needed)"
kill.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
kill.TextSize = 14

kill.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton.Text = "Kill"
end)

topqueque.Name = "topqueque"
topqueque.Parent = Scripts
topqueque.BackgroundColor3 = Color3.new(0, 0, 0)
topqueque.BackgroundTransparency = 0.5
topqueque.Position = UDim2.new(0, 0, 0, 551)
topqueque.Size = UDim2.new(0, 200, 0, 50)
topqueque.Font = Enum.Font.SourceSans
topqueque.FontSize = Enum.FontSize.Size14
topqueque.Text = "Topk3k"
topqueque.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
topqueque.TextScaled = false
topqueque.TextSize = 14
topqueque.TextWrapped = true

topqueque.MouseButton1Down:connect(function()
-- fixed for intriga by syndicate
local topkek = {}
topkek.patch = '1.0.5a'
topkek.data = {}
topkek.commandbase = {}
topkek.navigation = {}
topkek.banmgr = {}
topkek.lplr = game:GetService('Players').LocalPlayer

topkek.tools = {}
topkek.tools.gui = {}
topkek.tools.util = {}
topkek.tools.animator = {}

topkek.windows = {}
topkek.windows.lplr = {}
topkek.windows.server = {}
topkek.windows.players = {}
topkek.windows.destruction = {}
topkek.windows.scripts = {}
topkek.windows.misc = {}

topkek.misc = {}

topkek.gui = game:GetObjects("rbxassetid://1250386349")[1] 
topkek.gui.Parent = game:GetService("CoreGui")

topkek.center = topkek.gui.Main
topkek.holder = topkek.center.Holder
topkek.topbar = topkek.center.Topbar
topkek.template = topkek.holder.Template
topkek.navigator = topkek.center.Navigation

AllowHovers = false
PlayerChatHook, UpdateBanlist = nil
cmd = {}

--// data //--
topkek.data.windows = {
	'Home',
	'LocalPlayer',
	'Server',
	'Players',
	'Destruction',
	'Scripts',
	'Catalog',
	'Music',
	'Hats',
	'Faces',
	'Settings',
	'Commands',
	'Banlist',
}

color3 = function(r,g,b)
	return Color3.new(r/255, g/255, b/255)
end
--// doggo dropdown //--
-- thanks krystal
GUI = {
	TextBox = {
		Settings = {
			Font = Enum.Font.SourceSans;
			FontSize = Enum.FontSize.Size14;
		};
		Color = {
			Main = Color3.fromRGB(5,8,11);
			Border = Color3.fromRGB(27,42,53);
			Text = Color3.fromRGB(199,199,199);
		};
		New = function(Position, Size, Parent, ...)
			local arguments = {...};
			
			local TextBox = Instance.new("TextBox", Parent);
			TextBox.BackgroundColor3 = GUI.DropDown.Color.Main;
			TextBox.BorderColor3 = GUI.DropDown.Color.Border;
			TextBox.Font = GUI.TextBox.Settings.Font;
			TextBox.FontSize = GUI.TextBox.Settings.FontSize;
			TextBox.TextColor3 = GUI.TextBox.Color.Text;
			TextBox.Position = Position;
			TextBox.Size = Size;
			if #arguments then
				if arguments[1] then
					TextBox.Text = tostring(arguments[1]);
				else
					TextBox.Text = "";
				end	
			end		
			return TextBox;
		end;
	};
	DropDown = {
		Settings = {
			ScrollerAmount = 5; --A scroller will appear at this amount.
			ScrollBarThickness = 6;
		};
		Gfx = {
			Scroller = "rbxassetid://606572419";
		};
		Color = {
			Main = color3(36, 36, 107);
			Secondary = color3(39, 39, 113);
			Border = color3(44, 44, 127);
			Text = Color3.fromRGB(199,199,199);
		};
		New = function(Position, Size, Parent, ...)
			local vValue = {};
			local arguments = {...};
			local vSelected = Instance.new("StringValue");
			vSelected.Value = "nil";
			
			if arguments then
				if type(arguments) == "table" then
					for i=1,#(arguments) do
						if type(arguments[i]) == "table" then
							for f=1,#(arguments[i]) do
								table.insert(vValue, tostring((arguments[i])[f]));
							end
						else
							table.insert(vValue, tostring(arguments[i]));
						end
					end
					vSelected.Value = (vValue[1]);
				end
			end
			
			local Main = Instance.new("TextButton", Parent);
			Main.BackgroundColor3 = GUI.DropDown.Color.Main;
			Main.BorderColor3 = GUI.DropDown.Color.Border;
			Main.Position = Position;
			Main.Size = Size;
			Main.TextColor3 = GUI.DropDown.Color.Text;
			Main.FontSize = Enum.FontSize.Size14;
			Main.TextStrokeTransparency = 0.5;
			Main.TextXAlignment = Enum.TextXAlignment.Left;
			Main.Font = Enum.Font.SourceSans;
			Main.Text = "  "..tostring(vSelected.Value);
			Main.ZIndex = 3
			
			local Icon = Instance.new("TextLabel", Main);
			Icon.SizeConstraint = Enum.SizeConstraint.RelativeYY;
			Icon.BackgroundColor3 = GUI.DropDown.Color.Secondary;
			Icon.BorderColor3 = GUI.DropDown.Color.Border;
			Icon.Position = UDim2.new(1,-2,1,-2);
			Icon.Size = UDim2.new(-1,4,-1,4);
			Icon.TextColor3 = GUI.DropDown.Color.Text;
			Icon.FontSize = Enum.FontSize.Size14;
			Icon.TextStrokeTransparency = 0.5;
			Icon.Font = Enum.Font.SourceSans;
			Icon.Text = "V"
			Icon.ZIndex = 4

			local Holder, Search;
			local ClearHolder = function()
				if Holder then
					Holder:ClearAllChildren();
					Holder.Size = UDim2.new(1,0,0,0);
					Holder.Visible = false;
					if Search then
						Search.Visible = false;
					end
				end
			end;
			
			local CreateButton;
			local RefreshDropDown = function()
				if #vValue <= (GUI.DropDown.Settings.ScrollerAmount) then
					if not Holder or not Holder:IsA("Frame") then
						Holder = nil; Search = nil;
						Holder = Instance.new("Frame",Main);
						Holder.Size = UDim2.new(1,0,0,0);
						Holder.BackgroundColor3 = GUI.DropDown.Color.Main;
						Holder.BorderColor3 = GUI.DropDown.Color.Border;
						Holder.Visible = false;
						Holder.ZIndex = 3
					end
				elseif #vValue > (GUI.DropDown.Settings.ScrollerAmount) then
					if not Holder or not Holder:IsA("ScrollingFrame") then
						Holder = nil; Search = nil;
						Search = GUI.TextBox.New(UDim2.new(0,0,0,0),UDim2.new(1,0,0,Main.AbsoluteSize.Y),Main);
						Search.Visible = false;
						Search.ZIndex = 4
						Search.Changed:connect(function(p)
							if p == "Text" then
								CreateButton(Search.Text);
							end
						end)
						Holder = Instance.new("ScrollingFrame",Main);
						Holder.BackgroundColor3 = GUI.DropDown.Color.Main;
						Holder.BorderColor3 = GUI.DropDown.Color.Border;
						Holder.TopImage = GUI.DropDown.Gfx.Scroller;
						Holder.MidImage = GUI.DropDown.Gfx.Scroller;
						Holder.BottomImage = GUI.DropDown.Gfx.Scroller;
						Holder.Size = UDim2.new(1,0,0,Main.AbsoluteSize.Y * (GUI.DropDown.Settings.ScrollerAmount-1));
						Holder.Position = UDim2.new(0,0,0,Main.AbsoluteSize.Y)
						Holder.ScrollBarThickness = GUI.DropDown.Settings.ScrollBarThickness;
						Holder.Visible = false;
						Holder.ZIndex = 3;
					end
				end
				if #vValue == 1 and vSelected.Value ~= vValue[1] then
					vSelected.Value = vValue[1];
				elseif #vValue == 0 then
					vSelected.Value = "nil";
					warn("Table amount is nil.");
				end
				Main.Text = "  "..tostring(vSelected.Value);
				--ClearHolder();
			end;
			
			local Debounce = false;
			CreateButton = function(searches)
				if Debounce == false then
					Debounce = true;
					ClearHolder()
					Holder.Visible = true;
					local Searched = 0;
					if #vValue > 0 then
						for i=1,#vValue do
							if (searches ~= nil and string.find(string.lower(vValue[i]), string.lower(searches)) and searches ~= "") then
								Searched = Searched + 1;
							end
						end
						for i=1,#vValue do
							if (searches ~= nil and string.find(string.lower(vValue[i]), string.lower(searches)) and searches ~= "" and Searched > 0) or searches == nil or searches == "" or Searched <= 0 then
								local Select = Instance.new("TextButton", Holder);
								Select.BackgroundColor3 = GUI.DropDown.Color.Main;
								Select.BorderColor3 = GUI.DropDown.Color.Border;
								Select.BackgroundTransparency = 1;
								Select.BorderSizePixel = 0;
								Select.Position = Position;
								if #vValue <= (GUI.DropDown.Settings.ScrollerAmount) then
									Select.Size = UDim2.new(1,0,0,Main.AbsoluteSize.Y);
								else
									Select.Size = UDim2.new(1,-(GUI.DropDown.Settings.ScrollBarThickness),0,Main.AbsoluteSize.Y);
								end
								Select.Position = UDim2.new(0,0,0,(Main.AbsoluteSize.Y) * (#Holder:GetChildren() - 1)) 
								Select.TextColor3 = GUI.DropDown.Color.Text;
								Select.FontSize = Enum.FontSize.Size14;
								Select.TextStrokeTransparency = 0.5;
								Select.Font = Enum.Font.SourceSans;
								Select.Text = tostring(vValue[i]);
								Select.ZIndex = 3
								Select.MouseButton1Click:connect(function()
									vSelected.Value = vValue[i];
									ClearHolder();
									RefreshDropDown();
								end)
								if  #vValue <= (GUI.DropDown.Settings.ScrollerAmount) then
									Holder.Size = UDim2.new(1,0,0,Main.AbsoluteSize.Y * i);
								elseif Holder:IsA("ScrollingFrame") then
									Search.Visible = true;
									if #Holder:GetChildren() >= 1 then
										Holder.CanvasSize = UDim2.new(1,0,0,Main.AbsoluteSize.Y * #Holder:GetChildren());
										Holder.Size = UDim2.new(1,0,0,Main.AbsoluteSize.Y * #Holder:GetChildren());--GUI.DropDown.Settings.ScrollerAmount);
										if #Holder:GetChildren() >= GUI.DropDown.Settings.ScrollerAmount then
											Holder.Size = UDim2.new(1,0,0,Main.AbsoluteSize.Y * GUI.DropDown.Settings.ScrollerAmount);
											Holder.CanvasSize = UDim2.new(1,0,0,Main.AbsoluteSize.Y * #Holder:GetChildren());
										end
									elseif #Holder:GetChildren() < 1 then
										Holder.CanvasSize = UDim2.new(1,0,0,Main.AbsoluteSize.Y * 1);
										Holder.Size = UDim2.new(1,0,0,Main.AbsoluteSize.Y * 1);
									end
								end
							end
						end
					end
					Debounce = false;
				end
			end;
			
			RefreshDropDown();

			Main.MouseButton1Click:connect(function()
				CreateButton()
				if #vValue >= GUI.DropDown.Settings.ScrollerAmount and Search ~= nil then
					Search:CaptureFocus();
					Search.Text = "";
				end
			end)
			
			topkek.lplr:GetMouse().Button1Down:connect(function()
				ClearHolder()
			end)

			return {
				Update = function()
					RefreshDropDown();
				end;
				GetValue = function()
					RefreshDropDown();
					return vValue;
				end;
				GetSelected = function()
					RefreshDropDown();
					return vSelected.Value;
				end;
				SetTable = function(F)
					vValue = F;
					RefreshDropDown(); 
				end;
				Changed = function(F)
					vSelected.Changed:connect(function()
						ypcall(function() 
							F(vSelected.Value);
						end)
					end)
					return "ChangedEvent Hooked";
				end;
				AddValue = function(obj)
					local Type = type(obj);
					if Type == "table" then
						for i=1,#obj do
							table.insert(vValue, obj[i])
						end
					elseif Type == "string" or Type == "number" or Type == "boolean" then
						table.insert(vValue, obj)
					end
					RefreshDropDown();
				end;
				RemoveValue = function(obj)
					local Type = type(obj);
					if Type == "table" then
						for i=1,#vValue do
							for f=1,#obj do
								if tostring(obj[f]) == tostring(vValue[i]) then
									table.remove(vValue,i)
								end
							end
						end
					else
						for i=1,#vValue do
							if tostring(obj) == tostring(vValue[i]) then
								table.remove(vValue,i)
							end
						end
					end
					RefreshDropDown();
				end;
				ClearValue = function()
					vValue = {};
					RefreshDropDown();
				end;
			}
		end;
	};
};
--// util //--
function topkek.tools.util.Object(o, p)
	local a, b = pcall(function()
		Instance.new(o)
	end)
	if not a then
		return
	end
	local obj = Instance.new(o)
	for prop, val in pairs(p) do
		pcall(function()
			obj[prop] = val 
		end)
	end
	return obj
end

function topkek.tools.util.getContainer(n)
	if topkek.holder:FindFirstChild(n) then
		return topkek.holder[n]
	else
		print("menu not found; returning template")
		return topkek.holder['Template']
	end
end

function topkek.tools.util.play(id)
	local mu = Instance.new("Sound", game:GetService('Workspace'))
	mu.Volume = 1
	mu.Looped = true
	mu.Pitch = 1
	mu.SoundId = "rbxassetid://"..tostring(id)
	mu:Play()
end

function topkek.tools.util.getTorso(plr) --r15 compatibility lole
	if plr.Character then
		if plr.Character:FindFirstChild('UpperTorso') then
			return plr.Character.UpperTorso
		elseif plr.Character:FindFirstChild('Torso') then
			return plr.Character.Torso
		else
			return nil
		end
	end
end

function topkek.tools.util.recurseRemove(x,type_)
	local function recurse(x)
		for i, v in pairs(x:GetChildren()) do
			pcall(function()
				if v:IsA(type_) then
					v:Destroy()
				end
				if #(v:GetChildren())>0 then
					recurse(v)
				end
			end)
		end
	end
	recurse(x)
end

function topkek.tools.util.recurseFunc(type_,func)
	local function recurse(x)
		for i, v in pairs(x:GetChildren()) do
			pcall(function()
				if v:IsA(type_) then
					func(v)
				end
				if #(v:GetChildren())>0 then
					recurse(v)
				end
			end)
		end
	end
	recurse(game)
end
function topkek.tools.util.trowel()
	local T = Instance.new('Tool', game.Players.LocalPlayer.Backpack)
	T.Name = 'Custom Trowel'
	
	local p = Instance.new('Part')
	p.Name = 'Handle'
	p.Size = Vector3.new(1,4.4,1)
	p.Parent = T
	
	local specialMesh = Instance.new('SpecialMesh')
	specialMesh.MeshId = 'rbxasset://fonts/trowel.mesh'
	specialMesh.MeshType = 'FileMesh'
	specialMesh.TextureId = 'rbxasset://textures/TrowelTexture.png'
	specialMesh.Parent = T.Handle
	
	local sound = Instance.new'Sound'
	sound.Name = 'build'
	sound.SoundId = 'rbxasset://sounds//bass.wav'
	sound.Volume = 1
	sound.Parent = T.Handle
	 
	local brickHeight = 100
	local trowelSpeed = 0.05
	local brickWidth = 500
	local mouseConnection
	 
	function newBrick(CF, P, color)
	 local brick = Instance.new('Part')
	 brick.BrickColor = color
	 brick.CFrame = CF * CFrame.new(P + brick.Size / 2)
	 brick.Parent = game.Workspace
	 brick:MakeJoints()
	 brick.Material = 'Neon'
	 brick.Name = 'DeleteMe'
	 return  brick, P + brick.Size
	end
	 
	function genBrick(cFrame)
	 local randBrickColor = BrickColor.Random()
	 assert(brickWidth > 0)
	 
	 local yPos = 0
	 
	 while yPos < brickHeight do
	  local vPos
	  local X = -brickWidth / 2
	  while X < brickWidth / 2 do
	   local brick
	   brick, vPos = newBrick(cFrame, Vector3.new(X, yPos, 0), randBrickColor)
	   X = vPos.x
	   wait(trowelSpeed)
	  end
	  yPos = vPos.y
	 end
	end
	 
	function calcPos(vec)
	 if (math.abs(vec.x) > math.abs(vec.z)) then
	  if vec.x > 0 then
	   return Vector3.new(1, 0, 0)
	  else
	   return Vector3.new(-1, 0, 0)
	  end
	 else
	  if (vec.z > 0) then
	   return Vector3.new(0, 0, 1)
	  else
	   return Vector3.new(0, 0, -1)
	  end
	 end
	end
	 
	T.Enabled = true
	
	T.Activated:connect(function()
	 if T.Enabled and game.Players.LocalPlayer.Character:FindFirstChild('Humanoid') then
	  T.Enabled = false
	  T.Handle.build:Play()
	  genBrick(CFrame.new(game.Players.LocalPlayer.Character.Humanoid.TargetPoint, game.Players.LocalPlayer.Character.Humanoid.TargetPoint + calcPos((game.Players.LocalPlayer.Character.Humanoid.TargetPoint - game.Players.LocalPlayer.Character.Head.Position).unit)))
	  T.Enabled = true
	 end
	end)
	
	T.Equipped:connect(function()
	 mouseConnection = game.Players.LocalPlayer:GetMouse().KeyDown:connect(function(key)
	  if (key == 'r') then
	   for i,v in next, workspace:children'' do
	    if (v.Name == 'DeleteMe') then
	     v:Destroy()
	    end
	   end
	  end
	 end)
	end)
	
	T.Unequipped:connect(function()
	 mouseConnection:disconnect()
	end)
end
function topkek.tools.util.recurseSet(type_,prop,val)
	local function recurse(x)
		for i, v in pairs(x:GetChildren()) do
			pcall(function()
				if v:IsA(type_) then
					v[prop]=val
				end
				if #(v:GetChildren())>0 then
					recurse(v)
				end
			end)
		end
	end
	recurse(game)
end
function topkek.tools.util.recurseUltimate(d)
	topkek.tools.util.recurseDecal(d)
	topkek.tools.util.recurseParticles(d)
end
function topkek.tools.util.recurseDecal(img)
	img = 'rbxassetid://' .. img
	local function skybox(x)
		local sky = Instance.new("Sky",game.Lighting)
		local fcs={"Bk","Dn","Ft","Lf","Rt","Up"}
		for i,v in pairs(fcs) do
			sky["Skybox"..v]=x
		end
	end
	
	local function decal(p, b)
		local sides = {"Back", "Bottom", "Front", "Left", "Right", "Top"}
		for i, v in pairs(sides) do
			local a = Instance.new("Decal", p)
			a.Texture = b
			a.Face = v
		end
	end
			
	local function recurse(x)
		for i, v in pairs(x:GetChildren()) do
			pcall(function() -- 'error occured, no output from Lua' LOLE
				if v:IsA("BasePart") then
					decal(v, img)
				end
				if #(v:GetChildren())>0 then
					recurse(v)
				end
			end)
		end
	end
			
	recurse(game)
	skybox(img)
end
function topkek.tools.util.recurseParticles(img)--topkek2.0 code tbh
	img = 'rbxassetid://' .. img
	local function skybox(x)
		local sky = Instance.new("Sky",game.Lighting)
		local fcs={"Bk","Dn","Ft","Lf","Rt","Up"}
		for i,v in pairs(fcs) do
			sky["Skybox"..v]=x
		end
	end
	local function particle(p, b)
		local a = Instance.new("ParticleEmitter", p)
		a.Rate = 500
		a.Lifetime = NumberRange.new(20, 30)
		a.VelocitySpread = 200
		a.Texture = b
	end
			
	local function recurse(x)
		for i, v in pairs(x:GetChildren()) do
			pcall(function() -- 'error occured, no output from Lua' LOLE
				if v:IsA("BasePart") then
					particle(v, img)
				end
				if #(v:GetChildren())>0 then
					recurse(v)
				end
			end)
		end
	end
			
	recurse(game)
	skybox(img)
end
function topkek.tools.util.recurseSetObj(obj,type_,prop,val)
	local function recurse(x)
		for i, v in pairs(x:GetChildren()) do
			pcall(function()
				if v:IsA(type_) then
					v[prop]=val
				end
				if #(v:GetChildren())>0 then
					recurse(v)
				end
			end)
		end
	end
	recurse(obj)
end
function topkek.tools.util.doPlayers(cval, func)
	local plrs = {}
	if cval == 'All' then
		plrs = game:GetService('Players'):GetPlayers()
	else
		plrs = {game:GetService('Players'):FindFirstChild(cval)}
	end
	for i, v in pairs(plrs) do
		func(v)
	end
end
function topkek.tools.util.scalePlayer(sc,plr)
	local pchar = plr.Character
	if pchar:FindFirstChild("UpperTorso") then
		warn("Player [" ..plr.Name.. "] is R15.")
		return
	end
	local function scale(chr,scl)
	
		for _,v in pairs(pchar:GetChildren()) do
			if v:IsA("Hat") then
				v:Clone()
				v.Parent = game.Lighting
			end
		end
			
	    local Head = chr['Head']
	    local Torso = chr['Torso']
	    local LA = chr['Left Arm']
	    local RA = chr['Right Arm']
	    local LL = chr['Left Leg']
	    local RL = chr['Right Leg']
	    local HRP = chr['HumanoidRootPart']
	
	    wait(0.1)
	   
	    Head.formFactor = 3
	    Torso.formFactor = 3
	    LA.formFactor = 3
	    RA.formFactor = 3
	    LL.formFactor = 3
	    RL.formFactor = 3
	    HRP.formFactor = 3
	    
	    Head.Size = Vector3.new(scl * 2, scl, scl)
	    Torso.Size = Vector3.new(scl * 2, scl * 2, scl)
	    LA.Size = Vector3.new(scl, scl * 2, scl)
	    RA.Size = Vector3.new(scl, scl * 2, scl)
	    LL.Size = Vector3.new(scl, scl * 2, scl)
	    RL.Size = Vector3.new(scl, scl * 2, scl)
	    HRP.Size = Vector3.new(scl * 2, scl * 2, scl)
	    
	    local Motor1 = Instance.new('Motor6D', Torso)
	    Motor1.Part0 = Torso
	    Motor1.Part1 = Head
    	Motor1.C0 = CFrame.new(0, 1 * scl, 0) * CFrame.Angles(-1.6, 0, 3.1)
    	Motor1.C1 = CFrame.new(0, -0.5 * scl, 0) * CFrame.Angles(-1.6, 0, 3.1)
    	Motor1.Name = "Neck"
			    
    	local Motor2 = Instance.new('Motor6D', Torso)
    	Motor2.Part0 = Torso
    	Motor2.Part1 = LA
    	Motor2.C0 = CFrame.new(-1 * scl, 0.5 * scl, 0) * CFrame.Angles(0, -1.6, 0)
    	Motor2.C1 = CFrame.new(0.5 * scl, 0.5 * scl, 0) * CFrame.Angles(0, -1.6, 0)
    	Motor2.Name = "Left Shoulder"
    	
    	local Motor3 = Instance.new('Motor6D', Torso)
   		Motor3.Part0 = Torso
    	Motor3.Part1 = RA
    	Motor3.C0 = CFrame.new(1 * scl, 0.5 * scl, 0) * CFrame.Angles(0, 1.6, 0)
    	Motor3.C1 = CFrame.new(-0.5 * scl, 0.5 * scl, 0) * CFrame.Angles(0, 1.6, 0)
    	Motor3.Name = "Right Shoulder"
    	
    	local Motor4 = Instance.new('Motor6D', Torso)
    	Motor4.Part0 = Torso
    	Motor4.Part1 = LL
    	Motor4.C0 = CFrame.new(-1 * scl, -1 * scl, 0) * CFrame.Angles(0, -1.6, 0)
    	Motor4.C1 = CFrame.new(-0.5 * scl, 1 * scl, 0) * CFrame.Angles(0, -1.6, 0)
    	Motor4.Name = "Left Hip"
    	
    	local Motor5 = Instance.new('Motor6D', Torso)
    	Motor5.Part0 = Torso
    	Motor5.Part1 = RL
    	Motor5.C0 = CFrame.new(1 * scl, -1 * scl, 0) * CFrame.Angles(0, 1.6, 0)
    	Motor5.C1 = CFrame.new(0.5 * scl, 1 * scl, 0) * CFrame.Angles(0, 1.6, 0)
    	Motor5.Name = "Right Hip"
    	
    	local Motor6 = Instance.new('Motor6D', HRP)
    	Motor6.Part0 = HRP
    	Motor6.Part1 = Torso
    	Motor6.C0 = CFrame.new(0, 0, 0) * CFrame.Angles(-1.6, 0, -3.1)
    	Motor6.C1 = CFrame.new(0, 0, 0) * CFrame.Angles(-1.6, 0, -3.1)
    	    
	end
	
	scale(pchar, sc)
	
	for _,v in pairs(game.Lighting:GetChildren()) do
		if v:IsA("Hat") then
			v.Parent = pchar
		end
	end
end
function topkek.tools.util.applyFace(id)
	local Char = topkek.lplr.Character
	if(Char)then
		local Type = id
		local Meme=id
		local BBG_SIZE=Char.Head.Size.X*1.25;
		local STUD_VECTOR_1=Char.Head.Size.Z/4;
		local STUD_VECTOR_2=Char.Head.Size.Z;
		local bbg=Char:FindFirstChild'BBGMEME'or Instance.new('BillboardGui',Char);
			bbg.StudsOffset=Vector3.new(0,STUD_VECTOR_1,STUD_VECTOR_2);
			bbg.Size=UDim2.new(BBG_SIZE,0,BBG_SIZE);
			bbg.Adornee=Char.Head;
			bbg.Name='BBGMEME';
		local img=bbg:FindFirstChild'Meme'or Instance.new('ImageLabel',bbg);
			img.BackgroundTransparency=1;
			img.Image="rbxassetid://"..Meme;
			img.Size=UDim2.new(1,0,1,0)
			img.Name='Meme';
		for i,v in next,Char:children()do
			if(v.className=='Hat')then
				v=v:FindFirstChild'Handle';
				if(v)then
					v.Transparency=0
				end;
			end;
		end;
	end;
end;
function topkek.tools.util.weenieHutJunior(plr)
	plr=plr.Character
	Shaft=Instance.new("Part", plr)
	Shaft.Name='Shaft'
	Shaft.Size=Vector3.new(1, 2.5, 1)
	Shaft.TopSurface=0
	Shaft.BottomSurface=0
	Shaft.CanCollide=true
	Cyln=Instance.new("CylinderMesh", Shaft)
	Cyln.Scale=Vector3.new(0.5,0.7,0.5)
	Instance.new("Weld", plr)
	plr.Weld.Part0=plr:FindFirstChild("Torso") or plr:FindFirstChild("LowerTorso")
	plr.Weld.Part1=plr.Shaft 
	plr.Weld.C0=CFrame.new(0,-0.35,-0.9)*CFrame.fromEulerAnglesXYZ(2.2,0,0) 
	Shaft.BrickColor=BrickColor.new("Pastel brown")
	Tip=Instance.new("Part", plr)
	Tip.Name='Tip'
	Tip.TopSurface=0
	Tip.BottomSurface=0
	Tip.Size=Vector3.new(1, 1, 1)
	Tip.CanCollide=true
	Tip.Touched:connect(function(prt) if prt.Parent~=player then spawn(function() for i=1, 5 do local pert=Instance.new("Part", player) pert.CFrame=CFrame.new(prt.Position) pert.CanCollide=true local mesh=Instance.new("BlockMesh", pert) mesh.Scale=Vector3.new(0.2,0.2,0.2) pert.BrickColor=BrickColor.new("White") end end) end end)
	Cyln2=Instance.new("SpecialMesh", Tip)
	Cyln2.MeshType='Sphere'
	Cyln2.Scale=Vector3.new(0.6,0.6,0.6)
	Instance.new("Weld", plr).Name='Weld2'
	plr.Weld2.Part0=plr.Shaft
	plr.Weld2.Part1=plr.Tip 
	plr.Weld2.C0=CFrame.new(0,-.9,0)
	Tip.BrickColor=BrickColor.new("Pink")
	-----
	Ball1=Instance.new("Part", plr)
	Ball1.Name='Ball1'
	Ball1.Size=Vector3.new(1, 1, 1)
	Ball1.TopSurface=0
	Ball1.BottomSurface=0
	Cyln3=Instance.new("SpecialMesh", Ball1)
	Cyln3.MeshType='Sphere'
	Cyln3.Scale=Vector3.new(0.4,0.4,0.4)
	Instance.new("Weld", plr).Name='Weld3'
	plr.Weld3.Part0=plr.Shaft
	plr.Weld3.Part1=plr.Ball1 
	plr.Weld3.C0=CFrame.new(0.225,.4,0.2)
	Ball1.BrickColor=BrickColor.new("Pastel brown")
	-----
	Ball2=Instance.new("Part", plr)
	Ball2.Name='Ball2'
	Ball2.Size=Vector3.new(1, 1, 1)
	Ball2.TopSurface=0
	Ball2.BottomSurface=0
	Cyln3=Instance.new("SpecialMesh", Ball2)
	Cyln3.MeshType='Sphere'
	Cyln3.Scale=Vector3.new(0.4,0.4,0.4)
	Instance.new("Weld", plr).Name='Weld4'
	plr.Weld4.Part0=plr.Shaft
	plr.Weld4.Part1=plr.Ball2 
	plr.Weld4.C0=CFrame.new(-0.225,.4,0.2)
	Ball2.BrickColor=BrickColor.new("Pastel brown")
end
--// banmgr //--
topkek.banmgr.isPrivate = false
topkek.banmgr.whitelist = {}
topkek.banmgr.bans = {}
function topkek.banmgr.executeKick(z)
	local function doKick()
        if z.Character and z.Character:FindFirstChild('HumanoidRootPart') and z.Character:FindFirstChild('Torso') then
            z.Character.HumanoidRootPart.CFrame = CFrame.new(math.random(999000, 1001000), 1000000, 1000000)
            local SP = Instance.new('SkateboardPlatform', z.Character) SP.Position = z.Character.HumanoidRootPart.Position SP.Transparency = 1
            spawn(function()
                repeat wait()
                    if z.Character and z.Character:FindFirstChild('HumanoidRootPart') then
                        SP.Position = z.Character.HumanoidRootPart.Position
                    end
                until not game:GetService('Players'):FindFirstChild(z.Name)
            end)
            z.Character.Torso.Anchored = true
        end
	end
	repeat
		doKick()
		wait()
	until not z
end
function topkek.banmgr.loadFromFile()
	-- todo: read file
	topkek.settings.get()
	topkek.banmgr.bans = topkek.settingsTable['Bans']
end
function topkek.banmgr.addHardBan(p)
	-- todo: write file
	table.insert(topkek.banmgr.bans, p.Name)
	topkek.settings.get()
	table.insert(topkek.settingsTable['Bans'], p.Name)
	topkek.settings.write()
	print("Hardbanned " .. p.Name)
	UpdateBanlist()
	topkek.banmgr.executeKick(p)
	topkek.banmgr.loadFromFile()
end
function topkek.banmgr.addSoftBan(p)
	table.insert(topkek.banmgr.bans, p.Name)
	topkek.banmgr.executeKick(p)
end
function topkek.banmgr.plrBanned(p)
	for x, m in pairs(topkek.banmgr.bans) do
		if m == p.Name then
			return true
		end
	end	
	return false
end
function topkek.banmgr.doWhitelist(p)
	print(p .. " whitelisted")
	table.insert(topkek.banmgr.whitelist, p)
end
function topkek.banmgr.unwhitelist(p)
	for x, m in pairs(topkek.banmgr.whitelist) do
		if m == p then
			print(m .. " unwhitelisted")
			table.remove(topkek.banmgr.whitelist, x)
			if game:GetService('Players'):FindFirstChild(p) then
				topkek.banmgr.executeKick(game:GetService('Players')[p])
			end
		end
	end	
end
function topkek.banmgr.plrWhitelisted(p)
	for x, m in pairs(topkek.banmgr.whitelist) do
		if m == p.Name then
			return true
		end
	end	
	return false
end
function topkek.banmgr.makePrivate()
	topkek.banmgr.isPrivate = true
	for i, v in pairs(game:GetService('Players'):GetPlayers()) do
		if not topkek.banmgr.plrWhitelisted(v) and v ~= topkek.lplr then
			spawn(function()
				topkek.banmgr.executeKick(v)
			end)
		end
	end
end
function topkek.banmgr.unprivate()
	topkek.banmgr.isPrivate = false
end
function topkek.banmgr.init()
	topkek.banmgr.loadFromFile()
	game:GetService('Players').PlayerAdded:connect(function(p)
		if topkek.banmgr.plrBanned(p) or (topkek.banmgr.isPrivate and not topkek.banmgr.plrWhitelisted(p)) then
			print("Player " .. p.Name .. " is banned (or private on)! Kicking now.")
			topkek.banmgr.executeKick(p)
		end
	end)
end
--// settings //--
topkek.settings = {}
topkek.settingsTable = {}
function topkek.settings.write()
	--writefile("testplzignore.lua", "", game:GetService('HttpService'):JSONEncode(topkek.settingsTable))
end
function topkek.settings.get()
if game.Players.LocalPlayer.Character then
		print("No settings! Making new ...")
		topkek.settingsTable = {
			['Bans'] = {
				
			},
			['Themes'] = {
				{Primary = {0,0,0}, Secondary = {0,0,0}, Tertiary = {0,0,0}}
			};
		}
		topkek.settings.write()
		return topkek.settingsTable
	else
		local lset = game:GetService('HttpService'):JSONDecode(set)
		topkek.settingsTable = lset
		return lset
end
end
--// shortcuts //--
tk = {}
tk.ob = topkek.tools.util.Object
tk.dp = topkek.tools.util.doPlayers
tk.rcm = topkek.tools.util.recurseRemove
tk.rcs = topkek.tools.util.recurseSet
tk.rcf = topkek.tools.util.recurseFunc
tk.rco = topkek.tools.util.recurseSetObj
tk.play = topkek.tools.util.play
tk.gt = topkek.tools.util.getTorso
--// gui //--
-- copying this from topkek3.0 because i'm
-- too lazy to rewrite my lib
topkek.tools.gui.seperation = 12
function topkek.tools.gui:addLeftIcon(parent, img, sz)
	topkek.tools.util.Object('ImageLabel', {
		Parent = parent;
		BackgroundTransparency = 1;
		Position = UDim2.new(0, 2, 0, 2);
		Size = UDim2.new(0, sz, 0, sz);
		Image = img;
	})
end
function topkek.tools.gui:makeContainer(n)
	local temp = topkek.template:Clone()
	temp.Name = n
	temp.Parent = topkek.holder
	temp.Container.Visible = false
end
function topkek.tools.gui:hookContainer(o, ncan, sepr, stt)
	if not o:IsA("ScrollingFrame") and (not ncan) then
		return nil
	elseif o:IsA("ScrollingFrame") then
		o.CanvasSize = UDim2.new(0, 0, 0, 0)
	end
	
	local self = {}
	self.main = o
	self.drawX = 0
	self.drawY = stt or topkek.tools.gui.seperation/2
	self.drawHeight = 0
	self.sepr = sepr or topkek.tools.gui.seperation
	
	function self:drawButton(sz, txt, func, ysz, cbgd)
		local xposOffset = 0
		local xposScale = self.drawX
		local xszOffset = 0
		local xszScale = sz
		if not (self.drawX == 0)  then
			xszOffset = -5
			if sz + self.drawX > 0.998 then
				xszOffset = -10
			end
		elseif sz == 1 then
			local bzz = 4
			if ncan then
				bzz = 0
			end
			xszOffset = -(self.sepr) - bzz
			xposOffset = self.sepr/2
		else
			xszOffset = -4 + -(self.sepr/2)
			xposOffset = self.sepr/2
		end
		if not ysz then ysz = 20 end
		local obj = topkek.tools.util.Object("TextButton", {
			Parent = self.main;
			BackgroundColor3 = cbgd or Color3.new(57/255, 57/255, 163/255);
			BorderSizePixel = 0;
			Position = UDim2.new(xposScale, xposOffset, 0, self.drawY);
			Size = UDim2.new(xszScale, xszOffset, 0, ysz);
			Font = 'SourceSans';
			FontSize = 'Size14';
			Text = txt;
			TextSize = 14;
			TextColor3 = Color3.new(199/255, 199/255, 199/255);
		})
		obj.MouseButton1Down:connect(function()
			spawn(func)
		end)
		if ysz > self.drawHeight then
			self.drawHeight = ysz
		end
		self.drawX = self.drawX + sz
		if self.drawX > 0.998 then
			self.drawY = self.drawY + 3 + self.drawHeight
			self.drawX = 0
			self.drawHeight = 0
			if (not ncan) then
				self.main.CanvasSize = UDim2.new(0, 0, 0, self.drawY + 5)
			end
		end
		return obj
	end
	
	function self:GetChildren()
		return self.main:GetChildren()
	end
	
	function self:getDrawY()
		return self.drawY
	end
	
	function self:setDrawY(y)
		self.drawY = y
	end
	
	function self:drawTextBox(sz, txt, ysz, cbgd)
		local xposOffset = 0
		local xposScale = self.drawX
		local xszOffset = 0
		local xszScale = sz
		if not (self.drawX == 0)  then
			xszOffset = -5
			if sz + self.drawX > 0.998 then
				xszOffset = -10
			end
		elseif sz == 1 then
			xszOffset = -(self.sepr) - 5
			xposOffset = self.sepr/2
		else
			xszOffset = -4 + -(self.sepr/2)
			xposOffset = self.sepr/2
		end
		if not ysz then ysz = 20 end
		local obj = topkek.tools.util.Object("TextBox", {
			Parent = self.main;
			BackgroundColor3 = cbgd or color3(52, 52, 153); 
			BorderSizePixel = 0;
			Position = UDim2.new(xposScale, xposOffset, 0, self.drawY);
			Size = UDim2.new(xszScale, xszOffset, 0, ysz);
			Font = 'SourceSans';
			FontSize = 'Size14';
			Text = txt;
			TextSize = 14;
			TextColor3 = Color3.new(199/255, 199/255, 199/255);
		})
		if ysz > self.drawHeight then
			self.drawHeight = ysz
		end
		self.drawX = self.drawX + sz
		if self.drawX > 0.998 then
			self.drawY = self.drawY + 3 + self.drawHeight
			self.drawX = 0
			self.drawHeight = 0
			self.main.CanvasSize = UDim2.new(0, 0, 0, self.drawY + 5)
		end
		return obj
	end
	
	function self:drawImage(sz, img, ysz)
		local xposOffset = 0
		local xposScale = self.drawX
		local xszOffset = 0
		local xszScale = sz
		if not (self.drawX == 0)  then
			xszOffset = -5
			if sz + self.drawX > 0.998 then
				xszOffset = -12
			end
		elseif sz == 1 then
			xszOffset = -(self.sepr) - 5
			xposOffset = self.sepr/2
		else
			xszOffset = -5 + -(self.sepr/2)
			xposOffset = self.sepr/2
		end
		if not ysz then ysz = 20 end
		local obj = topkek.tools.util.Object("ImageLabel", {
			Parent = self.main;
			BackgroundTransparency = 1;
			BorderColor3 = Color3.new(27, 42, 53);
			BorderSizePixel = 0;
			Position = UDim2.new(xposScale, xposOffset, 0, self.drawY);
			Size = UDim2.new(xszScale, xszOffset, 0, ysz);
			Image = img;
		})
		if ysz > self.drawHeight then
			self.drawHeight = ysz
		end
		self.drawX = self.drawX + sz
		if self.drawX > 0.998 then
			self.drawY = self.drawY + 3 + self.drawHeight
			self.drawX = 0
			self.drawHeight = 0
			if (not ncan) then
				self.main.CanvasSize = UDim2.new(0, 0, 0, self.drawY + 5)
			end
		end
		return obj
	end
	
	function self:drawText(sz, txt, ysz)
		local xposOffset = 0
		local xposScale = self.drawX
		local xszOffset = 0
		local xszScale = sz
		if not (self.drawX == 0)  then
			xszOffset = -5
			if sz + self.drawX > 0.998 then
				xszOffset = -10
			end
		elseif sz == 1 then
			local bzz = 5
			if ncan then
				bzz = 0
			end
			xszOffset = -(self.sepr) - bzz
			xposOffset = self.sepr/2
		else
			xszOffset = -4 + -(self.sepr/2)
			xposOffset = self.sepr/2
		end
		if not ysz then ysz = 20 end
		local obj = topkek.tools.util.Object("TextLabel", {
			Parent = self.main;
			BackgroundColor3 = Color3.new(51/255, 51/255, 148/255);
			BorderSizePixel = 0;
			Position = UDim2.new(xposScale, xposOffset, 0, self.drawY);
			Size = UDim2.new(xszScale, xszOffset, 0, ysz);
			Font = 'SourceSans';
			FontSize = 'Size14';
			Text = txt;
			TextSize = 14;
			TextColor3 = Color3.new(199/255, 199/255, 199/255);

		})
		if ysz > self.drawHeight then
			self.drawHeight = ysz
		end
		self.drawX = self.drawX + sz
		if self.drawX > 0.998 then
			self.drawY = self.drawY + 3 + self.drawHeight
			self.drawX = 0
			self.drawHeight = 0
			if (not ncan) then
				self.main.CanvasSize = UDim2.new(0, 0, 0, self.drawY + 5)
			end
		end
		return obj
	end
	
	
	function self:drawScrollingContainer(ysz)
		local sz = UDim2.new(1, -(self.sepr/2) - 11, 0, ysz)
		local pos = UDim2.new(0, self.sepr/2, 0, self.drawY)
		local obj = topkek.tools.util.Object("ScrollingFrame", {
			Parent = self.main;
			BackgroundColor3 = color3(42, 42, 117);
			BorderSizePixel = 0;
			Position = pos;
			Size = sz;
			BottomImage = 'rbxassetid://368504177';
			MidImage = 'rbxassetid://368504177';
			TopImage = 'rbxassetid://368504177';
			ScrollBarThickness = 5;
		})
		
		self.drawY = self.drawY + 5 + ysz
		self.drawX = 0
		self.drawHeight = 0
		if (not ncan) then
			self.main.CanvasSize = UDim2.new(0, 0, 0, self.drawY + 5)
		end
		return topkek.tools.gui:hookContainer(obj, false, 10, 3)
	end
	
	function self:drawContainer(xsz, ysz, xz, tz, sep)
		local sz = UDim2.new(xsz, -(self.sepr/2) - 11, 0, ysz)
		local pos = UDim2.new(tz or 0, self.sepr/2, 0, self.drawY)
		local obj = topkek.tools.util.Object("Frame", {
			Parent = self.main;
			BackgroundColor3 = color3(42, 42, 117);
			BorderSizePixel = 0;
			Position = pos;
			Size = sz;
		})
		if not xz then
			self.drawY = self.drawY + 5 + ysz
		end
		self.drawX = 0
		self.drawHeight = 0
		if (not ncan) then
			self.main.CanvasSize = UDim2.new(0, 0, 0, self.drawY + 5)
		end
		return topkek.tools.gui:hookContainer(obj, sep or 12, 5)
	end
	
	function self:addSpacing()
		self.drawY = self.drawY + 3
	end
	
	function self:center()
		local a,c,b=
			self.main.Position.X.Scale,
				self.main.Position.X.Offset,self.main.Size.Y.Offset
		self.main.Position=UDim2.new(a,c+2, 0.5, -(b/2))
	end	
	
	return self
end

--//anim//--
topkek.tools.animator.animateTo = function(source, dest)
	-- holder2holder:
	-- invis holder
	-- clone holder; vis
	-- move holder to right
	-- vis dest container
	-- tween clone holder left
	-- tween dest holder right
	print("nav",source,dest)
	topkek.holder.Visible = false
	local hclone = topkek.holder:Clone()
	hclone.Parent = topkek.center
	hclone.Name = 'animclone'
	hclone.Visible = true
	topkek.holder.Position = UDim2.new(-1, 0, 0, 30)
	source.Visible = false
	dest.Visible = true
	dest.Container.Visible = true
	dest.Container.ZIndex = 1
	dest.ZIndex = 1
	topkek.holder.Visible = true
	topkek.holder:TweenPosition(UDim2.new(0, 150, 0, 30), "Out", "Quad", 0.3)
	hclone:TweenPosition(UDim2.new(1, 0, 0, 30), "Out", "Quad", 0.3)
	wait(0.3)
end
topkek.tools.animator.initialAnimation = function()
	-- initanim:
	-- join both composites
	-- delete composites; vis solid
	-- tween solid to nav topbar
	-- copy topbar plrname; move outside region
	-- tween in clone topbar
	-- delete clone and solid; vis topbar
	-- tween down topbar
	-- tween holder out
	local function abspos(x)
		return UDim2.new(0, x.AbsolutePosition.X, 0, x.AbsolutePosition.Y)
	end
	local function abssz(x)
		return UDim2.new(0, x.AbsoluteSize.X, 0, x.AbsoluteSize.Y)
	end
	local holder = topkek.holder
	local nav = topkek.navigator
	local topnav = nav.Topbar
	local topbar = topkek.topbar
	local pname = topbar.PlayerName:Clone()
	local solid = topkek.gui.Solid
	topkek.center.Size = UDim2.new(0, 150, 0, 30)
	topkek.gui.Composite1:TweenPosition(UDim2.new(0.5, -50, 0.5, -50), 'Out', 'Quad', 0.5)
	topkek.gui.Composite2:TweenPosition(UDim2.new(0.5, 0, 0.5, -50), 'Out', 'Quad', 0.5)
	wait(0.52)
	solid.Visible = true
	topkek.gui.Composite1:Destroy()
	topkek.gui.Composite2:Destroy()
	wait(3)
	solid.Label:TweenPosition(UDim2.new(0, 0, 1.5, 0), 'Out', 'Quad', 0.5)
	solid:TweenSizeAndPosition(abssz(topnav), abspos(topnav), 'Out', 'Linear', 0.6)
	wait(0.52)
	solid.Label:Destroy()
	wait(0.12)
	topkek.center.Visible = true
	topnav.Visible = true
	solid:Destroy()
	pname.Position = UDim2.new(0, -170, 0, 0)
	pname.Parent = topnav
	pname.Visible = true
	pname:TweenPosition(UDim2.new(0, 10, 0, 0), 'Out', 'Quad', 0.2)
	wait(0.25)
	topkek.center:TweenSize(UDim2.new(0, 150, 0, 395), 'Out', 'Quad', 0.3)
	spawn(topkek.navigation.buildNavigator)
	wait(0.35)
	topkek.center:TweenSize(UDim2.new(0, 470, 0, 395), 'In', 'Quad', 0.3)
	wait(0.35)
	topbar.PlayerName.Visible = true
	pname:Destroy()
	AllowHovers = true
end
--//nav//--
topkek.navigation.currentContainer = topkek.tools.util.getContainer('Home')
topkek.navigation.windowState = 0
topkek.navigation.gotoContainer = function(cont)
	topkek.tools.animator.animateTo(topkek.navigation.currentContainer, cont)
	topkek.navigation.currentContainer = cont
end
topkek.navigation.buildNavigator = function()
	local nav = topkek.navigator
	local hook = topkek.tools.gui:hookContainer(nav.Scroll, false)
	local btns = {}
	for l, x in pairs(topkek.data.windows) do
		local container = topkek.tools.util.getContainer(x)
		local btn = hook:drawButton(1, x, function() topkek.navigation.gotoContainer(container) end, 25)
		local ZPos = btn.Position
		btn.Position = btn.Position - UDim2.new(0, 0, 0, 5)
		btn:TweenPosition(ZPos, 'Out', 'Bounce', 0.2)
		btn.LayoutOrder = l
		btn.ZIndex = 4
		local OPos = btn.Position
		btn.MouseEnter:connect(function()
			if AllowHovers == false then
				return
			end
			for i, v in pairs(btns) do
				if v[1] ~= btn then
					v[1]:TweenPosition(v[2], 'Out', 'Quad', 0.1)
				end
			end
			btn:TweenPosition(OPos + UDim2.new(0, 3, 0, 0), 'Out', 'Quad', 0.1)
		end)
		btn.MouseLeave:connect(function()
			btn:TweenPosition(OPos, 'Out', 'Quad', 0.1)
		end)
		table.insert(btns, {btn, OPos})
		wait()	
	end
end
topkek.navigation.buildTopbar = function()
	local top = topkek.topbar
	local FELabel = top.Controllers.IsFE
	top.PlayerName.Text = topkek.lplr.Name
	if game:GetService('Workspace').FilteringEnabled == true then
		FELabel.Text = "FE Game"
		FELabel.TextColor3 = BrickColor.new("Bright red").Color
	else
		FELabel.Text = "Not FE"
		FELabel.TextColor3 = BrickColor.new("Bright green").Color
	end
	top.Controllers.Hide.MouseButton1Down:connect(function()
		if topkek.navigation.windowState == 0 then
			topkek.navigation.windowState = 1
			topkek.center:TweenSize(UDim2.new(0, 470, 0, 30), 'Out', 'Quint', 0.2)
		else
			topkek.navigation.windowState = 0
			topkek.center:TweenSize(UDim2.new(0, 470, 0, 395), 'Out', 'Quint', 0.2)
		end
	end)	
	top.Controllers.Exit.MouseButton1Down:connect(function()
		topkek.center:TweenSize(UDim2.new(0, 470, 0, 30), 'Out', 'Quint', 0.3)
		wait(0.31)
		topkek.center:TweenSize(UDim2.new(0, 0, 0, 0), 'Out', 'Quint', 0.3)
		PlayerChatHook:disconnect()
	end)
	
end
topkek.navigation.initCommandBar = function()
	DistributedCmdBar, cmd = topkek.holder.Command, {}
	loadstring(game:GetObjects("rbxassetid://685510751")[1].Source)()
	DistributedCmdBar.FocusLost:connect(function(e)
		if e == true then
			cmd.commands.run(DistributedCmdBar.Text)
			DistributedCmdBar.Text = ''
		end
	end)
	
	PlayerChatHook = cmd.players.PlayerChatted:connect(function (_, plr, msg, _)
		if cmd.util.isadmin(plr.Name) then
			if msg:sub(1,1) == cmd.prefix or msg:sub(1,1) == cmd.hidden then
				cmd.commands.run(msg:sub(2, #msg))
			end
		end
	end)
end
topkek.navigation.buildHomePage = function()
	local count = 0
	for _, _ in pairs(cmd.commands.store) do count = count + 1 end
	local hook = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Home').Container, true)
	hook:drawText(1, 'T0PK3K 4.0 blue editon by Jacoby')
	hook:drawText(1, 'Patch version 1.0.5')
	hook:drawText(1, 'Commandbase patch version 1.0.0')
	hook:drawText(1, 'Number of commands: ' .. tostring(count))
	local stime = hook:drawText(1, 'Server Time: 0')
	spawn(function()
		while true do
			stime.Text = 'Server Time: ' .. tostring(game:GetService('Workspace').DistributedGameTime)
			wait(0.5)
		end
	end)
	local ssz = hook:drawText(1, 'Server Size: 0')
	spawn(function()
		while true do
			ssz.Text = 'Server Size: ' .. tostring(game:GetService('Players').NumPlayers)
			wait(0.5)
		end
	end)
	local fe = game:GetService('Workspace').FilteringEnabled
	hook:drawText(1, 'FilteringEnabled: ' .. (fe and "YES" or "NO"))
	hook:drawText(1, 'PlaceId: ' .. tostring(game.PlaceId))
	hook:drawText(1, 'I did not make this GUI, just redesigned it. \nCredits for making it goes to nosyliam.', 55)
end
topkek.navigation.buildContainers = function()
	for _, v in pairs(topkek.data.windows) do
		topkek.tools.gui:makeContainer(v)
	end
end

topkek.navigation.initCommandBar()
topkek.navigation.buildContainers()
topkek.navigation.buildTopbar()
topkek.navigation.buildHomePage()
wait()


--// actual code below lole //--

--// PLAYERS //--
local plrwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Players').Container)
local search = plrwin:drawButton(1, '', function()end)
drop = GUI.DropDown.New(UDim2.new(0, 0, 0, 0), UDim2.new(1, 0, 1, 0), search, {'All'})
function fixPlayerDrop()
	local t = {'All'}
	for i, v in pairs(game.Players:GetPlayers()) do
		table.insert(t, v.Name)
	end
	drop.SetTable(t)
end
game.Players.PlayerAdded:connect(function()
	fixPlayerDrop()
end)
game.Players.PlayerRemoving:connect(function()
	fixPlayerDrop()
end)
plrFrame = plrwin:drawContainer(1, 100)
headshotContainer = plrFrame:drawContainer(0.4, 94, true)
headshotContainer:setDrawY(20)
headshot = headshotContainer:drawImage(1, "https://www.roblox.com/bust-thumbnail/image?userId=1&width=420&height=420&format=png", 74)
headshotContainer:setDrawY(0)
userNameText = headshotContainer:drawText(1, "[All]")
userNameText.ClipsDescendants = true
userNameText.Font = Enum.Font.SourceSansBold
infoContainer = plrFrame:drawContainer(0.5, 94, true, 0.5)
infoContainer.BackgroundColor3 = color3(38, 38, 108)
userIdText = infoContainer:drawText(1, "ID: 0")
userAgeText = infoContainer:drawText(1, "Age: 0")
userTeamText = infoContainer:drawText(1, "Team: Neutral")
cval = 'All'
fixPlayerDrop()

function updatePlayer(plri)
	local plr = game:GetService('Players'):FindFirstChild(plri)
	if not plr and plri ~= 'All' then
		print("Couldn't find player!")
		updatePlayer(topkek.lplr)
	else
		headshot.Image = "https://www.roblox.com/bust-thumbnail/image?userId=1&width=420&height=420&format=png"
		userNameText.Text = "[All]"
		userIdText.Text = 'ID: [multiple]'
		userAgeText.Text = 'Age: [multiple]'
		userTeamText.Text = 'Team: [multiple]'
		cval = 'All'
	end
	local team = plr.TeamColor
	if team == nil then
		team = 'Neutral'
	else
		team = tostring(team)
	end
	headshot.Image = "https://www.roblox.com/bust-thumbnail/image?userId=" .. tostring(plr.UserId) .. "&width=420&height=420&format=png"
	userNameText.Text = plr.Name
	userIdText.Text = 'ID: ' .. tostring(plr.UserId)
	userAgeText.Text = 'Age: ' .. tostring(plr.AccountAge)
	userTeamText.Text = 'Team: ' .. team
	cval = plr.Name
	
end
drop.Changed(updatePlayer)
--actual code ------__-
plrwin:addSpacing()
plrwin:drawButton(1/2, 'Kick', function()
	tk.dp(cval, function(p)
		topkek.banmgr.executeKick(p)
	end)
end)

plrwin:drawButton(1/2, 'Ban', function()
	tk.dp(cval, function(p)
		topkek.banmgr.addSoftBan(p)
	end)
end)
plrwin:drawButton(1/2,'Friendlag', function()
	tk.dp(cval, function(p)
		for i = 1, 10 do
			spawn(function()
				while wait() do
		    		game.Players.LocalPlayer:RequestFriendship(p)
		  	  		game.Players.LocalPlayer:RevokeFriendship(p)
				end
			end)
		end
	end)
end)
plrwin:drawButton(1/2, 'Hardban', function()
	tk.dp(cval, function(p)
		topkek.banmgr.addHardBan(p)
	end)
end)
plrwin:addSpacing()
plrwin:drawButton(1/2, 'Bring', function()
	tk.dp(cval, function(z)
		if z.Character then
			z.Character.HumanoidRootPart.CFrame =
				game:service'Players'.LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(1,1,1)
		end
	end)
end)
plrwin:drawButton(1/2, 'Goto', function()
	tk.dp(cval, function(z)
		game:service'Players'.LocalPlayer.Character.HumanoidRootPart.CFrame =
			z.Character.HumanoidRootPart.CFrame * CFrame.new(1,1,1)
	end)
end)
plrwin:addSpacing()
plrwin:drawButton(1/3, 'Kill', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild("Humanoid") then
			p.Character.Humanoid.Health = 0
		end
	end)
end)
plrwin:drawButton(1/3, 'Seizure', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild("Humanoid") and tk.gt(p) then
			spawn(function()
				p.Character.Humanoid.PlatformStand = true
				tk.gt(p).CFrame = tk.gt(p).CFrame * CFrame.Angles(math.rad(90),0,0) 
				repeat 
					wait()
					p.Character.Humanoid.PlatformStand = true
					tk.gt(p).Velocity = Vector3.new(math.random(-10,10),-5,math.random(-10,10)) 
					tk.gt(p).RotVelocity = Vector3.new(math.random(-5,5),math.random(-5,5),math.random(-5,5)) 
				until not p.Character:FindFirstChild("Humanoid") or not tk.gt(p)
			end)
		end
	end)
end)
plrwin:drawButton(1/3, 'Stun', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild("Humanoid") then
			p.Character.Humanoid.PlatformStand = true
			p.Character.Torso.CFrame = p.Character.Torso.CFrame * CFrame.Angles(math.rad(90),0,0) 
		end
	end)
end)
plrwin:drawButton(1/3, 'Freeze', function()
	tk.dp(cval, function(p)
		if p.Character then
			tk.gt(p).Anchored = true
		end
	end)
end)
plrwin:drawButton(1/3, 'Thaw', function()
	tk.dp(cval, function(p)
		if p.Character then
			tk.gt(p).Anchored = false
		end
	end)
end)
plrwin:drawButton(1/3, 'Superslow', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.Humanoid.WalkSpeed = 1
		end
	end)
end)
plrwin:drawButton(1/3, 'Highjump', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.Humanoid.JumpPower = 125
		end
	end)
end)
plrwin:drawButton(1/3, 'God', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.Humanoid.MaxHealth = math.huge
			p.Character.Humanoid.Health = math.huge
		end
	end)
end)
plrwin:drawButton(1/3, 'Semigod', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.Humanoid.MaxHealth = 9e9
			p.Character.Humanoid.Health = 9e9
		end
	end)
end)
plrwin:drawButton(1/3, 'Fast', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.Humanoid.WalkSpeed = 50
		end
	end)
end)
Follow = false;
plrwin:drawButton(1/3, 'Annoy', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			if Follow == true then
				Follow = false; return
			else Follow = true end
			while Follow == true do
				game:service'Players'.LocalPlayer.Character.HumanoidRootPart.CFrame=
					p.Character.HumanoidRootPart.CFrame
				wait()
			end
		end
	end)
end)
plrwin:drawButton(1/3, 'Freefall', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.HumanoidRootPart.CFrame = p.Character.HumanoidRootPart.CFrame * CFrame.new(0, 10000, 0)		
		end
	end)
end)
plrwin:drawButton(1/3, 'Destroy', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.Humanoid:Destroy()
		end
	end)
end)
plrwin:drawButton(1/3, 'Fix', function()
	tk.dp(cval, function(p)
		if p.Character and p.Character:FindFirstChild('Humanoid') then
			p.Character.Humanoid.Health = 100
			p.Character.Humanoid.MaxHealth = 100
			p.Character.Humanoid.JumpPower = 100
			p.Character.Humanoid.WalkSpeed = 16
			p.Character.Humanoid.PlatformStand = false
			p.Character.Humanoid.Jump = true
		end
	end)
end)
plrwin:drawButton(1/3, 'Respawn', function()
	tk.dp(cval, function(p)
		if p.Character then
			local a1 = Instance.new("Model", game:service'Workspace')
			local a2 = Instance.new("Part", game:service'Workspace')
			a2.CanCollide = true
			a2.Anchored = true
			a2.CFrame = CFrame.new(10000, 10000, 10000)
			a2.Name = "Torso"
			local a3 = Instance.new("Humanoid", a1)
			a3.MaxHealth=100;a3.Health=100
			p.Character = a1
			a3.Health=0
		end
	end)
end)
plrwin:addSpacing()
local nameInp
plrwin:drawButton(1/3, 'Name', function()
	tk.dp(cval, function(z)
		local Character = z.Character
		local newName = Instance.new("Model", z.Character)
		newName.Name = nameInp.Text
		local cl = Character:WaitForChild("Head"):Clone()
		cl.Parent = newName
		cl:WaitForChild("face"):Destroy()
		local hum = Instance.new("Humanoid", newName)
		hum.Name = "NameTag"
		hum.MaxHealth = 0
		hum.Health = 0
		local weld = Instance.new("Weld", cl)
		weld.Part0 = cl
		weld.Part1 = Character:WaitForChild("Head")
		Character:WaitForChild("Head").Transparency = 1
		wait(.5)
		cl.BrickColor = Character:WaitForChild("Head").BrickColor
	end)
end)
nameInp = plrwin:drawTextBox(2/3, '')
local chatInp
plrwin:drawButton(1/3, 'Chat', function()
	tk.dp(cval, function(z)
		game:GetService('Chat'):Chat(z.Charcter, chatInp.Text)
	end)
end)
chatInp = plrwin:drawTextBox(2/3, '')
local disgInp
plrwin:drawButton(1/3, 'Disguise', function()
	tk.dp(cval, function(p)
		local id = 0
		if tonumber(disgInp.Text) then
			id = tonumber(disgInp.Text)
		else
			id = game:GetService('Players'):GetUserIdFromNameAsync(disgInp.Text)
		end
		if p.Character:FindFirstChild("Humanoid") then
			p.Character.Humanoid.Health = 0
		end
		p.CharacterAppearance = 'https://assetgame.roblox.com/Asset/CharacterFetch.ashx?userId=' .. tostring(id)
	end)
end)
disgInp = plrwin:drawTextBox(2/3, 'ROBLOX')
plrwin:addSpacing()
clrR = plrwin:drawTextBox(1/3, '0')
clrG = plrwin:drawTextBox(1/3, '0')
clrB = plrwin:drawTextBox(1/3, '0')
function getColor()
	local r = tonumber(clrR.Text)
	local g = tonumber(clrG.Text)
	local b = tonumber(clrB.Text)
	if not (r and g and b) then return Color3.new(0,0,0) end
	return Color3.new(r/255, g/255, b/255)
end
plrwin:drawButton(1/3, 'Sparkles', function()
	tk.dp(cval, function(z)
		Instance.new("Sparkles", tk.gt(z)).SparkleColor = getColor()
	end)
end)
plrwin:drawButton(1/3, 'Smoke', function()
	tk.dp(cval, function(z)
		Instance.new("Smoke", tk.gt(z)).Color = getColor()

	end)
end)
plrwin:drawButton(1/3, 'Fire', function()
	tk.dp(cval, function(z)
		local fr = Instance.new("Fire", tk.gt(z))
		fr.Color = getColor()
		fr.Heat = 30
		fr.Size = 20
	end)
end)
plrwin:drawButton(1/3, 'Forcefield', function()
	tk.dp(cval, function(z)
		if z.Character then
			Instance.new("ForceField", z.Character)
		end
	end)
end)
plrwin:drawButton(1/3, 'Select', function()
	tk.dp(cval, function(z)
		if z.Character and tk.gt(z) then
			Instance.new("SelectionBox", tk.gt(z)).Adornee = tk.gt(z)
		end
	end)
end)
plrwin:drawButton(1/3, 'Sphere', function()
	tk.dp(cval, function(z)
		if z.Character and tk.gt(z) then
			Instance.new("SelectionSphere", tk.gt(z)).Adornee = tk.gt(z)
		end
	end)
end)
plrwin:drawButton(1/3, 'Fling', function()
	tk.dp(cval, function(z)
		spawn(function() --kohls admin commands lol
			if z.Character and tk.gt(z) then 
				local xran, zran
				repeat xran = math.random(5555, 9999) until math.abs(xran) >= 5555
				repeat zran = math.random(5555, 9999) until math.abs(zran) >= 5555
				z.Character.Humanoid.Sit = true 
				tk.gt(z).Velocity = Vector3.new(0,0,0)
				local frc = Instance.new("BodyForce", tk.gt(z))
				frc.Name = "BFRC" 
				frc.force = Vector3.new(xran*4,9999*5,zran*4) 
				game:GetService("Debris"):AddItem(frc, 0.1)
			end
		end)
	end)
end)
plrwin:drawButton(1/3, 'Explode', function()
	tk.dp(cval, function(z)
		if z.Character and tk.gt(z) then
			local explosion = Instance.new("Explosion")
			explosion.Position = tk.gt(z).Position
			explosion.Parent = workspace
		end
	end)
end)
plrwin:drawButton(1/3, 'Nuke', function()
	tk.dp(cval, function(z)
		if z.Character and tk.gt(z) then
			local torso = tk.gt(z)
			local nuke = Instance.new("Part", game.Workspace)
			local opos = torso.CFrame
			nuke.BrickColor = BrickColor.new("Bright yellow")
			nuke.TopSurface = Enum.SurfaceType.Smooth
			nuke.BottomSurface = Enum.SurfaceType.Smooth
			nuke.Anchored = true
			nuke.CanCollide = false
			nuke.Shape = "Ball"				
			nuke.Transparency = 0.5
			nuke.CFrame = torso.CFrame		
			nuke.Size = Vector3.new(1, 1, 1)
			nuke.Touched:connect(function(p)
				local expl = Instance.new("Explosion", p)
				expl.BlastPressure = 50000
				expl.BlastRadius = 50
				expl.Position = p.Position
				p.Material = Enum.Material.CorrodedMetal
				p:BreakJoints()
			end)
			for i = 1, 150 do
				nuke.Size = Vector3.new(i, i, i)
				nuke.CFrame = opos
				wait(0.08)
			end
			nuke:Destroy()
		end
	end)
end)
plrwin:drawButton(1/3, 'No Tools', function()
	tk.dp(cval, function(p)
		for _, t in pairs(p.Backpack:GetChildren()) do
			t:Destroy()
		end
	end)
end)
plrwin:drawButton(1/3, 'Take Tools', function()
	tk.dp(cval, function(p)
		for _, t in pairs(p.Backpack:GetChildren()) do
			t.Parent = game:service'Players'.LocalPlayer.Backpack
		end
	end)
end)
plrwin:drawButton(1/3, 'BTools', function()
	tk.dp(cval, function(p)
		local a = Instance.new("HopperBin")
		a.BinType = "GameTool"
		a.Parent = p.Backpack
		local a = Instance.new("HopperBin")
		a.BinType = "Clone"
		a.Parent = p.Backpack
		local a = Instance.new("HopperBin")
		a.BinType = "Hammer"
		a.Parent = p.Backpack
	end)
end)
plrwin:drawButton(1/3, 'Hotdog', function()
	tk.dp(cval, function(p)
		if p.Character and tk.gt(p) then
			topkek.tools.util.weenieHutJunior(p)
		end
	end)
end)
plrwin:drawButton(1/3, 'Quicksand', function()
	tk.dp(cval, function(z)
		if z.Character and z.Character:FindFirstChild("Humanoid") then
			local tor = tk.gt(z)
			local hole = Instance.new("Part", z.Character)
			hole.Anchored = true
			hole.Name = "Hole"
			hole.FormFactor = Enum.FormFactor.Custom
			hole.Size = Vector3.new(7, 1, 7)
			hole.CanCollide = false
			hole.CFrame = tor.CFrame * CFrame.new(0,-3.3,0)
			hole.BrickColor = BrickColor.new("Cool yellow")
			hole.Material = Enum.Material.Sand
			local hm = Instance.new("CylinderMesh", hole)
			tor.Anchored = true
			if z.Character:FindFirstChild("Humanoid") then
				z.Character.Humanoid.Jump = true
			end
			for x,m in pairs(z.Character:GetChildren()) do
				if m:IsA("BasePart") or m:IsA("MeshPart") then
					m.CanCollide = false
				end
			end
			for i=1,75 do
				tor.CFrame=tor.CFrame*CFrame.new(0,-0.1,0)
				wait(0.06)
			end
			tor.CFrame=tor.CFrame*CFrame.new(0,
				-500,0
			)
			z.Character.Humanoid.Health = 0
		end
	end)
end)
plrwin:drawButton(1/3, 'Insane', function()
	tk.dp(cval, function(p)
		if p.Character and tk.gt(p) then
			for i,v in pairs(tk.gt(p):GetChildren()) do
				if v:IsA("Motor6D") then
					spawn(function()
						while v do
							v.C0=v.C0*CFrame.Angles(math.random(-180,180),math.random(-180,180),math.random(-180,180))
							wait()
						end
					end)
				end
			end
		end
	end)
end)
plrwin:drawButton(1/3, 'Invisible', function()
	tk.dp(cval, function(p)
		tk.rco(p.Character, 'BasePart', 'Transparency', 1)
		tk.rco(p.Character, 'MeshPart', 'Transparency', 1)
	end)
end)
plrwin:drawButton(1/3, 'Visible', function()
	tk.dp(cval, function(p)
		tk.rco(p.Character, 'BasePart', 'Transparency', 0)
		tk.rco(p.Character, 'MeshPart', 'Transparency', 0)
	end)
end)
plrwin:drawButton(1/3, 'Bighead', function()
	tk.dp(cval, function(z)
		if z.Character then
			if z.Character:FindFirstChild('Head') then
				z.Character.Head.Mesh.Scale=Vector3.new(5,5,5)
			end
		end
	end)
end)
plrwin:drawButton(1/3, 'Goldify', function()
	tk.dp(cval, function(z)
		if z.Character then
			tk.rco(z.Character, 'BasePart', 'Material', 'Marble')
			tk.rco(z.Character, 'MeshPart', 'Material', 'Marble')
			tk.rco(z.Character, 'BasePart', 'BrickColor', BrickColor.new('Bright yellow'))
			tk.rco(z.Character, 'MeshPart', 'BrickColor', BrickColor.new('Bright yellow'))
		end
	end)
end)
plrwin:drawButton(1/3, 'Neon', function()
	tk.dp(cval, function(z)
		if z.Character then
			tk.rco(z.Character, 'BasePart', 'Material', 'Neon')
			tk.rco(z.Character, 'MeshPart', 'Material', 'Neon')
		end
	end)
end)
plrwin:drawButton(1/3, 'Shiny', function()
	tk.dp(cval, function(z)
		if z.Character then
			tk.rco(z.Character, 'BasePart', 'Reflectance', 1)
			tk.rcm(z.Character, 'MeshPart')
		end
	end)
end)
plrwin:drawButton(1/3, 'Shrek', function()
	tk.dp(cval, function(z)
		if z.Character then
			local pchar = z.Character
			for i,v in pairs(pchar:GetChildren()) do
				if v:IsA("Hat") or v:IsA("Accessory") or v:IsA("CharacterMesh") or v:IsA("Shirt") or v:IsA("Pants") then
					v:Destroy()
				end
			end
			for i,v in pairs(pchar.Head:GetChildren()) do
				if v:IsA("Decal") or v:IsA("SpecialMesh") then
					v:Destroy()
				end
			end
			
			local mesh = Instance.new("SpecialMesh", pchar.Head)
			mesh.MeshType = "FileMesh"
			pchar.Head.Mesh.MeshId = "http://www.roblox.com/asset/?id=19999257"
			pchar.Head.Mesh.Offset = Vector3.new(-0.1, 0.1, 0)
			pchar.Head.Mesh.TextureId = "http://www.roblox.com/asset/?id=156397869"
			
			local Shirt = Instance.new("Shirt", z.Character)
			local Pants = Instance.new("Pants", z.Character)
			
			Shirt.ShirtTemplate = "rbxassetid://133078194"
			Pants.PantsTemplate = "rbxassetid://133078204"
		end
	end)
end)
plrwin:drawButton(1/3, 'Duck', function()
	tk.dp(cval, function(z)
		if z.Character then
			local pchar = z.Character
		    for i,v in pairs(pchar:GetChildren()) do
			    if v:IsA("Hat") or v:IsA("Accessory") then
				    v:Destroy()
			    end
		    end
		    local duck = Instance.new("SpecialMesh", z.Character.HumanoidRootPart)
		    duck.MeshType = "FileMesh"
		    duck.MeshId = "http://www.roblox.com/asset/?id=9419831"
		    duck.TextureId = "http://www.roblox.com/asset/?id=9419827"
		    duck.Scale = Vector3.new(5, 5, 5)
		    tk.rco(z.Character, 'Instance', 'Transparency', 1)
			z.Character.HumanoidRootPart.Transparency = 0
		end
	end)
end)
plrwin:drawButton(1/3, 'Spheres', function()
	tk.dp(cval, function(z)
		if z.Character then
			tk.rco(z.Character, 'BasePart', 'Shape', 'Cylinder')
		end
	end)
end)
plrwin:drawButton(1/3, 'Big', function()
	tk.dp(cval, function(z)
		if z.Character then
			topkek.tools.util.scalePlayer(5, z)
		end
	end)
end)
plrwin:drawButton(1/3, 'Small', function()
	tk.dp(cval, function(z)
		if z.Character then
			topkek.tools.util.scalePlayer(5, z)
		end
	end)
end)
plrwin:drawButton(1/3, 'Giraffe', function()
	tk.dp(cval, function(z)
		if z.Character then
			local char=z.Character
			local h=char.Head
			local tor=char:FindFirstChild("Torso")
			if not tor then return end
			tor.Neck.C0=tor.Neck.C0*CFrame.new(0,0,5)
			local fn=Instance.new("Part",char)
			fn.Size=Vector3.new(1,5.5,1)
			fn.Name="FakeNeck"
			fn.Anchored=false
			fn.CanCollide=false
			if char:FindFirstChild("Body Colors") then
				fn.BrickColor=char["Body Colors"].HeadColor
			end
			local cm=Instance.new("CylinderMesh",fn)
			local we=Instance.new("Weld",h)
			we.Part0=h
			we.Part1=fn
			we.C1=we.C1*CFrame.new(0,2.6,0)
		end
	end)
end)
plrwin:drawButton(1/3, 'Dab', function()
	tk.dp(cval, function(z)
		if z.Character and z.Character:FindFirstChild("Torso") then
			local chr = z.Character
			chr.Animate.Disabled = true
	        chr.Torso["Left Shoulder"].C1 = CFrame.new(0, 0.699999988, 0, 0.939692616, 0, -0.342020124, -0.330366075, -0.258819044, -0.907673359, -0.0885213241, 0.965925813, -0.243210346)
	        chr.Torso["Right Shoulder"].C1 = CFrame.new(-0.600000024, 0.5, -0.200000003, 0.664462984, 0.241844743, 0.707106769, -0.664462984, -0.241844788, 0.707106769, 0.342020154, -0.939692616, -3.09086197e-008)
	        chr.Torso["Neck"].C1 = CFrame.new(0, -0.600000024, 0, -0.866025388, 0.5, 0, -0.171010137, -0.29619807, 0.939692616, 0.469846278, 0.813797653, 0.342020124)
		end
	end)
end)
plrwin:drawButton(1/3, 'Force Follow', function()
	tk.dp(cval, function(z)
		game:GetService("RunService"):BindToRenderStep("_", 0, function()
			z.Character.Humanoid:MoveTo(topkek.lplr.Character.Head.Position)
		end)
	end)
end)
plrwin:drawButton(1/3, 'Camlock', function()
	tk.dp(cval, function(z)
		z.CameraMode = "LockFirstPerson"
	end)
end)
--// SERVER //--
local servwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Server').Container)
local detailWin = servwin:drawContainer(1, 100, nil, nil, 18)
detailWin:drawText(1, 'Job ID: ' .. (game.JobId and (game.JobId ~= "") or "???"))
detailWin:drawText(1, 'Game Name: ' .. game:service'MarketplaceService':GetProductInfo(game.PlaceId).Name)
detailWin:drawText(1, 'Creator Name: ' .. game:GetService('Players'):GetNameFromUserIdAsync(game.CreatorId))
pcall(function() detailWin:drawText(1, 'Genre: ' .. tostring(game.Genre)) end)
servwin:drawButton(1/2, 'Shutdown', function()
	workspace.Gravity = 0/0
end)
servwin:drawButton(1/2, 'Clear', function()
	for i,v in pairs(game:service'Workspace':GetChildren()) do
		if (not v:IsA("Terrain"))and(v.Name~="Camera") then
			v:Destroy()
		end
	end
end)
servwin:drawButton(1/2, 'Baseplate', function()
	for X = -2500, 2500, 512 do
		for Z = -2500, 2500, 512 do
			local P = Instance.new("Part")
		    P.Anchored = true
		    P.Locked = true
		    P.Size = Vector3.new(512,3,512)
		    P.CFrame = CFrame.new(X,0,Z)
		    P.BrickColor = BrickColor.Green()
		    P.Parent = game:service'Workspace'
		end
	end
end)
servwin:drawButton(1/2, 'Reset', function()
	for i,v in pairs(game:service'Workspace':GetChildren()) do
		if (not v:IsA("Terrain"))and(v.Name~="Camera") then
			v:Destroy()
		end
	end
	for X = -2500, 2500, 512 do
		for Z = -2500, 2500, 512 do
			local P = Instance.new("Part")
		    P.Anchored = true
		    P.Locked = true
		    P.Size = Vector3.new(512,3,512)
		    P.CFrame = CFrame.new(X,0,Z)
		    P.BrickColor = BrickColor.Green()
		    P.Parent = game:service'Workspace'
		end
	end
	for i, v in pairs(game:GetService('Players'):GetPlayers()) do
		local a1 = Instance.new("Model", game:service'Workspace')
		local a2 = Instance.new("Part", game:service'Workspace')
		a2.CanCollide = true
		a2.Anchored = true
		a2.CFrame = CFrame.new(10000, 10000, 10000)
		a2.Name = "Torso"
		local a3 = Instance.new("Humanoid", a1)
		a3.MaxHealth=100;a3.Health=100
		v.Character = a1
		a3.Health=0
	end
end)
servwin:drawButton(1, 'Remove Sounds', function()
	tk.rcm(game, 'Sound')
end)
servwin:addSpacing()
servwin:drawButton(1, 'Break All', function()
	workspace:BreakJoints(workspace:GetChildren())
end)
local gravInp
servwin:drawButton(1/3, 'Gravity', function()
	if not tonumber(gravInp.Text) then return end
	workspace.Gravity = tonumber(gravInp.Text)
end)
gravInp = servwin:drawTextBox(2/3, '')
servwin:addSpacing()
servwin:drawButton(1, 'Reset Lighting', function()
	local l = game:service'Lighting'
	l.Ambient = Color3.new(0, 0, 0)
	l.Brightness = 1
	l.GlobalShadows = true
	l.Outlines = true
	l.FogEnd = 100000
	l.FogStart = 0
	l:SetMinutesAfterMidnight(12*60)
end)
local brightInp
servwin:drawButton(1/3, 'Brightness', function()
	if not tonumber(brightInp.Text) then return end
	game:GetService('Lighting').Brightness = tonumber(brightInp.Text)
end)
brightInp = servwin:drawTextBox(2/3, '100')
local fogInp
servwin:drawButton(1/3, 'Fog', function()
	if not tonumber(fogInp.Text) then return end
	game:GetService('Lighting').FogEnd = tonumber(fogInp.Text)
end)
fogInp = servwin:drawTextBox(2/3, '0')
local timeInp
servwin:drawButton(1/3, 'Hour', function()
	if not tonumber(timeInp.Text) then return end
	game:GetService('Lighting'):SetMinutesAfterMidnight(60*tonumber(timeInp.Text))
end)
timeInp = servwin:drawTextBox(2/3, '12')
servwin:addSpacing()
-- private server crap
local privateToggle
local privStatus = false
privateToggle = servwin:drawButton(1, 'Private Server OFF', function()
	if privStatus == false then
		privStatus = true
		privateToggle.Text = 'Private Server ON'
		topkek.banmgr.makePrivate()
	else
		privateToggle.Text = 'Private Server OFF'
		topkek.banmgr.unprivate()
	end
end)
servwin:addSpacing()
servwin:drawText(1, 'Whitelist')
local plrAddInp
servwin:drawButton(1/3, 'Add', function()
	topkek.banmgr.doWhitelist(plrAddInp.Text)
	ReorderWL()
end)
plrAddInp = servwin:drawTextBox(2/3, '')
wlCont = servwin:drawScrollingContainer(100)
function ReorderWL()
	local wl = topkek.banmgr.whitelist
	for i,v in pairs(wlCont:GetChildren()) do
		v:Destroy()
	end
	wlCont:setDrawY(3)
	for i,v in pairs(wl) do
		wlCont:drawText(2/3, v)
		wlCont:drawButton(1/3, 'Remove', function()
			topkek.banmgr.unwhitelist(v)
			ReorderWL()
		end) 
	end
end
ReorderWL()
--// LOCALPLAYER //--
local lpwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('LocalPlayer').Container)
lpwin:drawButton(1, 'Reset Camera', function()
	game.Workspace.CurrentCamera:remove()
	wait(.1)
	game.Workspace.CurrentCamera.CameraSubject = topkek.lplr.Character.Humanoid or 
		game.Workspace[topkek.lplr.Name].Humanoid
	game.Workspace.CurrentCamera.CameraType = "Custom"
end)
lpwin:drawButton(1, 'Respawn', function()
	local a1 = Instance.new("Model", game:service'Workspace')
	local a2 = Instance.new("Part", game:service'Workspace')
	a2.CanCollide = true
	a2.Anchored = true
	a2.CFrame = CFrame.new(10000, 10000, 10000)
	a2.Name = "Torso"
	local a3 = Instance.new("Humanoid", a1)
	a3.MaxHealth=100;a3.Health=100
	topkek.lplr.Character = a1
	a3.Health=0
end)
lpwin:drawButton(1, 'Rejoin', function()
	game:GetService('TeleportService'):Teleport(game.PlaceId)
end)
lpwin:addSpacing()
lpwin:drawButton(1/2, 'God', function()
	if topkek.lplr.Character:FindFirstChild("Humanoid") then
		topkek.lplr.Character.Humanoid.MaxHealth = math.huge
		topkek.lplr.Character.Humanoid.Health = math.huge
	end
end)
lpwin:drawButton(1/2, 'Semigod', function()
	if topkek.lplr.Character:FindFirstChild("Humanoid") then
		topkek.lplr.Character.Humanoid.MaxHealth = 9e9
		topkek.lplr.Character.Humanoid.Health = 9e9
	end
end)
Loopgod = false
lpwin:drawButton(1, 'Loopgod', function()
	if Loopgod == false then
		Loopgod = true
		spawn(function()
			repeat
				topkek.lplr.Character.Humanoid.MaxHealth = math.huge
				topkek.lplr.Character.Humanoid.Health = math.huge
				wait()
			until Loopgod == false
		end)	
	else
		Loopgod = false
	end
end)
lpwin:addSpacing()
plrwin:addSpacing()
local Lev, Clip, Fly
lpwin:drawButton(1/2, 'Levitate', function()
	if Lev == true then
		Lev = false
		return
	end
	Lev = true
	repeat
		topkek.lplr.Character.Humanoid:ChangeState(10)
		wait(0)
	until Lev == false
end)
lpwin:drawButton(1/2, 'Noclip', function()
	if Clip == true then
		Clip = false
		return
	end
	Clip = true
	game:GetService("RunService").Stepped:connect(function()
		tk.gt(topkek.lplr).CanCollide = not Clip
		topkek.lplr.Character.Head.CanCollide = not Clip
		topkek.lplr.Character.HumanoidRootPart.CanCollide = not Clip
		if topkek.lplr.Character.UpperTorso then
			topkek.lplr.Character.LowerTorso.CanCollide = not Clip
		end
	end)
	topkek.lplr.Character.HumanoidRootPart.Changed:connect(function()
		tk.gt(topkek.lplr).CanCollide = not Clip
		topkek.lplr.Character.Head.CanCollide = not Clip
		topkek.lplr.Character.HumanoidRootPart.CanCollide = not Clip
		if topkek.lplr.Character.UpperTorso then
			topkek.lplr.Character.LowerTorso.CanCollide = not Clip
		end
	end)
end)
lpwin:drawButton(1/2, 'Fly', function()
	if Fly == true then
		Fly = false
		return
	end
	Fly = true
  local mouse=game.Players.LocalPlayer:GetMouse''
  localplayer=game.Players.LocalPlayer
  game.Players.LocalPlayer.Character:WaitForChild("HumanoidRootPart")
  local torso = game.Players.LocalPlayer.Character.HumanoidRootPart
  local speed=0
  local keys={a=false,d=false,w=false,s=false} 
  local e1
  local e2
  local function start()
   local pos = Instance.new("BodyPosition",torso)
   local gyro = Instance.new("BodyGyro",torso)
   pos.Name="EPIXPOS"
   pos.maxForce = Vector3.new(math.huge, math.huge, math.huge)
   pos.position = torso.Position
   gyro.maxTorque = Vector3.new(9e9, 9e9, 9e9) 
   gyro.cframe = torso.CFrame
   repeat
    wait()
    localplayer.Character.Humanoid.PlatformStand=true
    local new=gyro.cframe - gyro.cframe.p + pos.position
    if not keys.w and not keys.s and not keys.a and not keys.d then
     speed=1
    end 
    if keys.w then 
     new = new + workspace.CurrentCamera.CoordinateFrame.lookVector * speed
     speed=speed+0.01
    end
    if keys.s then 
     new = new - workspace.CurrentCamera.CoordinateFrame.lookVector * speed
     speed=speed+0.01
    end
    if keys.d then 
     new = new * CFrame.new(speed,0,0)
     speed=speed+0.01
    end
    if keys.a then 
     new = new * CFrame.new(-speed,0,0)
     speed=speed+0.01
    end
    if speed>5 then
     speed=5
    end
    pos.position=new.p
    if keys.w then
     gyro.cframe = workspace.CurrentCamera.CoordinateFrame*CFrame.Angles(-math.rad(speed*15),0,0)
    elseif keys.s then
     gyro.cframe = workspace.CurrentCamera.CoordinateFrame*CFrame.Angles(math.rad(speed*15),0,0)
    else
     gyro.cframe = workspace.CurrentCamera.CoordinateFrame
    end
   until not Fly
   if gyro then gyro:Destroy() end
   if pos then pos:Destroy() end
   flying=false
   localplayer.Character.Humanoid.PlatformStand=false
   speed=0
  end
  e1=mouse.KeyDown:connect(function(key)
   if not torso or not torso.Parent then flying=false e1:disconnect() e2:disconnect() return end
   if key=="w" then
    keys.w=true
   elseif key=="s" then
    keys.s=true
   elseif key=="a" then
    keys.a=true
   elseif key=="d" then
    keys.d=true
   end
  end)
  e2=mouse.KeyUp:connect(function(key)
   if key=="w" then
    keys.w=false
   elseif key=="s" then
    keys.s=false
   elseif key=="a" then
    keys.a=false
   elseif key=="d" then
    keys.d=false
   end
  end)
  start()
end)
lpwin:drawButton(1/2, 'Highjump', function()
	local thrust = Instance.new("BodyVelocity")
	game:GetService('UserInputService').InputBegan:connect(function(i, b)
		if i.KeyCode == Enum.KeyCode.Space then
			print("Got jump")
			coroutine.resume(coroutine.create(function()
				thrust.Parent = game.Players.LocalPlayer.Character.PrimaryPart
				thrust.velocity = Vector3.new(0,50,0)
				thrust.maxForce = Vector3.new(0,4e+050,0)
				wait(0.2)
				thrust.Parent = nil 
			end))
		end
	end)
end)
lpwin:addSpacing()
local apprInp
lpwin:drawButton(1/3, 'Appearance', function()
	local id = 0
	if tonumber(apprInp.Text) then
		id = tonumber(apprInp.Text)
	else
		id = game:GetService('Players'):GetUserIdFromNameAsync(apprInp.Text)
	end
	if topkek.lplr.Character:FindFirstChild("Humanoid") then
		topkek.lplr.Character.Humanoid.Health = 0
	end
	topkek.lplr.CharacterAppearance = 'https://assetgame.roblox.com/Asset/CharacterFetch.ashx?userId=' .. tostring(id)
end)
apprInp = lpwin:drawTextBox(2/3, 'ROBLOX')
local teamInp
lpwin:drawButton(1/3, 'Team', function()
	topkek.lplr.TeamColor = BrickColor.new(teamInp.Text)
end)
teamInp = lpwin:drawTextBox(2/3, 'Bright red')
lpwin:drawButton(1/2, 'Naked', function()
	topkek.lplr:ClearCharacterAppearance()
end)
lpwin:drawButton(1/2, 'Neutral', function()
	topkek.lplr.Neutral = true
end)
lpwin:addSpacing()
lpwin:drawButton(1/2, 'Orb', function()
	game.Players.LocalPlayer.Character = nil
	--lp:Destroy()
	local cam = game.Workspace.CurrentCamera
	local m = Instance.new("Model", game.Workspace)
	m.Name = game.Players.LocalPlayer.Name
	local hum = Instance.new("Humanoid", m)
	hum.Health = 0
	hum.MaxHealth = 0
	local orb = Instance.new("Part", m)
	orb.Size = Vector3.new(1, 1, 1)
	orb.Shape = "Ball"
	orb.Name = "Head"
	orb.Anchored = true
	orb.CanCollide = true
	orb.BottomSurface = Enum.SurfaceType.Smooth
	orb.TopSurface = Enum.SurfaceType.Smooth
	orb.Transparency = 0
	spawn(function()
		while true do
			wait(0.1)
			if orb then
				orb.BrickColor = BrickColor.Random()
			else break end
		end
	end)
	cam.CameraSubject = orb
	cam.CameraType = Enum.CameraType.Fixed
	game:GetService("RunService").RenderStepped:connect(function()
		orb.CFrame = cam.CoordinateFrame * CFrame.new(0, -2, -6)
	end)
	game.Players.LocalPlayer.Chatted:connect(function(a)
		game:GetService("Chat"):Chat(orb, a)
	end)
end)
lpwin:drawButton(1/2, 'Freecam', function()
	local cam = game.Workspace.CurrentCamera
	cam.CameraType = "Fixed"
	cam.CameraSubject = nil
	topkek.lplr.Character = nil
end)
lpwin:drawButton(1/2, 'NoGrav', function()
	if topkek.lplr.Character then
		for x,m in pairs(topkek.lplr.Character:GetChildren()) do
			if m:IsA("BasePart") then
				local bf = Instance.new("BodyForce", m)
				bf.force = Vector3.new(0, 192.25, 0) * m:GetMass()
			end
			if m:IsA("Hat") or m:IsA("Accessory") then
				if m:findFirstChild("Handle") then
					local bf = Instance.new("BodyForce", m.Handle)
					bf.force = Vector3.new(0, 192.25, 0) * m.Handle:GetMass()
				end
			end
		end
	end
end)
lpwin:drawButton(1/2, 'Trowel', function()
	topkek.tools.util.trowel()
end) 
lpwin:addSpacing()
lpwin:drawButton(1/2, 'Fedora', function()
	local hats={
		98346834,
		215751161,
		119916949,
		72082328,
		147180077,
		100929604,
		63043890,
		1285307,
		1029025,
		334663683,
		259423244
	}
	game:GetObjects("rbxassetid://" .. tostring(hats[math.random(1,#hats)]))[1].Parent = topkek.lplr.Character
end)
lpwin:drawButton(1/2, 'Rainbow Name', function()
	topkek.lplr.Neutral = false
	repeat
		wait()
		topkek.lplr.TeamColor = BrickColor.Random()
	until not topkek.lplr.Character.Humanoid
end)
local tagInp
lpwin:drawButton(1/3, 'Tag', function()
	local len = 10
	local bb = Instance.new("BillboardGui")
	bb.Parent = topkek.lplr.Character.Head
	bb.Adornee = topkek.lplr.Character.Head
	bb.AlwaysOnTop = true
	bb.Enabled = true
	bb.Size = UDim2.new(len, 0, 1.5, 0)
	bb.Name = "tag"
	bb.StudsOffset = Vector3.new(0, 3, 0)
	--local fr = Instance.new("Frame")
	--fr.Parent = bb
	--fr.Size = UDim2.new(1, 0, 1, 0)
	--fr.Style = Enum.FrameStyle.RobloxRound
	local tl = Instance.new("TextLabel")
	tl.Parent = bb
	tl.Font = Enum.Font.Code
	tl.BackgroundTransparency = 1
	tl.TextScaled = true
	tl.TextColor3 = Color3.new(15/255, 15/255, 15/255)
	tl.Size = UDim2.new(1, 0, 1, 0)
	tl.Text = tagInp.Text
	tl.Name = "trutag"
	tl.Visible = true
	tl.ZIndex = 2
end)
tagInp = lpwin:drawTextBox(2/3, '')
--// SCRIPTS //--
local scriptwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Scripts').Container)
local search = scriptwin:drawTextBox(1,'')
local origy = scriptwin:getDrawY()
scriptwin:addSpacing()
scriptwin:addSpacing()
local scripts = game:GetObjects("rbxassetid://376553985")[1]
local container = {}
function MakeList(condition)
	for i,v in pairs(scriptwin:GetChildren()) do
		if v.Name == "Script" then
			v:Destroy()
		end
	end
	scriptwin:setDrawY(origy)
	for i, v in pairs(scripts:GetChildren()) do
		if string.find(v.Name:lower(), condition:lower()) or (condition == "") or (condition == " ") then
			local scr = scriptwin:drawButton(1, v.Name, function()
				spawn(function() loadstring(v.Source)() end)
			end, 25)
			scr.Name = 'Script'
		end
	end
end
game:GetService("UserInputService").InputChanged:connect(function(inp)
	if inp.UserInputType == Enum.UserInputType.TextInput then
		if search:IsFocused() then
			MakeList(search.Text)
		end
	end
end)
MakeList('')
--// DESTRUCTION // --
local destwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Destruction').Container)
local decals, seldec = destwin:drawScrollingContainer(100)
seldec = destwin:drawText(1, 'Selected Decal: None')
cursel = nil
local decs = {
	{'Rain', '574772793'},
	{'Robbie', '574773630'},
	{'Pepe', '244905904'},
	{'Troll Face', '48308661'},
	{'Jeff', '109129888'},
	{'Shrek', '170539018'},
	{'Doge', '133720697'},
	{'Dat Boi', '409578848'},
}
for _, v in pairs(decs) do
	local b = decals:drawButton(1, v[1], function()seldec.Text="Selected Decal: " ..v[2] cursel=v[2] end,20)
	topkek.tools.gui:addLeftIcon(b,'rbxassetid://'..v[2],20)
end
destwin:drawButton(1, 'Spam Decal', function()
	if cursel ~= nil then
		topkek.tools.util.recurseDecal(tonumber(cursel))
	end
end)
destwin:drawButton(1, 'Spam Particles', function()
	if cursel ~= nil then
		topkek.tools.util.recurseParticles(tonumber(cursel))
	end
end)
destwin:drawButton(1, 'Spam Both', function()
	if cursel ~= nil then
		topkek.tools.util.recurseUltimate(tonumber(cursel))
	end
end)
destwin:drawButton(1, 'Rollback', function()
	tk.rcm(workspace, 'Decal')
	tk.rcm(workspace, 'ParticleEmitter')
end)
destwin:addSpacing()
destwin:drawButton(1, '666', function()
	for i,v in next,workspace:children''do
	 	if(v:IsA'BasePart')then
	    me=v;
	    bbg=Instance.new('BillboardGui',me);
	    bbg.Name='stuf';
	    bbg.Adornee=me;
	    bbg.Size=UDim2.new(2.5,0,2.5,0)
	    --bbg.StudsOffset=Vector3.new(0,2,0)
	    tlb=Instance.new'TextLabel';
	    tlb.Text='666 666 666 666 666 666';
	    tlb.Font='SourceSansBold';
	    tlb.FontSize='Size48';
	    tlb.TextColor3=Color3.new(1,0,0);
	    tlb.Size=UDim2.new(1.25,0,1.25,0);
	    tlb.Position=UDim2.new(-0.125,-22,-1.1,0);
	    tlb.BackgroundTransparency=1;
	    tlb.Parent=bbg;
	    end;end;
	    --coroutine.wrap(function()while wait''do
	      s=Instance.new'Sound';
	      s.Parent=workspace;
	      s.SoundId='rbxassetid://152840862';
	      s.Pitch=1;
	      s.Volume=1;
	      s.Looped=true;
	      s:play();
	      --end;end)();
	      function xds(dd)
	        for i,v in next,dd:children''do
	          if(v:IsA'BasePart')then
	            v.BrickColor=BrickColor.new'Really black';
	            v.TopSurface='Smooth';
	            v.BottomSurface='Smooth';
	            s=Instance.new('SelectionBox',v);
	            s.Adornee=v;
	            s.Color=BrickColor.new'Really red';
	            a=Instance.new('PointLight',v);
	            a.Color=Color3.new(1,0,0);
	            a.Range=15;
	            a.Brightness=5;
	            f=Instance.new('Fire',v);
	            f.Size=19;
	            f.Heat=22;
	            end;
	            game.Lighting.TimeOfDay=0;
	            game.Lighting.Brightness=0;
	            game.Lighting.ShadowColor=Color3.new(0,0,0);
	            game.Lighting.Ambient=Color3.new(1,0,0);
	            game.Lighting.FogEnd=200;
	            game.Lighting.FogColor=Color3.new(0,0,0);
	        local dec = 'http://www.roblox.com/asset/?id=19399245';
	            local fac = {'Front', 'Back', 'Left', 'Right', 'Top', 'Bottom'}
	            --coroutine.wrap(function()
	            --for _,__ in pairs(fac) do
	            --local ddec = Instance.new("Decal", v)
	            --ddec.Face = __
	            --ddec.Texture = dec
	        --end end)()
	            if #(v:GetChildren())>0 then
	                   xds(v) 
	              end
	         end
	    end
	xds(game.Workspace)
end)
destwin:drawButton(1, 'Troll', function()
	topkek.tools.util.recurseUltimate('48308661')
	tk.play(154664102)
end)
destwin:addSpacing()
destwin:drawButton(1/2,'Colorize',function() -- when u skid off variable XDDDDDpranked
	local materiallist = 
	{Enum.Material.Plastic,Enum.Material.Wood,Enum.Material.Slate,Enum.Material.Concrete,Enum.Material.CorrodedMetal,
		Enum.Material.DiamondPlate,Enum.Material.Foil,Enum.Material.Grass,
		Enum.Material.Ice,Enum.Material.Marble,Enum.Material.Granite,Enum.Material.Brick,
		Enum.Material.Pebble,Enum.Material.Sand,Enum.Material.Sand,
		Enum.Material.Fabric,Enum.Material.SmoothPlastic,Enum.Material.Metal,Enum.Material.WoodPlanks,Enum.Material.Neon,Enum.Material.Cobblestone}
	local function r(where) 
		for _,v in pairs (where:GetChildren()) do 
		if v:IsA("BasePart") then 
		spawn(function() while wait(0.1) do v.Material = materiallist[math.random(#materiallist)] wait()   end end) end r(v) end end r(workspace)
end)
destwin:drawButton(1/2,'Materialize',function()
	local function r(where) 
 	for _,v in pairs (where:GetChildren()) do 
  	if v:IsA("BasePart") then 
   	spawn(function() while wait(0.1) do v.Transparency = math.random(0,1) wait()   end end) end r(v) end end r(workspace)
end)
destwin:drawButton(1/2,'Meshify',function()
	local enums={
		Enum.MeshType.Head;
		Enum.MeshType.Torso;
		Enum.MeshType.Wedge;
		Enum.MeshType.Brick;
		Enum.MeshType.Sphere;
		Enum.MeshType.Cylinder;
	}
	tk.rcf('BasePart',function(o)
		local mesh = Instance.new('SpecialMesh', o)
		mesh.MeshType = enums[math.random(1,#enums)]
	end)
end)
destwin:drawButton(1/2,'Loop-Meshify',function()
	coroutine.wrap(function()
		while true do
			local enums={
				Enum.MeshType.Head;
				Enum.MeshType.Torso;
				Enum.MeshType.Wedge;
				Enum.MeshType.Brick;
				Enum.MeshType.Sphere;
				Enum.MeshType.Cylinder;
			}
			tk.rcf('BasePart',function(o)
				if o:FindFirstChild("Mesh") then o.Mesh:Destroy() end
				local mesh = Instance.new('SpecialMesh', o)
				mesh.MeshType = enums[math.random(1,#enums)]
			end)
			wait(0.5)
		end
	end)()
end)
destwin:addSpacing()
destwin:drawButton(1, 'Rotations', function()
	tk.rcf('BasePart', function(o)
		o.Rotation = Vector3.new(math.random(0,180),math.random(0,180),math.random(0,180))
	end)
end)
destwin:drawButton(1, 'Collisions', function()
	tk.rcf('BasePart', function(o)
		o.CanCollide = false
	end)
end)
destwin:drawButton(1, 'Velocity', function()
	tk.rcf('BasePart', function(o)
		o.Velocity = Vector3.new(math.random(0,180),math.random(0,180),math.random(0,180))
	end)
end)
destwin:drawButton(1, 'Invisiblity', function()
	tk.rcf('BasePart', function(o)
		o.Transparency = 1
	end)
end)
destwin:drawButton(1, 'BreakJoints', function()
	tk.rcf('Model', function(o)
		o:BreakJoints()
	end)
end)
destwin:drawButton(1, 'Forces', function()
	tk.rcf('BasePart', function(o)
		local bf = Instance.new("BodyForce", o)
		bf.Force = Vector3.new(math.random(0,180)*5,math.random(0,180)*5,math.random(0,180)*5)
	end)
end)
destwin:drawButton(1, 'Brightness', function()
	tk.rcf('BasePart', function(o)
		local light = Instance.new("SpotLight", o)
		light.Brightness = 9e9
		light.Range = 60
	end)
end)
--// CATALOG //--
local catwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Catalog').Container)
local page, currentkeyword = 1, ""
local searchbar, search, makeCatalog, res = 0, 0, 0, {}
local searchbar = catwin:drawTextBox(2/3,'')
local search = catwin:drawButton(1/3, 'Search', function()
	page = 1
	currentkeyword = searchbar.Text
	makeCatalog(currentkeyword, page)
end)
local previous = catwin:drawButton(1/2, 'Previous Page', function()
	if page > 1 then
		page = page - 1
		makeCatalog(currentkeyword, page)
	end
end)
local previous = catwin:drawButton(1/2, 'Next Page', function()
	if page >= 1 then
		page = page + 1
		makeCatalog(currentkeyword, page)
	end
end)
local catalog_start = catwin:getDrawY()
function split(str,divider)
	local found = ""
	local results = {}
	for i=1,string.len(str) do
		if (string.lower(string.sub(str,i,i)) == string.lower(divider)) then
			table.insert(results, found)
			found = ""
		else
			found = found..string.sub(str,i,i)
		end
	end
	table.insert(results, found)
	return results
end
function GetName(nm)
	local spl = split(nm," ")
	local a,b,c,d,e=spl[1] or "",spl[2] or "",spl[3] or "", spl[4] or "", spl[5] or ""
	return (a.." "..b.." "..c.." "..d.." "..e)
end
function makeCatalog(keyword, page)
	local endpoint = "http://search.roblox.com/catalog/json?Category=6&Keyword="..keyword.."&IncludeNotForSale=false&ResultsPerPage=10&PageNumber="..tostring(page)
	local results = game:HttpGet(endpoint, true)
	local parse = game:GetService('HttpService'):JSONDecode(results)
	for i, v in pairs(res) do
		v:Destroy()
	end
	catwin:setDrawY(catalog_start)
	catwin:addSpacing()
	for i, v in pairs(parse) do
		local img = catwin:drawImage(1/2, 'https://www.roblox.com/Thumbs/Asset.ashx?width=420&height=420&assetId='..tostring(v['AssetId']), 50)
		local below = topkek.tools.util.Object("TextButton", {
			Parent = img;
			BackgroundColor3 = Color3.new(57/255, 57/255, 163/255);
			BorderSizePixel = 0;
			Position = UDim2.new(0, -45, 1, 5);
			Size = UDim2.new(0,img.AbsoluteSize.X, 0, 20);
			Font = 'SourceSans';
			FontSize = 'Size14';
			Text = GetName(v['Name']);
			TextSize = 14;
			TextColor3 = color3(199, 199, 199);
			TextStrokeTransparency = 0.5;
			ClipsDescendants = true;
		})
		below.MouseButton1Down:connect(function()
			local Model = Instance.new("Model", workspace)
			game:GetObjects('rbxassetid://'..tostring(v['AssetId']))[1].Parent = Model
			Model:MakeJoints()
			Model:MoveTo(topkek.lplr.Character.Head.Position)
		end)
		img.Size=UDim2.new(0,50,0,50)
		img.Position=img.Position+UDim2.new(0,45,0,0)
		if (i%2)==0 then
			catwin:setDrawY(catwin:getDrawY() + 25)
		end
		if (i==10) then
			catwin.main.CanvasSize = catwin.main.CanvasSize + UDim2.new(0,0,0,25)
		end
		table.insert(res,img)
	end
end
makeCatalog("", 1)
--// CMDS //--
cmdwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Commands').Container)
count = 0
for _, _ in pairs(cmd.commands.store) do count = count + 1 end
cmdwin:drawText(1, tostring(count) .. " Commands")
cmdwin:drawText(1, 'Chat Prefix: /')
local cmdlist = cmdwin:drawScrollingContainer(260)
for i, v in pairs(cmd.commands.fmtstore) do
	local xfmt = {}
	local str = "  ;" .. i .. " "
	for form in v:gmatch("[^%%]+") do
		if form ~= 'cmd' then
			if form == 'inf' then form = 'str' end
			str = str .. "{" .. form .. "} " 
		end
	end
	cmdlist:drawText(1, str)
end
--// MUSIC //--
musicwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Music').Container)
Sounds = {
	{"caramell", 2303479};
	{"epic", 27697743};
	{"rick", 2027611};	
	{"halo", 1034065};
	{"pokemon", 1372261};
	{"cursed", 1372257};
	{"extreme", 11420933};
	{"awaken", 27697277};
	{"alone", 27697392};
	{"mario", 1280470};
	{"choir", 1372258};
	{"chrono" ,1280463};
	{"dotr", 11420922};
	{"entertain", 27697267};
	{"fantasy", 1280473};
	{"final", 787};
	{"organ", 11231513};
	{"tunnel", 9650822}
}

local cursel
local xcursel = 0
scr = musicwin:drawScrollingContainer(230)
for i, v in pairs(Sounds) do
	scr:drawButton(1, v[1] .. " - " .. tonumber(v[2]), function()
		cursel.Text = "Currently Selected - " .. v[1]
		xcursel = v[2]
	end)
end

cursel = musicwin:drawText(1, "Currently Selected - None")
local setInp
musicwin:drawButton(1/3, "Set", function()
	if tonumber(setInp.Text) then
		cursel.Text = "Currently Selected - " .. setInp.Text
		xcursel = tonumber(setInp.Text)
	end
end)
setInp = musicwin:drawTextBox(2/3, '')
musicwin:drawButton(1, "Play", function()
	tk.rcm(game, 'Sound')
	tk.play(xcursel)	
end)
musicwin:drawButton(1, "Stop", function()
	tk.rcm(game, 'Sound')
end)
--// FACES //--
facwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Faces').Container)
local faces = {	
	{name='Rofl',id=47595647},
	{name='Sparta',id=74142203},
	{name='UJelly',id=48989071},
	{name='Troll',id=45120559},
	{name='Horse',id=62079221},
	{name='Angry',id=48258623},
	{name='Okey',id=62830600},
	{name='Yeaw',id=53646377},
	{name='Here',id=62677045},
	{name='Har',id=48260066},
	{name='Baby Sun',id=47596170},
	{name='LOL',id=48293007},
	{name='Sad',id=53645378},
	{name='Joseph Stalin',id=48290678},
	{name='Doge',id=130742396},
	{name='Forever Alone',id=156886272},
	{name='RickRoll',id=5104631},
	{name='Jim Carrey',id=74885351},
	{name='Meh IRL',id=237553381}
}
local cursel, xcursel = nil, 0
faclist = facwin:drawScrollingContainer(260)
for i,v in pairs(faces) do
	local btn = faclist:drawButton(1, v['name'], function()
		xcursel = v['id']
		cursel.Text = 'Currently Selected: ' .. v['name']
	end)
	topkek.tools.gui:addLeftIcon(btn,'rbxassetid://'..tostring(v['id']),20)
end
cursel = facwin:drawText(1, 'Currently Selected: None')
facwin:drawButton(1, 'Wear', function()
	if not (xcursel == 0) then
		if topkek.lplr.Character then
			tk.rcm(topkek.lplr.Character, 'Accessory')
			tk.rcm(topkek.lplr.Character, 'Hat')
			topkek.tools.util.applyFace(xcursel)
		end
	end
end)
--// SETTINGS // --
setwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Settings').Container)
setwin:drawText(1, 'Patch: ' .. topkek.patch)
setwin:drawText(1, 'Devnote: kys')
setwin:drawText(1, [[
     I am captured by a windstorm
     Caught on you
     Nothing here can stop me
     When it's windy in my heart
     Captured by a windstorm
     Night and day
     Here is only you and me
     And the light the sky has left behind
 
     It's time to leave
     Because times that have pass will not return
     Traveling on open seas
     Where everything's like new
     In the future that you hold
 
     Without regrets I leave my safe harbor
     Free but still tied to a set of open arms
]], 260)
--// BANLIST //--
banwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Banlist').Container)
local plrBanInp
banwin:drawButton(1/3, 'Add', function()
	topkek.settings.get()
	table.insert(topkek.settingsTable['Bans'], plrBanInp.Text)
	topkek.settings.write()
	UpdateBanlist()
end)
plrBanInp = banwin:drawTextBox(2/3, '')
banCont = banwin:drawScrollingContainer(288)
function UpdateBanlist(x)
	topkek.settings.get()
	local wl = x or topkek.settingsTable['Bans']
	for i,v in pairs(banCont:GetChildren()) do
		v:Destroy()
	end
	banCont:setDrawY(3)
	for i,v in pairs(wl) do
		banCont:drawText(2/3, v)
		banCont:drawButton(1/3, 'Remove', function()
			for x, m in pairs(wl) do
				if m == v then
					table.remove(topkek.settingsTable['Bans'], x)
					topkek.settings.write()
					UpdateBanlist()
					topkek.banmgr.bans = topkek.settingsTable['Bans']
				end
			end
		end) 
	end
end
UpdateBanlist()
--// HATS //--
hatwin = topkek.tools.gui:hookContainer(topkek.tools.util.getContainer('Hats').Container)
local hats={	
	{name='Dominus Empyreus',id=21070012},
	{name='Dominus Vespertilio',id=96103379},
	{name='Dominus Infernus',id=31101391},
	{name='Dominus Rex',id=250395631},
	{name='Dominus Frigidus',id=48545806},
	{name='Dominus Astra',id=162067148},
	{name='Dominus Aureus',id=138932314},
	{name='DIY Dominus Empyreus',id=151789690},
	{name='Dominus Messor',id=64444871},
	{name='Demon Skeleton Wings',id=133554007},
	{name='Gilded Wings of Glory',id=250405532},
	{name='Majestic Ice Wings',id=188702967},
	{name='Black Wings',id=215719598},
	{name='Clockworks Shades',id=11748356},
	{name='Faerie Wings',id=19399896},
	{name='Orinthian Wings',id=223751505},
	{name='Clockworks Headphones',id=1235488},
	{name='Perfectly Legitimate Business Hat',id=19027209},
	{name='Sparkling Angel Wings',id=192557913},
	{name='Commander Crows Wings',id=133553855},
	{name='Sunfire Wings',id=158068470},
	{name='Royal Faerie Wings',id=119916756},
	{name='Wings of Freedom',id=164174048},
	{name='Firebrand Wings',id=128160626},
	{name='Frozen Wings',id=136758613},
	{name='Webbed Wings',id=120507280},
	{name='Gargoyle Wings',id=120507201},
	{name='Bat Wings',id=19399858},
	{name='Wings of Fire',id=136758532},
	{name='Headrow',id=1082935},
	{name='Rubber Duckie',id=9254254},
	{name='Valkyrie Helm',id=1365767},
{name='Hockey Mask',id=5161514}}
local searchi = hatwin:drawButton(1, '', function()end)
dropx = GUI.DropDown.New(UDim2.new(0, 0, 0, 0), UDim2.new(1, 0, 1, 0), searchi, {'All'})
function fixPlayerDropi()
	local t = {'All'}
	for i, v in pairs(game.Players:GetPlayers()) do
		table.insert(t, v.Name)
	end
	dropx.SetTable(t)
end
game.Players.PlayerAdded:connect(function()
	fixPlayerDropi()
end)
game.Players.PlayerRemoving:connect(function()
	fixPlayerDropi()
end)
local eval = 'All'
dropx.Changed(function(p) eval = p end)
fixPlayerDrop()

local hatInp
hatlist = hatwin:drawScrollingContainer(260)
for i,v in pairs(hats) do
	hatlist:drawButton(1, v['name'], function()
		hatInp.Text = tostring(v['id']) 
	end)
end
hatwin:drawButton(1/3, 'Wear', function()
	local hat = game:GetObjects("rbxassetid://"..tonumber(hatInp.Text))[1]
	tk.dp(eval, function(x)
		if x.Character then
			hat:Clone().Parent = x.Character
		end
	end)
end)


hatInp = hatwin:drawTextBox(2/3, '')
topkek.tools.animator.initialAnimation()
topkek.banmgr.init()
end)

runingoutofideas.Name = "runingoutofideas"
runingoutofideas.Parent = Scripts
runingoutofideas.BackgroundColor3 = Color3.new(0, 0, 0)
runingoutofideas.BackgroundTransparency = 0.5
runingoutofideas.Position = UDim2.new(0, 0, 0, 603)
runingoutofideas.Size = UDim2.new(0, 200, 0, 50)
runingoutofideas.Font = Enum.Font.SourceSans
runingoutofideas.FontSize = Enum.FontSize.Size14
runingoutofideas.Text = "fe hax gui lite"
runingoutofideas.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
runingoutofideas.TextSize = 14
runingoutofideas.TextWrapped = true

runingoutofideas.MouseButton1Down:connect(function()
--made in literally 5 minutes, just a copy paste of the only working buttons on fe hax gui











hi = game:GetObjects('rbxassetid://928597043')[1]
hi.Parent = game.Players.LocalPlayer.PlayerGui
hi.TextButton.sd.MouseButton1Down:Connect(function()
for i =1,100 do
spawn(function()
while wait() do
for i,v in pairs(game:GetService'Players':GetPlayers()) do
if v.Character ~= nil and v.Character:FindFirstChild'Head' then
for _,x in pairs(v.Character.Head:GetChildren()) do
if x:IsA'Sound' then x.Playing = true end
end
end
end
end
end)
end
end)
--hot fly script by RGEENEUS cuz im too lazy to make one
local speed = 50 -- This is the fly speed. Change it to whatever you like. The variable can be changed while running
local c
local h
local bv
local bav
local cam
local flying
local p = game:GetService'Players'.LocalPlayer
local buttons = {W = false, S = false, A = false, D = false, Moving = false}
local startFly = function () -- Call this function to begin flying 
if not p.Character or not p.Character.Head or flying then return end
c = p.Character
h = c.Humanoid
h.PlatformStand = true
cam = workspace:WaitForChild('Camera')
bv = Instance.new("BodyVelocity")
bav = Instance.new("BodyAngularVelocity")
bv.Velocity, bv.MaxForce, bv.P = Vector3.new(0, 0, 0), Vector3.new(10000, 10000, 10000), 1000
bav.AngularVelocity, bav.MaxTorque, bav.P = Vector3.new(0, 0, 0), Vector3.new(10000, 10000, 10000), 1000
bv.Parent = c.Head
bav.Parent = c.Head
flying = true
h.Died:connect(function() flying = false end)
end
local endFly = function () -- Call this function to stop flying
if not p.Character or not flying then return end
h.PlatformStand = false
bv:Destroy()
bav:Destroy()
flying = false
end
game:GetService("UserInputService").InputBegan:connect(function (input, GPE) 
if GPE then return end
for i, e in pairs(buttons) do
if i ~= "Moving" and input.KeyCode == Enum.KeyCode[i] then
buttons[i] = true
buttons.Moving = true
end
end
end)
game:GetService("UserInputService").InputEnded:connect(function (input, GPE) 
if GPE then return end
local a = false
for i, e in pairs(buttons) do
if i ~= "Moving" then
if input.KeyCode == Enum.KeyCode[i] then
buttons[i] = false
end
if buttons[i] then a = true end
end
end
buttons.Moving = a
end)
local setVec = function (vec)
return vec * (speed / vec.Magnitude)
end
game:GetService("RunService").Heartbeat:connect(function (step) -- The actual fly function, called every frame
if flying and c and c.PrimaryPart then
local p = c.PrimaryPart.Position
local cf = cam.CFrame
local ax, ay, az = cf:toEulerAnglesXYZ()
c:SetPrimaryPartCFrame(CFrame.new(p.x, p.y, p.z) * CFrame.Angles(ax, ay, az))
if buttons.Moving then
local t = Vector3.new()
if buttons.W then t = t + (setVec(cf.lookVector)) end
if buttons.S then t = t - (setVec(cf.lookVector)) end
if buttons.A then t = t - (setVec(cf.rightVector)) end
if buttons.D then t = t + (setVec(cf.rightVector)) end
c:TranslateBy(t * step)
end
end
end)
hi.TextButton.fh.MouseButton1Down:Connect(function()
local lol = game:GetService'Players'.LocalPlayer.Character
pcall(function()
for i,v in pairs(lol:GetChildren()) do
if v.Name ~= 'Head' and v.Name ~= 'Torso' and v.Name ~= 'HumanoidRootPart' then
v:Destroy()
end
end
local ok = lol:FindFirstChild'Torso'
if ok then ok = ok:FindFirstChild'roblox' if ok then ok:Destroy() end end
Instance.new('Humanoid', lol)
if lol.HumanoidRootPart:FindFirstChild'Rank' then lol.HumanoidRootPart:FindFirstChild'Rank':Destroy() end
local nouxd = lol:FindFirstChild'Torso'
wait'1'
lol.Head.Position = lol.Head.Position + Vector3.new(1,1,1)
if nouxd then nouxd.Transparency = 1 end
wait'.3'
startFly()
end)
end)
end)

oof.Name = "oof"
oof.Parent = Scripts
oof.BackgroundColor3 = Color3.new(0, 0, 0)
oof.BackgroundTransparency = 0.5
oof.Position = UDim2.new(0, 0, 0, 655)
oof.Size = UDim2.new(0, 200, 0, 50)
oof.Font = Enum.Font.SourceSans
oof.FontSize = Enum.FontSize.Size14
oof.Text = "oof"
oof.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
oof.TextSize = 14
oof.TextWrapped = true

oof.MouseButton1Down:connect(function()
while wait() do
    for i,v in pairs(game:GetService'Players':GetPlayers()) do
        if v.Character ~= nil and v.Character:FindFirstChild'Head' then
            for _,x in pairs(v.Character.Head:GetChildren()) do
                if x:IsA'Sound' then x.Playing = true end
            end
        end
    end
end
end)

whydoustillreadthis.Name = "whydoustillreadthis"
whydoustillreadthis.Parent = Scripts
whydoustillreadthis.BackgroundColor3 = Color3.new(0, 0, 0)
whydoustillreadthis.BackgroundTransparency = 0.5
whydoustillreadthis.Position = UDim2.new(0, 0, 0, 707)
whydoustillreadthis.Size = UDim2.new(0, 200, 0, 50)
whydoustillreadthis.Font = Enum.Font.SourceSans
whydoustillreadthis.FontSize = Enum.FontSize.Size14
whydoustillreadthis.Text = "FE Animation GUI"
whydoustillreadthis.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
whydoustillreadthis.TextSize = 14
whydoustillreadthis.TextWrapped = true

whydoustillreadthis.MouseButton1Down:connect(function()
--FE Animation Gui Made by Dark Magic Rblx in ROBLOX Studio, please give credits if you use this.
--You can use all and me in the Name Here Section!
gui = Instance.new("ScreenGui",game.Players.LocalPlayer.PlayerGui)
gui.Name = "FE Animation Gui by Dark Magic Rblx"
box = Instance.new("Frame",gui)
box.Size = UDim2.new(0,400,0,100)
box.Position = UDim2.new(0,800,0,500)
box.BackgroundTransparency = 0
box.BackgroundColor3 = Color3.new(167,0,0)
box.BorderSizePixel = 5
box.BorderColor3 = Color3.new(27,42,53)

o = Instance.new("TextBox",gui)
o.Name = "Speed Here"
o.Size = UDim2.new(0,150,0,15)
o.Position = UDim2.new(0,1000,0,590)
o.BackgroundTransparency = 0
o.BackgroundColor3 = Color3.new(0,0,0)
o.BorderSizePixel = 0
o.Font = "Arcade"
o.TextColor3 = Color3.new(255,255,255)
o.TextScaled = true
o.TextWrapped = true
o.Text = "Speed Here"

a = Instance.new("TextBox",gui)
a.Name = "ID Here"
a.Size = UDim2.new(0,300,0,25)
a.Position = UDim2.new(0,900,0,530)
a.BackgroundTransparency = 0
a.BackgroundColor3 = Color3.new(0,0,0)
a.BorderSizePixel = 0
a.Font = "Arcade"
a.TextColor3 = Color3.new(255,255,255)
a.TextScaled = true
a.TextWrapped = true
a.Text = "ID Here"

b = Instance.new("TextBox",gui)
b.Name = "Namehere"
b.Size = UDim2.new(0,300,0,25)
b.Position = UDim2.new(0,900,0,560)
b.BackgroundTransparency = 0
b.BackgroundColor3 = Color3.new(0,0,0)
b.BorderSizePixel = 0
b.Font = "Arcade"
b.TextColor3 = Color3.new(255,255,255)
b.TextScaled = true
b.TextWrapped = true
b.Text = "Name here"

c = Instance.new("TextButton",gui)
c.Name = "Animation"
c.Size = UDim2.new(0,100,0,40)
c.Position = UDim2.new(0,800,0,520)
c.BackgroundTransparency = 0
c.BackgroundColor3 = Color3.new(0,0,0)
c.BorderSizePixel = 0
c.Font = "Arcade"
c.TextColor3 = Color3.new(255,255,255)
c.TextScaled = true
c.TextWrapped = true
c.Text = "Animation"

d = Instance.new("TextButton",gui)
d.Name = "Player"
d.Size = UDim2.new(0,100,0,40)
d.Position = UDim2.new(0,800,0,560)
d.BackgroundTransparency = 0
d.BackgroundColor3 = Color3.new(0,0,0)
d.BorderSizePixel = 0
d.Font = "Arcade"
d.TextColor3 = Color3.new(255,255,255)
d.TextScaled = true
d.TextWrapped = true
d.Text = "Player"

cred = Instance.new("TextLabel",gui)
cred.Name = "Credits"
cred.Size = UDim2.new(0,400,0,20)
cred.Position = UDim2.new(0,800,0,500)
cred.BackgroundTransparency = 0
cred.BackgroundColor3 = Color3.new(0,0,0)
box.BorderSizePixel = 5
box.BorderColor3 = Color3.new(27,42,53)
cred.Font = "Arcade"
cred.FontSize = "Size24"
cred.TextColor3 = Color3.new(255,255,255)
cred.Text = "FE Animation Gui by Dark Magic Rblx!"
cred.TextSize = 19

c.MouseButton1Down:connect(function()
local AnimationId = gui["ID Here"].Text
local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://"..AnimationId
local Player = game.Players:FindFirstChild(gui.Namehere.Text)
if Player ~= nil then
local k = Player.Character.Humanoid:LoadAnimation(Anim)
k:Play()  
k:AdjustSpeed(gui["Speed Here"].Text)
end 
if gui.Namehere.Text =="me" then
local k = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
k:Play()  
k:AdjustSpeed(gui["Speed Here"].Text)	
end
if gui.Namehere.Text =="all" then
for i,v in pairs(game.Players:GetChildren()) do
local k = v.Character.Humanoid:LoadAnimation(Anim)
k:Play()  
k:AdjustSpeed(gui["Speed Here"].Text)	
end
end
end)
   

d.MouseButton1Down:connect(function()
local AnimationId = gui["ID Here"].Text
local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://"..AnimationId
local Player = game.Players:FindFirstChild(gui.Namehere.Text)
if Player ~= nil then
local k = Player.Character.Humanoid:LoadAnimation(Anim)
k:Play()  
k:AdjustSpeed(gui["Speed Here"].Text)
end 
if gui.Namehere.Text =="me" then
local k = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
k:Play()  
k:AdjustSpeed(gui["Speed Here"].Text)	
end
if gui.Namehere.Text =="all" then
for i,v in pairs(game.Players:GetChildren()) do
local k = v.Character.Humanoid:LoadAnimation(Anim)
k:Play()  
k:AdjustSpeed(gui["Speed Here"].Text)	
end
end
end)
end)

Frame.Parent = FEScriptHub
Frame.BackgroundColor3 = Color3.new(1, 1, 1)
Frame.Position = UDim2.new(0, 0, 0, 288)
Frame.Size = UDim2.new(0, 277, 0, 175)
Frame.Visible = false

TextBox69.Parent = Frame
TextBox69.BackgroundColor3 = Color3.new(1, 1, 1)
TextBox69.Position = UDim2.new(0, 38, 0, 30)
TextBox69.Size = UDim2.new(0, 200, 0, 50)
TextBox69.Font = Enum.Font.SourceSans
TextBox69.FontSize = Enum.FontSize.Size14
TextBox69.TextSize = 14

TextButton.Parent = Frame
TextButton.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton.Position = UDim2.new(0, 38, 0, 111)
TextButton.Size = UDim2.new(0, 200, 0, 50)
TextButton.Font = Enum.Font.SourceSans
TextButton.FontSize = Enum.FontSize.Size14
TextButton.Text = ""
TextButton.TextSize = 14

TextButton_2.Parent = Frame
TextButton_2.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_2.BackgroundTransparency = 1
TextButton_2.Position = UDim2.new(0, 240, 0, 0)
TextButton_2.Size = UDim2.new(0, 37, 0, 28)
TextButton_2.Font = Enum.Font.SourceSans
TextButton_2.FontSize = Enum.FontSize.Size14
TextButton_2.Text = "X"
TextButton_2.TextColor3 = Color3.new(1, 0, 0)
TextButton_2.TextScaled = true
TextButton_2.TextSize = 14
TextButton_2.TextWrapped = true

chatspam.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton.Text = "Spam"
end)

TextButton_2.MouseButton1Down:connect(function()
Frame.Visible = false
end)

TextButton.MouseButton1Down:connect(function()
succ = TextBox69.Text
if TextButton.Text == "Fling" then
Target = ""..succ

game:GetService('RunService').Stepped:connect(function()
   game.Players.LocalPlayer.Character.Head.CanCollide = false
   game.Players.LocalPlayer.Character.Torso.CanCollide = false
   game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
   game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
end)
b = Instance.new("RocketPropulsion")
b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
b.Target = game.Players[Target].Character.HumanoidRootPart
b.TurnP = 20000
b.MaxThrust = 20000
b.MaxSpeed = 1000
b.ThrustP = 13000
b:Fire()
end

if TextButton.Text == "Push" then
Target = ""..succ

game:GetService('RunService').Stepped:connect(function()
  game.Players.LocalPlayer.Character.Head.CanCollide = false
  game.Players.LocalPlayer.Character.Torso.CanCollide = false
  game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
  game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
end)
b = Instance.new("RocketPropulsion")
b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
b.Target = game.Players[Target].Character["Left Leg"]
b.TurnP = 2500
b.MaxThrust = 50000
b.MaxSpeed = 1000
b.ThrustP = 50000
b.CartoonFactor = 1
b:Fire()
end

if TextButton.Text == "Spam" then
while wait() do
wait(0.5)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(TextBox69.Text, "All")
end
end

if TextButton.Text == "Rape" then
local Victim=game.Players[TextBox69.Text].Character
local A=Instance.new'Animation' 
A.AnimationId='rbxassetid://148840371' 
local P=game:GetService'Players'.LocalPlayer 
local C=P.Character or P.CharacterAdded:Wait() 
local H=C:WaitForChild'Humanoid':LoadAnimation(A) 
H:Play() 
H:AdjustSpeed(5) 
game:GetService'RunService'.Stepped:Connect(function() 
 if Victim:findFirstChild("HumanoidRootPart") then
  game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = Victim.HumanoidRootPart.CFrame * CFrame.new(0,0,1.3)
 end
end)
end

if TextButton.Text == "Kill" then
Target = ""..succ

game.Players.LocalPlayer.Character.Humanoid.Name = 1
local l = game.Players.LocalPlayer.Character["1"]:Clone()
l.Parent = game.Players.LocalPlayer.Character
l.Name = "Humanoid"
wait(0.1)
game.Players.LocalPlayer.Character["1"]:Destroy()
game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
game.Players.LocalPlayer.Character.Animate.Disabled = true
wait(0.1)
game.Players.LocalPlayer.Character.Animate.Disabled = false
game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
end
wait(0.1)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[Target].Character.HumanoidRootPart.CFrame
wait(0.1)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[Target].Character.HumanoidRootPart.CFrame
wait(0.2)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(-10000,-100, -10000))
end

if TextButton.Text == "Teleport" then
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[TextBox69.Text].Character.HumanoidRootPart.CFrame
end

if TextButton.Text == "Bring" then
-- illremember's cool fe bring script
-- have a tool in backpack before execute
Target = ""..succ

NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
game.Players.LocalPlayer.Character.Humanoid.Name = 1
local l = game.Players.LocalPlayer.Character["1"]:Clone()
l.Parent = game.Players.LocalPlayer.Character
l.Name = "Humanoid"
wait(0.1)
game.Players.LocalPlayer.Character["1"]:Destroy()
game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
game.Players.LocalPlayer.Character.Animate.Disabled = true
wait(0.1)
game.Players.LocalPlayer.Character.Animate.Disabled = false
game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
end
local function tp(player,player2)
local char1,char2=player.Character,player2.Character
if char1 and char2 then
char1.HumanoidRootPart.CFrame = char2.HumanoidRootPart.CFrame
end
end
local function getout(player,player2)
local char1,char2=player.Character,player2.Character
if char1 and char2 then
char1:MoveTo(char2.Head.Position)
end
end
tp(game.Players[Target], game.Players.LocalPlayer)
wait(0.1)
tp(game.Players[Target], game.Players.LocalPlayer)
wait(0.3)
getout(game.Players.LocalPlayer, game.Players[Target])
wait(0.2)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
end

if TextButton.Text == "Torture" then
while wait (0.80) do
game.ReplicatedStorage.API.AdoptAPI.HoldBaby:FireServer(game.Players[TextBox69.Text])
game.ReplicatedStorage.API.AdoptAPI.EjectBaby:FireServer(game.Players[TextBox69.Text])
end
end
end)

kys.Name = "kys"
kys.Parent = Scripts
kys.BackgroundColor3 = Color3.new(0, 0, 0)
kys.BackgroundTransparency = 0.5
kys.Position = UDim2.new(0, 0, 0, 757)
kys.Size = UDim2.new(0, 200, 0, 50)
kys.Font = Enum.Font.SourceSans
kys.FontSize = Enum.FontSize.Size14
kys.Text = "Suicide Gun(City Life)"
kys.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
kys.TextSize = 14
kys.MouseButton1Down:connect(function()
--SUICIDE GUN REBORN BY DMS
-- made by harkinian and moon
-- jk its actually a edit by FroggysFriend#7364 lol
-- fuck off if u think this is skidded :P
-- extremely rare so dont leak :U
o1 = Instance.new("Tool")
o2 = Instance.new("Part")
o3 = Instance.new("SpecialMesh")
o4 = Instance.new("Part")
o5 = Instance.new("BlockMesh")
o6 = Instance.new("Part")
o7 = Instance.new("BlockMesh")
o8 = Instance.new("Part")
o9 = Instance.new("BlockMesh")
o10 = Instance.new("Part")
o11 = Instance.new("BlockMesh")
o12 = Instance.new("Part")
o13 = Instance.new("BlockMesh")
o14 = Instance.new("Part")
o15 = Instance.new("BlockMesh")
o16 = Instance.new("Part")
o17 = Instance.new("BlockMesh")
o18 = Instance.new("Part")
o19 = Instance.new("BlockMesh")
o20 = Instance.new("Part")
o21 = Instance.new("CylinderMesh")
o22 = Instance.new("Part")
o23 = Instance.new("CylinderMesh")
o24 = Instance.new("Part")
o25 = Instance.new("CylinderMesh")
o26 = Instance.new("Part")
o27 = Instance.new("BlockMesh")
o28 = Instance.new("Part")
o29 = Instance.new("CylinderMesh")
o30 = Instance.new("Part")
o31 = Instance.new("PointLight")
o32 = Instance.new("BillboardGui")
o33 = Instance.new("ImageLabel")
o34 = Instance.new("BlockMesh")
o35 = Instance.new("Part")
o36 = Instance.new("BlockMesh")
o37 = Instance.new("Part")
o38 = Instance.new("BlockMesh")
o39 = Instance.new("Part")
o40 = Instance.new("BlockMesh")
o41 = Instance.new("Part")
o42 = Instance.new("Decal")
o43 = Instance.new("CylinderMesh")
o44 = Instance.new("Part")
o45 = Instance.new("CylinderMesh")
o46 = Instance.new("Part")
o47 = Instance.new("BlockMesh")
o48 = Instance.new("Part")
o49 = Instance.new("SpecialMesh")
o50 = Instance.new("Part")
o51 = Instance.new("SpecialMesh")
o52 = Instance.new("Part")
o53 = Instance.new("BlockMesh")
o54 = Instance.new("Part")
o55 = Instance.new("BlockMesh")
o56 = Instance.new("Part")
o57 = Instance.new("BlockMesh")
o58 = Instance.new("Part")
o59 = Instance.new("CylinderMesh")
o60 = Instance.new("Part")
o61 = Instance.new("SpecialMesh")
o62 = Instance.new("Part")
o63 = Instance.new("BlockMesh")
o64 = Instance.new("Part")
o65 = Instance.new("SpecialMesh")
o66 = Instance.new("Part")
o67 = Instance.new("BlockMesh")
o68 = Instance.new("Part")
o69 = Instance.new("BlockMesh")
o70 = Instance.new("Part")
o71 = Instance.new("SpecialMesh")
o72 = Instance.new("Part")
o73 = Instance.new("BlockMesh")
o74 = Instance.new("Part")
o75 = Instance.new("BlockMesh")
o76 = Instance.new("Part")
o77 = Instance.new("BlockMesh")
o78 = Instance.new("Part")
o79 = Instance.new("SpecialMesh")
o80 = Instance.new("Part")
o81 = Instance.new("CylinderMesh")
o82 = Instance.new("Part")
o83 = Instance.new("SpecialMesh")
o84 = Instance.new("Part")
o85 = Instance.new("BlockMesh")
o86 = Instance.new("Part")
o87 = Instance.new("SpecialMesh")
o88 = Instance.new("Part")
o89 = Instance.new("SpecialMesh")
o90 = Instance.new("Part")
o91 = Instance.new("BlockMesh")
o92 = Instance.new("Part")
o93 = Instance.new("BlockMesh")
o94 = Instance.new("Part")
o95 = Instance.new("SpecialMesh")
o96 = Instance.new("Part")
o97 = Instance.new("BlockMesh")
o98 = Instance.new("Part")
o99 = Instance.new("SpecialMesh")
o100 = Instance.new("Part")
o101 = Instance.new("BlockMesh")
o102 = Instance.new("Part")
o103 = Instance.new("BlockMesh")
o104 = Instance.new("Part")
o105 = Instance.new("SpecialMesh")
o106 = Instance.new("Part")
o107 = Instance.new("BlockMesh")
o108 = Instance.new("Part")
o109 = Instance.new("CylinderMesh")
o110 = Instance.new("Part")
o111 = Instance.new("BlockMesh")
o112 = Instance.new("Part")
o113 = Instance.new("SpecialMesh")
o114 = Instance.new("Part")
o115 = Instance.new("CylinderMesh")
o116 = Instance.new("Part")
o117 = Instance.new("BlockMesh")
o118 = Instance.new("Part")
o119 = Instance.new("SpecialMesh")
o120 = Instance.new("Part")
o121 = Instance.new("BlockMesh")
o122 = Instance.new("Part")
o123 = Instance.new("SpecialMesh")
o124 = Instance.new("Part")
o125 = Instance.new("SpecialMesh")
o126 = Instance.new("Part")
o127 = Instance.new("BlockMesh")
o128 = Instance.new("Part")
o129 = Instance.new("BlockMesh")
o130 = Instance.new("Part")
o131 = Instance.new("SpecialMesh")
o132 = Instance.new("Part")
o133 = Instance.new("BlockMesh")
o134 = Instance.new("Part")
o135 = Instance.new("BlockMesh")
o136 = Instance.new("Part")
o137 = Instance.new("SpecialMesh")
o138 = Instance.new("Part")
o139 = Instance.new("BlockMesh")
o140 = Instance.new("Part")
o141 = Instance.new("CylinderMesh")
o142 = Instance.new("Part")
o143 = Instance.new("BlockMesh")
o144 = Instance.new("Part")
o145 = Instance.new("SpecialMesh")
o146 = Instance.new("Part")
o147 = Instance.new("SpecialMesh")
o148 = Instance.new("Part")
o149 = Instance.new("Sound")
o150 = Instance.new("BlockMesh")
o1.Name = "Suicide"
o1.Parent = game.Players.LocalPlayer.Backpack
o2.Parent = o1
o2.Material = Enum.Material.SmoothPlastic
o2.BrickColor = BrickColor.new("Really black")
o2.Position = Vector3.new(18.950964, 0.850407004, 14.2854338)
o2.Rotation = Vector3.new(-2.19040904e-013, 2.50129006e-006, -180)
o2.Anchored = true
o2.FormFactor = Enum.FormFactor.Custom
o2.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o2.CFrame = CFrame.new(18.950964, 0.850407004, 14.2854338, -1, 8.74227766e-008, 4.36557457e-008, -8.74227766e-008, -1, 3.82298495e-015, 4.36557457e-008, 3.92853881e-018, 1)
o2.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o2.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o2.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o2.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o2.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o2.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o2.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o3.Parent = o2
o3.Scale = Vector3.new(0.666666687, 0.388888866, 0.416666687)
o3.MeshType = Enum.MeshType.Wedge
o4.Parent = o1
o4.Material = Enum.Material.SmoothPlastic
o4.BrickColor = BrickColor.new("Really black")
o4.Position = Vector3.new(18.950964, 0.953182995, 14.5104237)
o4.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o4.Anchored = true
o4.FormFactor = Enum.FormFactor.Custom
o4.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o4.CFrame = CFrame.new(18.950964, 0.953182995, 14.5104237, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o4.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o4.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o4.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o4.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o4.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o4.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o4.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o5.Parent = o4
o5.Scale = Vector3.new(0.333333343, 0.194444433, 0.694444478)
o6.Parent = o1
o6.Material = Enum.Material.SmoothPlastic
o6.BrickColor = BrickColor.new("Black")
o6.Position = Vector3.new(18.950964, 1.13095105, 14.5993176)
o6.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o6.Anchored = true
o6.FormFactor = Enum.FormFactor.Custom
o6.Size = Vector3.new(0.566666663, 0.200000003, 0.200000003)
o6.CFrame = CFrame.new(18.950964, 1.13095105, 14.5993176, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o6.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o6.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o6.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o6.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o6.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o6.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o6.Color = Color3.new(0.105882, 0.164706, 0.207843)
o7.Parent = o6
o7.Scale = Vector3.new(1, 0.583333313, 0.722222269)
o8.Name = "SightBack"
o8.Parent = o1
o8.Material = Enum.Material.SmoothPlastic
o8.Position = Vector3.new(18.950964, 1.23151195, 14.4882116)
o8.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o8.Anchored = true
o8.FormFactor = Enum.FormFactor.Custom
o8.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o8.CFrame = CFrame.new(18.950964, 1.23151195, 14.4882116, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o8.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o8.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o8.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o8.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o8.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o8.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o9.Parent = o8
o9.Scale = Vector3.new(0.166666672, 0.111111112, 0.411111116)
o10.Parent = o1
o10.Material = Enum.Material.SmoothPlastic
o10.BrickColor = BrickColor.new("Really black")
o10.Position = Vector3.new(18.950964, 0.961513996, 14.5937595)
o10.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o10.Anchored = true
o10.FormFactor = Enum.FormFactor.Custom
o10.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o10.CFrame = CFrame.new(18.950964, 0.961513996, 14.5937595, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o10.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o10.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o10.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o10.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o10.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o10.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o10.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o11.Parent = o10
o11.Scale = Vector3.new(0.49999997, 0.277777761, 0.694444478)
o12.Parent = o1
o12.Material = Enum.Material.SmoothPlastic
o12.BrickColor = BrickColor.new("Really black")
o12.Position = Vector3.new(18.950964, 1.19539297, 14.5993176)
o12.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o12.Anchored = true
o12.FormFactor = Enum.FormFactor.Custom
o12.Size = Vector3.new(0.566666663, 0.200000003, 0.200000003)
o12.CFrame = CFrame.new(18.950964, 1.19539297, 14.5993176, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o12.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o12.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o12.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o12.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o12.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o12.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o12.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o13.Parent = o12
o13.Scale = Vector3.new(1, 0.249999985, 0.411111116)
o14.Parent = o1
o14.Material = Enum.Material.SmoothPlastic
o14.BrickColor = BrickColor.new("Really black")
o14.Position = Vector3.new(18.908186, 1.19095695, 14.5993176)
o14.Rotation = Vector3.new(-90, 44.9999962, 90)
o14.Anchored = true
o14.FormFactor = Enum.FormFactor.Custom
o14.Size = Vector3.new(0.566666663, 0.200000003, 0.200000003)
o14.CFrame = CFrame.new(18.908186, 1.19095695, 14.5993176, 0, -0.707106709, 0.707106709, 5.38120031e-018, 0.707106769, 0.707106769, -1, 2.04281037e-011, 9.59801127e-011)
o14.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o14.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o14.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o14.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o14.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o14.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o14.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o15.Parent = o14
o15.Scale = Vector3.new(1, 0.194444433, 0.222222224)
o16.Name = "SightBack"
o16.Parent = o1
o16.Material = Enum.Material.SmoothPlastic
o16.Position = Vector3.new(18.9787407, 1.25372696, 14.4882116)
o16.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o16.Anchored = true
o16.FormFactor = Enum.FormFactor.Custom
o16.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o16.CFrame = CFrame.new(18.9787407, 1.25372696, 14.4882116, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o16.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o16.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o16.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o16.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o16.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o16.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o17.Parent = o16
o17.Scale = Vector3.new(0.166666672, 0.111111112, 0.13333334)
o18.Name = "SightBack"
o18.Parent = o1
o18.Material = Enum.Material.SmoothPlastic
o18.Position = Vector3.new(18.9231701, 1.25372696, 14.4882002)
o18.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o18.Anchored = true
o18.FormFactor = Enum.FormFactor.Custom
o18.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o18.CFrame = CFrame.new(18.9231701, 1.25372696, 14.4882002, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o18.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o18.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o18.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o18.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o18.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o18.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o19.Parent = o18
o19.Scale = Vector3.new(0.166666672, 0.111111112, 0.13333334)
o20.Parent = o1
o20.Material = Enum.Material.SmoothPlastic
o20.BrickColor = BrickColor.new("Black")
o20.Position = Vector3.new(18.950964, 0.886528015, 14.5798664)
o20.Rotation = Vector3.new(-90, -2.50447761e-006, -90)
o20.Anchored = true
o20.FormFactor = Enum.FormFactor.Custom
o20.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o20.CFrame = CFrame.new(18.950964, 0.886528015, 14.5798664, -8.74279067e-008, 1, -4.37113812e-008, -3.83195418e-015, 4.37113812e-008, 1, 1, 8.74279067e-008, -4.65359901e-018)
o20.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o20.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o20.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o20.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o20.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o20.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o20.Color = Color3.new(0.105882, 0.164706, 0.207843)
o21.Parent = o20
o21.Scale = Vector3.new(0.416666687, 0.722222269, 0.416666687)
o22.Name = "SightLine"
o22.Parent = o1
o22.Material = Enum.Material.SmoothPlastic
o22.BrickColor = BrickColor.new("Smoky grey")
o22.Position = Vector3.new(18.950964, 1.21539295, 15.7804356)
o22.Rotation = Vector3.new(90, -2.50447761e-006, -90)
o22.Anchored = true
o22.FormFactor = Enum.FormFactor.Custom
o22.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o22.CFrame = CFrame.new(18.950964, 1.21539295, 15.7804356, 0, 1, -4.37113812e-008, 5.38120031e-018, -4.37113812e-008, -1, -1, 0, 6.1083781e-018)
o22.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o22.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o22.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o22.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o22.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o22.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o22.Color = Color3.new(0.356863, 0.364706, 0.411765)
o23.Parent = o22
o23.Scale = Vector3.new(0.505999982, 0.150000006, 0.505999982)
o24.Parent = o1
o24.Material = Enum.Material.SmoothPlastic
o24.BrickColor = BrickColor.new("Black")
o24.Position = Vector3.new(18.950964, 0.96707201, 15.7326679)
o24.Rotation = Vector3.new(-90, -2.50447761e-006, -180)
o24.Anchored = true
o24.FormFactor = Enum.FormFactor.Custom
o24.Size = Vector3.new(0.200000003, 0.344444454, 0.200000003)
o24.CFrame = CFrame.new(18.950964, 0.96707201, 15.7326679, -1, 4.36557457e-008, -4.37113812e-008, -4.37113812e-008, 1.9122997e-015, 1, 4.36557457e-008, 1, -4.65359901e-018)
o24.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o24.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o24.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o24.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o24.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o24.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o24.Color = Color3.new(0.105882, 0.164706, 0.207843)
o25.Parent = o24
o25.Scale = Vector3.new(0.405599982, 1, 0.405599982)
o26.Parent = o1
o26.Material = Enum.Material.SmoothPlastic
o26.BrickColor = BrickColor.new("Black")
o26.Position = Vector3.new(18.950964, 1.01984501, 15.7298756)
o26.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o26.Anchored = true
o26.FormFactor = Enum.FormFactor.Custom
o26.Size = Vector3.new(0.338888884, 0.200000003, 0.200000003)
o26.CFrame = CFrame.new(18.950964, 1.01984501, 15.7298756, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o26.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o26.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o26.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o26.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o26.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o26.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o26.Color = Color3.new(0.105882, 0.164706, 0.207843)
o27.Parent = o26
o27.Scale = Vector3.new(1, 0.527777731, 0.611111104)
o28.Parent = o1
o28.Material = Enum.Material.SmoothPlastic
o28.BrickColor = BrickColor.new("Black")
o28.Position = Vector3.new(18.950964, 0.96707201, 15.7298756)
o28.Rotation = Vector3.new(-90, -2.50447761e-006, -180)
o28.Anchored = true
o28.FormFactor = Enum.FormFactor.Custom
o28.Size = Vector3.new(0.200000003, 0.338888884, 0.200000003)
o28.CFrame = CFrame.new(18.950964, 0.96707201, 15.7298756, -1, 4.36557457e-008, -4.37113812e-008, -4.37113812e-008, 1.9122997e-015, 1, 4.36557457e-008, 1, -4.65359901e-018)
o28.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o28.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o28.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o28.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o28.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o28.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o28.Color = Color3.new(0.105882, 0.164706, 0.207843)
o29.Parent = o28
o29.Scale = Vector3.new(0.611111104, 1, 0.611111104)
o30.Name = "Main"
o30.Parent = o1
o30.Material = Enum.Material.SmoothPlastic
o30.BrickColor = BrickColor.new("Really black")
o30.Transparency = 1
o30.Position = Vector3.new(18.950964, 1.12816894, 15.9493256)
o30.Rotation = Vector3.new(90, -2.50447761e-006, 2.50796006e-006)
o30.Anchored = true
o30.FormFactor = Enum.FormFactor.Custom
o30.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o30.CFrame = CFrame.new(18.950964, 1.12816894, 15.9493256, 1, -4.3772161e-008, -4.37113812e-008, -4.37113812e-008, -1.49011594e-008, -1, 4.3772161e-008, 1, -1.49011603e-008)
o30.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o30.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o30.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o30.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o30.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o30.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o30.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o31.Name = "FlashFX"
o31.Parent = o30
o31.Color = Color3.new(1, 1, 0)
o31.Enabled = false
o31.Brightness = 10
o31.Range = 6
o31.Shadows = true
o32.Name = "FlashGui"
o32.Parent = o30
o32.Size = UDim2.new(1.1000000238419,0,1.1000000238419,0)
o32.Enabled = false
o33.Name = "Label"
o33.Parent = o32
o33.Size = UDim2.new(1,0,1,0)
o33.BackgroundTransparency = 1
o33.Image = "http://www.roblox.com/asset/?id=117472237"
o34.Parent = o30
o34.Scale = Vector3.new(0.99999994, 0.99999994, 0.99999994)
o35.Parent = o1
o35.Material = Enum.Material.SmoothPlastic
o35.BrickColor = BrickColor.new("Black")
o35.Position = Vector3.new(18.908186, 1.19095695, 15.5132236)
o35.Rotation = Vector3.new(-90, 44.9999962, 90)
o35.Anchored = true
o35.FormFactor = Enum.FormFactor.Custom
o35.Size = Vector3.new(0.772222221, 0.200000003, 0.200000003)
o35.CFrame = CFrame.new(18.908186, 1.19095695, 15.5132236, 0, -0.707106709, 0.707106709, 5.38120031e-018, 0.707106769, 0.707106769, -1, 2.04281037e-011, 9.59801127e-011)
o35.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o35.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o35.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o35.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o35.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o35.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o35.Color = Color3.new(0.105882, 0.164706, 0.207843)
o36.Parent = o35
o36.Scale = Vector3.new(1, 0.194444433, 0.222222224)
o37.Parent = o1
o37.Material = Enum.Material.SmoothPlastic
o37.BrickColor = BrickColor.new("Black")
o37.Position = Vector3.new(18.950964, 1.19539297, 15.5132236)
o37.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o37.Anchored = true
o37.FormFactor = Enum.FormFactor.Custom
o37.Size = Vector3.new(0.772222221, 0.200000003, 0.200000003)
o37.CFrame = CFrame.new(18.950964, 1.19539297, 15.5132236, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o37.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o37.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o37.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o37.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o37.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o37.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o37.Color = Color3.new(0.105882, 0.164706, 0.207843)
o38.Parent = o37
o38.Scale = Vector3.new(1, 0.249999985, 0.411111116)
o39.Parent = o1
o39.Material = Enum.Material.SmoothPlastic
o39.BrickColor = BrickColor.new("Black")
o39.Position = Vector3.new(18.950964, 1.13095105, 15.5132236)
o39.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o39.Anchored = true
o39.FormFactor = Enum.FormFactor.Custom
o39.Size = Vector3.new(0.772222221, 0.200000003, 0.200000003)
o39.CFrame = CFrame.new(18.950964, 1.13095105, 15.5132236, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o39.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o39.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o39.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o39.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o39.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o39.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o39.Color = Color3.new(0.105882, 0.164706, 0.207843)
o40.Parent = o39
o40.Scale = Vector3.new(1, 0.583333313, 0.722222269)
o41.Parent = o1
o41.Material = Enum.Material.SmoothPlastic
o41.BrickColor = BrickColor.new("Black")
o41.Position = Vector3.new(18.950964, 1.12816894, 15.3854284)
o41.Rotation = Vector3.new(-90, -2.50447761e-006, -180)
o41.Anchored = true
o41.FormFactor = Enum.FormFactor.Custom
o41.Size = Vector3.new(0.200000003, 1.06111109, 0.200000003)
o41.CFrame = CFrame.new(18.950964, 1.12816894, 15.3854284, -1, 4.36557457e-008, -4.37113812e-008, -4.37113812e-008, 1.9122997e-015, 1, 4.36557457e-008, 1, -4.65359901e-018)
o41.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o41.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o41.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o41.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o41.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o41.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o41.Color = Color3.new(0.105882, 0.164706, 0.207843)
o42.Parent = o41
o42.Texture = "http://www.roblox.com/asset/?id=47760372"
o42.Face = Enum.NormalId.Top
o43.Parent = o41
o43.Scale = Vector3.new(0.49999997, 1, 0.49999997)
o44.Parent = o1
o44.Material = Enum.Material.SmoothPlastic
o44.BrickColor = BrickColor.new("Black")
o44.Position = Vector3.new(18.950964, 0.961513996, 15.352108)
o44.Rotation = Vector3.new(-90, -2.50447761e-006, -180)
o44.Anchored = true
o44.FormFactor = Enum.FormFactor.Custom
o44.Size = Vector3.new(0.200000003, 0.416666627, 0.200000003)
o44.CFrame = CFrame.new(18.950964, 0.961513996, 15.352108, -1, 4.36557457e-008, -4.37113812e-008, -4.37113812e-008, 1.9122997e-015, 1, 4.36557457e-008, 1, -4.65359901e-018)
o44.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o44.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o44.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o44.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o44.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o44.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o44.Color = Color3.new(0.105882, 0.164706, 0.207843)
o45.Parent = o44
o45.Scale = Vector3.new(0.666666687, 1, 0.666666687)
o46.Name = "Mag"
o46.Parent = o1
o46.Material = Enum.Material.SmoothPlastic
o46.BrickColor = BrickColor.new("Black")
o46.Position = Vector3.new(18.950964, 0.129971996, 14.3866644)
o46.Rotation = Vector3.new(101, 90, 0)
o46.Anchored = true
o46.FormFactor = Enum.FormFactor.Custom
o46.Size = Vector3.new(0.200000003, 0.333333343, 0.200000003)
o46.CFrame = CFrame.new(18.950964, 0.129971996, 14.3866644, -2.79885857e-008, -5.49657244e-008, 1, 0.981627166, -0.190809026, 1.69563066e-008, 0.190809026, 0.981627107, 5.93718141e-008)
o46.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o46.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o46.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o46.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o46.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o46.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o46.Color = Color3.new(0.105882, 0.164706, 0.207843)
o47.Parent = o46
o47.Scale = Vector3.new(0.027777778, 1, 0.666666687)
o48.Parent = o1
o48.Material = Enum.Material.SmoothPlastic
o48.BrickColor = BrickColor.new("Black")
o48.Position = Vector3.new(18.950964, 0.161533996, 14.3493176)
o48.Rotation = Vector3.new(0.019784553, -6.66929267e-009, 180)
o48.Anchored = true
o48.FormFactor = Enum.FormFactor.Custom
o48.Size = Vector3.new(0.200000003, 0.200000003, 0.266666681)
o48.CFrame = CFrame.new(18.950964, 0.161533996, 14.3493176, -1, -8.74227979e-008, -1.16401111e-010, 8.74227766e-008, -0.99999994, -0.000345305598, 0, -0.000345305569, 0.99999994)
o48.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o48.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o48.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o48.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o48.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o48.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o48.Color = Color3.new(0.105882, 0.164706, 0.207843)
o49.Parent = o48
o49.Scale = Vector3.new(0.694444478, 0.222222224, 1)
o49.MeshType = Enum.MeshType.Wedge
o50.Parent = o1
o50.Material = Enum.Material.SmoothPlastic
o50.BrickColor = BrickColor.new("Really black")
o50.Position = Vector3.new(18.950964, 0.155975997, 14.3354216)
o50.Rotation = Vector3.new(3.08320072e-016, 0, -180)
o50.Anchored = true
o50.FormFactor = Enum.FormFactor.Custom
o50.Size = Vector3.new(0.200000003, 0.200000003, 0.438888878)
o50.CFrame = CFrame.new(18.950964, 0.155975997, 14.3354216, -1, 1.0960446e-021, 0, 1.0960446e-021, -1, -5.38120031e-018, 0, 5.38120031e-018, 1)
o50.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o50.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o50.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o50.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o50.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o50.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o50.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o51.Parent = o50
o51.Scale = Vector3.new(0.666666687, 0.333333343, 1)
o51.MeshType = Enum.MeshType.Wedge
o52.Parent = o1
o52.Material = Enum.Material.SmoothPlastic
o52.BrickColor = BrickColor.new("Black")
o52.Position = Vector3.new(18.950964, 0.239300996, 14.1882057)
o52.Rotation = Vector3.new(105, 90, 0)
o52.Anchored = true
o52.FormFactor = Enum.FormFactor.Custom
o52.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o52.CFrame = CFrame.new(18.950964, 0.239300996, 14.1882057, -1.07331601e-008, -6.40018527e-008, 1, 0.965925813, -0.258819044, -6.21114538e-009, 0.258819073, 0.965925813, 6.46105036e-008)
o52.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o52.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o52.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o52.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o52.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o52.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o52.Color = Color3.new(0.105882, 0.164706, 0.207843)
o53.Parent = o52
o53.Scale = Vector3.new(0.944444478, 0.111111112, 0.611111104)
o54.Parent = o1
o54.Material = Enum.Material.SmoothPlastic
o54.BrickColor = BrickColor.new("Really black")
o54.Position = Vector3.new(18.950964, 0.225419, 14.3520937)
o54.Rotation = Vector3.new(-3.25256337e-007, 90, 0)
o54.Anchored = true
o54.FormFactor = Enum.FormFactor.Custom
o54.Size = Vector3.new(0.26111111, 0.200000003, 0.200000003)
o54.CFrame = CFrame.new(18.950964, 0.225419, 14.3520937, 8.94069672e-008, -6.24762481e-015, 1, -5.6767937e-009, 1, 1.42108539e-014, -1, -5.6767937e-009, 8.94069672e-008)
o54.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o54.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o54.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o54.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o54.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o54.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o54.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o55.Parent = o54
o55.Scale = Vector3.new(1, 0.416666687, 0.694444478)
o56.Parent = o1
o56.Material = Enum.Material.SmoothPlastic
o56.BrickColor = BrickColor.new("Really black")
o56.Position = Vector3.new(18.950964, 0.197641, 14.2215319)
o56.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o56.Anchored = true
o56.FormFactor = Enum.FormFactor.Custom
o56.Size = Vector3.new(0.211111099, 0.200000003, 0.200000003)
o56.CFrame = CFrame.new(18.950964, 0.197641, 14.2215319, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o56.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o56.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o56.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o56.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o56.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o56.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o56.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o57.Parent = o56
o57.Scale = Vector3.new(1, 0.0833333358, 0.666666687)
o58.Parent = o1
o58.Material = Enum.Material.SmoothPlastic
o58.BrickColor = BrickColor.new("Really black")
o58.Position = Vector3.new(18.950964, 0.258204013, 14.3493176)
o58.Rotation = Vector3.new(-90, -2.50447761e-006, -90)
o58.Anchored = true
o58.FormFactor = Enum.FormFactor.Custom
o58.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o58.CFrame = CFrame.new(18.950964, 0.258204013, 14.3493176, -8.74279067e-008, 1, -4.37113812e-008, -3.83195418e-015, 4.37113812e-008, 1, 1, 8.74279067e-008, -4.65359901e-018)
o58.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o58.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o58.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o58.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o58.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o58.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o58.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o59.Parent = o58
o59.Scale = Vector3.new(0.49999997, 0.722222269, 0.472222239)
o60.Parent = o1
o60.Material = Enum.Material.SmoothPlastic
o60.BrickColor = BrickColor.new("Really black")
o60.Position = Vector3.new(18.950964, 0.244874001, 14.1993141)
o60.Rotation = Vector3.new(0.019784553, -6.66929267e-009, 180)
o60.Anchored = true
o60.FormFactor = Enum.FormFactor.Custom
o60.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o60.CFrame = CFrame.new(18.950964, 0.244874001, 14.1993141, -1, -8.74227979e-008, -1.16401111e-010, 8.74227766e-008, -0.99999994, -0.000345305598, 0, -0.000345305569, 0.99999994)
o60.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o60.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o60.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o60.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o60.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o60.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o60.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o61.Parent = o60
o61.Scale = Vector3.new(0.694444478, 0.222222224, 0.222222224)
o61.MeshType = Enum.MeshType.Wedge
o62.Parent = o1
o62.Material = Enum.Material.SmoothPlastic
o62.BrickColor = BrickColor.new("Black")
o62.Position = Vector3.new(18.993742, 1.19095695, 15.1076584)
o62.Rotation = Vector3.new(90, 44.9999962, -90)
o62.Anchored = true
o62.FormFactor = Enum.FormFactor.Custom
o62.Size = Vector3.new(1.58333337, 0.200000003, 0.200000003)
o62.CFrame = CFrame.new(18.993742, 1.19095695, 15.1076584, 0, 0.707106709, 0.707106709, 5.38120031e-018, 0.707106769, -0.707106769, -1, 9.59801127e-011, -2.04281037e-011)
o62.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o62.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o62.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o62.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o62.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o62.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o62.Color = Color3.new(0.105882, 0.164706, 0.207843)
o63.Parent = o62
o63.Scale = Vector3.new(1, 0.194444433, 0.222222224)
o64.Parent = o1
o64.Material = Enum.Material.SmoothPlastic
o64.Position = Vector3.new(18.950964, 0.867092013, 15.1298876)
o64.Rotation = Vector3.new(180, 2.50796006e-006, 8.65142192e-006)
o64.Anchored = true
o64.FormFactor = Enum.FormFactor.Custom
o64.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o64.CFrame = CFrame.new(18.950964, 0.867092013, 15.1298876, 1, -1.50995803e-007, 4.3772161e-008, -1.50995803e-007, -1, -6.59664855e-015, 4.3772161e-008, 3.92853881e-018, -1)
o64.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o64.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o64.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o64.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o64.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o64.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o65.Parent = o64
o65.Scale = Vector3.new(0.611111104, 0.333333343, 0.138888881)
o65.MeshType = Enum.MeshType.Wedge
o66.Parent = o1
o66.Material = Enum.Material.SmoothPlastic
o66.Position = Vector3.new(18.950964, 0.83930999, 15.1048679)
o66.Rotation = Vector3.new(89.9999771, 90, 0)
o66.Anchored = true
o66.FormFactor = Enum.FormFactor.Custom
o66.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o66.CFrame = CFrame.new(18.950964, 0.83930999, 15.1048679, -8.74231674e-008, 2.50292942e-008, 1, 1, 4.33125763e-007, 8.74231461e-008, -4.33125791e-007, 1, -2.50292942e-008)
o66.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o66.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o66.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o66.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o66.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o66.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o67.Parent = o66
o67.Scale = Vector3.new(0.944444478, 0.111111112, 0.611111104)
o68.Parent = o1
o68.Material = Enum.Material.SmoothPlastic
o68.BrickColor = BrickColor.new("Fossil")
o68.Position = Vector3.new(18.950964, 0.716949999, 15.0719404)
o68.Rotation = Vector3.new(-45, 90, 0)
o68.Anchored = true
o68.FormFactor = Enum.FormFactor.Custom
o68.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o68.CFrame = CFrame.new(18.950964, 0.716949999, 15.0719404, -1.36843425e-010, -2.04281037e-011, 1, -0.707106769, 0.707106769, -1.0960446e-021, -0.707106709, -0.707106709, 0)
o68.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o68.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o68.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o68.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o68.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o68.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o68.Color = Color3.new(0.623529, 0.631373, 0.67451)
o69.Parent = o68
o69.Scale = Vector3.new(0.527777731, 0.111111112, 0.611111104)
o70.Parent = o1
o70.Material = Enum.Material.SmoothPlastic
o70.BrickColor = BrickColor.new("Black")
o70.Position = Vector3.new(18.950964, 0.875427008, 15.0743237)
o70.Rotation = Vector3.new(3.08320072e-016, 0, -180)
o70.Anchored = true
o70.FormFactor = Enum.FormFactor.Custom
o70.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o70.CFrame = CFrame.new(18.950964, 0.875427008, 15.0743237, -1, 1.0960446e-021, 0, 1.0960446e-021, -1, -5.38120031e-018, 0, 5.38120031e-018, 1)
o70.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o70.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o70.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o70.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o70.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o70.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o70.Color = Color3.new(0.105882, 0.164706, 0.207843)
o71.Parent = o70
o71.Scale = Vector3.new(0.611111104, 0.249999985, 0.194444433)
o71.MeshType = Enum.MeshType.Wedge
o72.Parent = o1
o72.Material = Enum.Material.SmoothPlastic
o72.BrickColor = BrickColor.new("Black")
o72.Position = Vector3.new(18.9315281, 1.09817195, 15.0048761)
o72.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o72.Anchored = true
o72.FormFactor = Enum.FormFactor.Custom
o72.Size = Vector3.new(0.244444445, 0.200000003, 0.200000003)
o72.CFrame = CFrame.new(18.9315281, 1.09817195, 15.0048761, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o72.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o72.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o72.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o72.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o72.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o72.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o72.Color = Color3.new(0.105882, 0.164706, 0.207843)
o73.Parent = o72
o73.Scale = Vector3.new(1, 0.277777761, 0.527777731)
o74.Parent = o1
o74.Material = Enum.Material.SmoothPlastic
o74.BrickColor = BrickColor.new("Black")
o74.Position = Vector3.new(18.9870701, 1.13095105, 15.0048761)
o74.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o74.Anchored = true
o74.FormFactor = Enum.FormFactor.Custom
o74.Size = Vector3.new(0.244444445, 0.200000003, 0.200000003)
o74.CFrame = CFrame.new(18.9870701, 1.13095105, 15.0048761, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o74.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o74.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o74.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o74.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o74.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o74.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o74.Color = Color3.new(0.105882, 0.164706, 0.207843)
o75.Parent = o74
o75.Scale = Vector3.new(1, 0.583333313, 0.361111134)
o76.Parent = o1
o76.Material = Enum.Material.SmoothPlastic
o76.BrickColor = BrickColor.new("Black")
o76.Position = Vector3.new(18.970396, 1.17595196, 15.0048761)
o76.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o76.Anchored = true
o76.FormFactor = Enum.FormFactor.Custom
o76.Size = Vector3.new(0.244444445, 0.200000003, 0.200000003)
o76.CFrame = CFrame.new(18.970396, 1.17595196, 15.0048761, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o76.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o76.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o76.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o76.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o76.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o76.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o76.Color = Color3.new(0.105882, 0.164706, 0.207843)
o77.Parent = o76
o77.Scale = Vector3.new(1, 0.444444448, 0.216666669)
o78.Parent = o1
o78.Material = Enum.Material.SmoothPlastic
o78.BrickColor = BrickColor.new("Black")
o78.Position = Vector3.new(18.950964, 0.39764601, 14.6493216)
o78.Rotation = Vector3.new(180, 2.50796006e-006, 5.00895612e-006)
o78.Anchored = true
o78.FormFactor = Enum.FormFactor.Custom
o78.Size = Vector3.new(0.200000003, 0.550000012, 0.200000003)
o78.CFrame = CFrame.new(18.950964, 0.39764601, 14.6493216, 1, -8.74227766e-008, 4.3772161e-008, -8.74227766e-008, -1, -3.8177829e-015, 4.3772161e-008, 6.83386182e-018, -1)
o78.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o78.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o78.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o78.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o78.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o78.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o78.Color = Color3.new(0.105882, 0.164706, 0.207843)
o79.Parent = o78
o79.Scale = Vector3.new(0.666666687, 1, 0.944444478)
o79.MeshType = Enum.MeshType.Wedge
o80.Parent = o1
o80.Material = Enum.Material.SmoothPlastic
o80.BrickColor = BrickColor.new("Black")
o80.Position = Vector3.new(18.8859501, 0.96707201, 15.0021019)
o80.Rotation = Vector3.new(-90, -2.50447761e-006, -90.0000076)
o80.Anchored = true
o80.FormFactor = Enum.FormFactor.Custom
o80.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o80.CFrame = CFrame.new(18.8859501, 0.96707201, 15.0021019, -1.51107088e-007, 1, -4.37113812e-008, -6.60488848e-015, 4.37113812e-008, 1, 1, 1.51107088e-007, -4.65359901e-018)
o80.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o80.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o80.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o80.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o80.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o80.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o80.Color = Color3.new(0.105882, 0.164706, 0.207843)
o81.Parent = o80
o81.Scale = Vector3.new(0.249999985, 0.027777778, 0.249999985)
o82.Parent = o1
o82.Material = Enum.Material.SmoothPlastic
o82.BrickColor = BrickColor.new("Dark stone grey")
o82.Position = Vector3.new(18.950964, 0.858749986, 14.8770924)
o82.Rotation = Vector3.new(-180, -2.50796256e-006, 5.00895703e-006)
o82.Anchored = true
o82.FormFactor = Enum.FormFactor.Custom
o82.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o82.CFrame = CFrame.new(18.950964, 0.858749986, 14.8770924, 0.99999994, -8.74227837e-008, -4.37722036e-008, -8.74227837e-008, -0.99999994, 7.17606313e-018, -4.36557599e-008, 1.89421216e-015, -0.999999762)
o82.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o82.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o82.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o82.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o82.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o82.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o82.Color = Color3.new(0.388235, 0.372549, 0.384314)
o83.Parent = o82
o83.Scale = Vector3.new(0.472222239, 0.416666687, 0.222222224)
o83.MeshType = Enum.MeshType.Wedge
o84.Parent = o1
o84.Material = Enum.Material.SmoothPlastic
o84.BrickColor = BrickColor.new("Black")
o84.Position = Vector3.new(18.950964, 1.05040395, 14.9382162)
o84.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o84.Anchored = true
o84.FormFactor = Enum.FormFactor.Custom
o84.Size = Vector3.new(1.24444449, 0.200000003, 0.200000003)
o84.CFrame = CFrame.new(18.950964, 1.05040395, 14.9382162, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o84.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o84.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o84.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o84.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o84.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o84.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o84.Color = Color3.new(0.105882, 0.164706, 0.207843)
o85.Parent = o84
o85.Scale = Vector3.new(1, 0.222222224, 0.722222269)
o86.Parent = o1
o86.Material = Enum.Material.SmoothPlastic
o86.BrickColor = BrickColor.new("Black")
o86.Position = Vector3.new(18.950964, 0.469879985, 14.2215319)
o86.Rotation = Vector3.new(2.05579065e-016, -2.50796006e-006, 6.27987314e-020)
o86.Anchored = true
o86.FormFactor = Enum.FormFactor.Custom
o86.Size = Vector3.new(0.200000003, 0.527777791, 0.211111099)
o86.CFrame = CFrame.new(18.950964, 0.469879985, 14.2215319, 1, -1.0960446e-021, -4.3772161e-008, -7.78546341e-022, 1, -3.58803156e-018, 4.3772161e-008, -5.38120031e-018, 1)
o86.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o86.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o86.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o86.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o86.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o86.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o86.Color = Color3.new(0.105882, 0.164706, 0.207843)
o87.Parent = o86
o87.Scale = Vector3.new(0.666666687, 1, 1)
o87.MeshType = Enum.MeshType.Wedge
o88.Parent = o1
o88.Material = Enum.Material.SmoothPlastic
o88.BrickColor = BrickColor.new("Dark stone grey")
o88.Position = Vector3.new(18.950964, 0.736557007, 14.8798761)
o88.Rotation = Vector3.new(180, -2.50129006e-006, 180)
o88.Anchored = true
o88.FormFactor = Enum.FormFactor.Custom
o88.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o88.CFrame = CFrame.new(18.950964, 0.736557007, 14.8798761, -1, -1.0960446e-021, -4.36557457e-008, 1.41269847e-021, 1, -1.6144448e-018, 4.36557457e-008, -5.38120031e-018, -1)
o88.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o88.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o88.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o88.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o88.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o88.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o88.Color = Color3.new(0.388235, 0.372549, 0.384314)
o89.Parent = o88
o89.Scale = Vector3.new(0.472222239, 0.416666687, 0.249999985)
o89.MeshType = Enum.MeshType.Wedge
o90.Parent = o1
o90.Material = Enum.Material.SmoothPlastic
o90.BrickColor = BrickColor.new("Smoky grey")
o90.Position = Vector3.new(18.950964, 0.683766007, 14.9020796)
o90.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o90.Anchored = true
o90.FormFactor = Enum.FormFactor.Custom
o90.Size = Vector3.new(0.283333331, 0.200000003, 0.200000003)
o90.CFrame = CFrame.new(18.950964, 0.683766007, 14.9020796, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o90.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o90.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o90.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o90.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o90.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o90.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o90.Color = Color3.new(0.356863, 0.364706, 0.411765)
o91.Parent = o90
o91.Scale = Vector3.new(1, 0.111111112, 0.611111104)
o92.Parent = o1
o92.Material = Enum.Material.SmoothPlastic
o92.BrickColor = BrickColor.new("Black")
o92.Position = Vector3.new(18.950964, 0.992074013, 14.9382162)
o92.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o92.Anchored = true
o92.FormFactor = Enum.FormFactor.Custom
o92.Size = Vector3.new(1.24444449, 0.200000003, 0.200000003)
o92.CFrame = CFrame.new(18.950964, 0.992074013, 14.9382162, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o92.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o92.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o92.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o92.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o92.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o92.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o92.Color = Color3.new(0.105882, 0.164706, 0.207843)
o93.Parent = o92
o93.Scale = Vector3.new(1, 0.361111134, 0.666666687)
o94.Parent = o1
o94.Material = Enum.Material.SmoothPlastic
o94.BrickColor = BrickColor.new("Black")
o94.Position = Vector3.new(18.950964, 0.708733976, 14.827096)
o94.Rotation = Vector3.new(-180, 0.0927856117, 180)
o94.Anchored = true
o94.FormFactor = Enum.FormFactor.Custom
o94.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o94.CFrame = CFrame.new(18.950964, 0.708733976, 14.827096, -0.999998689, -1.0960446e-021, 0.00161941373, -1.1745207e-017, 1, 4.66291637e-018, -0.00161941373, -5.38120031e-018, -0.999998689)
o94.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o94.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o94.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o94.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o94.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o94.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o94.Color = Color3.new(0.105882, 0.164706, 0.207843)
o95.Parent = o94
o95.Scale = Vector3.new(0.611111104, 0.138888881, 0.249999985)
o95.MeshType = Enum.MeshType.Wedge
o96.Parent = o1
o96.Material = Enum.Material.SmoothPlastic
o96.BrickColor = BrickColor.new("Black")
o96.Position = Vector3.new(18.950964, 0.797657013, 14.8104324)
o96.Rotation = Vector3.new(180, -2.50129006e-006, 180)
o96.Anchored = true
o96.FormFactor = Enum.FormFactor.Custom
o96.Size = Vector3.new(0.200000003, 0.205555543, 0.200000003)
o96.CFrame = CFrame.new(18.950964, 0.797657013, 14.8104324, -1, -1.0960446e-021, -4.36557457e-008, 1.41269847e-021, 1, -1.6144448e-018, 4.36557457e-008, -5.38120031e-018, -1)
o96.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o96.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o96.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o96.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o96.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o96.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o96.Color = Color3.new(0.105882, 0.164706, 0.207843)
o97.Parent = o96
o97.Scale = Vector3.new(0.472222239, 1, 0.444444448)
o98.Parent = o1
o98.Material = Enum.Material.SmoothPlastic
o98.BrickColor = BrickColor.new("Black")
o98.Position = Vector3.new(18.950964, 0.875427008, 14.8298864)
o98.Rotation = Vector3.new(-180, 0, -6.27987314e-020)
o98.Anchored = true
o98.FormFactor = Enum.FormFactor.Custom
o98.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o98.CFrame = CFrame.new(18.950964, 0.875427008, 14.8298864, 1, 1.0960446e-021, 0, -1.0960446e-021, -1, 5.38120031e-018, 0, 5.38120031e-018, -1)
o98.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o98.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o98.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o98.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o98.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o98.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o98.Color = Color3.new(0.105882, 0.164706, 0.207843)
o99.Parent = o98
o99.Scale = Vector3.new(0.666666687, 0.249999985, 0.194444433)
o99.MeshType = Enum.MeshType.Wedge
o100.Parent = o1
o100.Material = Enum.Material.SmoothPlastic
o100.BrickColor = BrickColor.new("Black")
o100.Position = Vector3.new(18.988184, 0.986526012, 14.8076496)
o100.Rotation = Vector3.new(3.00000024, 90, 0)
o100.Anchored = true
o100.FormFactor = Enum.FormFactor.Custom
o100.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o100.CFrame = CFrame.new(18.988184, 0.986526012, 14.8076496, 2.57358579e-011, -6.64535094e-012, 1, 0.0523359589, 0.99862951, -1.0960446e-021, -0.99862951, 0.0523359627, 0)
o100.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o100.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o100.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o100.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o100.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o100.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o100.Color = Color3.new(0.105882, 0.164706, 0.207843)
o101.Parent = o100
o101.Scale = Vector3.new(0.694444478, 0.249999985, 0.361111134)
o102.Parent = o1
o102.Material = Enum.Material.SmoothPlastic
o102.BrickColor = BrickColor.new("Black")
o102.Position = Vector3.new(18.950964, 0.875427008, 14.8020916)
o102.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o102.Anchored = true
o102.FormFactor = Enum.FormFactor.Custom
o102.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o102.CFrame = CFrame.new(18.950964, 0.875427008, 14.8020916, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o102.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o102.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o102.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o102.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o102.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o102.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o102.Color = Color3.new(0.105882, 0.164706, 0.207843)
o103.Parent = o102
o103.Scale = Vector3.new(0.0833333358, 0.249999985, 0.666666687)
o104.Parent = o1
o104.Material = Enum.Material.SmoothPlastic
o104.BrickColor = BrickColor.new("Really black")
o104.Position = Vector3.new(18.950964, 0.536549985, 14.6048756)
o104.Rotation = Vector3.new(180, 2.50796006e-006, 5.00895612e-006)
o104.Anchored = true
o104.FormFactor = Enum.FormFactor.Custom
o104.Size = Vector3.new(0.200000003, 0.794444382, 0.244444445)
o104.CFrame = CFrame.new(18.950964, 0.536549985, 14.6048756, 1, -8.74227766e-008, 4.3772161e-008, -8.74227766e-008, -1, -3.8177829e-015, 4.3772161e-008, 6.83386182e-018, -1)
o104.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o104.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o104.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o104.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o104.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o104.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o104.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o105.Parent = o104
o105.Scale = Vector3.new(0.694444478, 1, 1)
o105.MeshType = Enum.MeshType.Wedge
o106.Name = "Mag"
o106.Parent = o1
o106.Material = Enum.Material.SmoothPlastic
o106.BrickColor = BrickColor.new("Really black")
o106.Position = Vector3.new(18.950964, 0.56080699, 14.4704056)
o106.Rotation = Vector3.new(101, 90, 0)
o106.Anchored = true
o106.FormFactor = Enum.FormFactor.Custom
o106.Size = Vector3.new(0.872222185, 0.322222203, 0.200000003)
o106.CFrame = CFrame.new(18.950964, 0.56080699, 14.4704056, -2.79885857e-008, -5.65955389e-008, 1, 0.981627166, -0.190809026, 1.66447549e-008, 0.190809026, 0.981627107, 6.10016286e-008)
o106.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o106.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o106.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o106.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o106.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o106.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o106.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o107.Parent = o106
o107.Scale = Vector3.new(1, 1, 0.611111104)
o108.Parent = o1
o108.Material = Enum.Material.SmoothPlastic
o108.BrickColor = BrickColor.new("Smoky grey")
o108.Position = Vector3.new(18.950964, 0.731004, 14.7326536)
o108.Rotation = Vector3.new(-90, 4.32571142e-006, -90.0000076)
o108.Anchored = true
o108.FormFactor = Enum.FormFactor.Custom
o108.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o108.CFrame = CFrame.new(18.950964, 0.731004, 14.7326536, -1.51107088e-007, 1, 7.54979084e-008, 7.25342942e-015, -7.54979084e-008, 1, 1, 1.51107088e-007, 4.14945855e-015)
o108.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o108.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o108.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o108.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o108.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o108.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o108.Color = Color3.new(0.356863, 0.364706, 0.411765)
o109.Parent = o108
o109.Scale = Vector3.new(0.416666687, 0.694444478, 0.416666687)
o110.Parent = o1
o110.Material = Enum.Material.SmoothPlastic
o110.BrickColor = BrickColor.new("Black")
o110.Position = Vector3.new(18.950964, 0.544876993, 14.4409838)
o110.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o110.Anchored = true
o110.FormFactor = Enum.FormFactor.Custom
o110.Size = Vector3.new(0.227777779, 0.711111128, 0.200000003)
o110.CFrame = CFrame.new(18.950964, 0.544876993, 14.4409838, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o110.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o110.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o110.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o110.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o110.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o110.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o110.Color = Color3.new(0.105882, 0.164706, 0.207843)
o111.Parent = o110
o111.Scale = Vector3.new(1, 1, 0.666666687)
o112.Parent = o1
o112.Material = Enum.Material.SmoothPlastic
o112.BrickColor = BrickColor.new("Black")
o112.Position = Vector3.new(18.950964, 0.775434017, 14.7993164)
o112.Rotation = Vector3.new(180, -2.50129006e-006, 180)
o112.Anchored = true
o112.FormFactor = Enum.FormFactor.Custom
o112.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o112.CFrame = CFrame.new(18.950964, 0.775434017, 14.7993164, -1, -1.0960446e-021, -4.36557457e-008, 1.41269847e-021, 1, -1.6144448e-018, 4.36557457e-008, -5.38120031e-018, -1)
o112.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o112.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o112.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o112.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o112.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o112.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o112.Color = Color3.new(0.105882, 0.164706, 0.207843)
o113.Parent = o112
o113.Scale = Vector3.new(0.666666687, 0.249999985, 0.111111112)
o113.MeshType = Enum.MeshType.Wedge
o114.Parent = o1
o114.Material = Enum.Material.SmoothPlastic
o114.BrickColor = BrickColor.new("Black")
o114.Position = Vector3.new(18.950964, 0.730996013, 14.7298584)
o114.Rotation = Vector3.new(180, 0, -90.0000076)
o114.Anchored = true
o114.FormFactor = Enum.FormFactor.Custom
o114.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o114.CFrame = CFrame.new(18.950964, 0.730996013, 14.7298584, -1.94707198e-007, 1, 0, 1, 1.94707169e-007, -4.37113883e-008, -4.37113883e-008, 0, -1)
o114.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o114.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o114.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o114.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o114.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o114.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o114.Color = Color3.new(0.105882, 0.164706, 0.207843)
o115.Parent = o114
o115.Scale = Vector3.new(0.833333373, 0.666666687, 0.805555522)
o116.Parent = o1
o116.Material = Enum.Material.SmoothPlastic
o116.BrickColor = BrickColor.new("Black")
o116.Position = Vector3.new(18.950964, 0.928192973, 14.7298584)
o116.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o116.Anchored = true
o116.FormFactor = Enum.FormFactor.Custom
o116.Size = Vector3.new(0.827777743, 0.200000003, 0.200000003)
o116.CFrame = CFrame.new(18.950964, 0.928192973, 14.7298584, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o116.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o116.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o116.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o116.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o116.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o116.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o116.Color = Color3.new(0.105882, 0.164706, 0.207843)
o117.Parent = o116
o117.Scale = Vector3.new(1, 0.277777761, 0.666666687)
o118.Parent = o1
o118.Material = Enum.Material.SmoothPlastic
o118.BrickColor = BrickColor.new("Black")
o118.Position = Vector3.new(18.950964, 0.825424016, 14.7993164)
o118.Rotation = Vector3.new(-180, 0, -6.27987314e-020)
o118.Anchored = true
o118.FormFactor = Enum.FormFactor.Custom
o118.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o118.CFrame = CFrame.new(18.950964, 0.825424016, 14.7993164, 1, 1.0960446e-021, 0, -1.0960446e-021, -1, 5.38120031e-018, 0, 5.38120031e-018, -1)
o118.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o118.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o118.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o118.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o118.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o118.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o118.Color = Color3.new(0.105882, 0.164706, 0.207843)
o119.Parent = o118
o119.Scale = Vector3.new(0.666666687, 0.249999985, 0.111111112)
o119.MeshType = Enum.MeshType.Wedge
o120.Parent = o1
o120.Material = Enum.Material.SmoothPlastic
o120.BrickColor = BrickColor.new("Black")
o120.Position = Vector3.new(18.950964, 0.600430012, 14.4798584)
o120.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o120.Anchored = true
o120.FormFactor = Enum.FormFactor.Custom
o120.Size = Vector3.new(0.200000003, 0.666666687, 0.200000003)
o120.CFrame = CFrame.new(18.950964, 0.600430012, 14.4798584, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o120.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o120.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o120.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o120.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o120.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o120.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o120.Color = Color3.new(0.105882, 0.164706, 0.207843)
o121.Parent = o120
o121.Scale = Vector3.new(0.027777778, 1, 0.694444478)
o122.Parent = o1
o122.Material = Enum.Material.SmoothPlastic
o122.BrickColor = BrickColor.new("Black")
o122.Position = Vector3.new(18.950964, 0.980957985, 14.5104237)
o122.Rotation = Vector3.new(2.05579065e-016, -2.50796006e-006, 6.27987314e-020)
o122.Anchored = true
o122.FormFactor = Enum.FormFactor.Custom
o122.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o122.CFrame = CFrame.new(18.950964, 0.980957985, 14.5104237, 1, -1.0960446e-021, -4.3772161e-008, -7.78546341e-022, 1, -3.58803156e-018, 4.3772161e-008, -5.38120031e-018, 1)
o122.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o122.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o122.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o122.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o122.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o122.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o122.Color = Color3.new(0.105882, 0.164706, 0.207843)
o123.Parent = o122
o123.Scale = Vector3.new(0.694444478, 0.0833333358, 0.333333343)
o123.MeshType = Enum.MeshType.Wedge
o124.Parent = o1
o124.Material = Enum.Material.SmoothPlastic
o124.BrickColor = BrickColor.new("Black")
o124.Position = Vector3.new(18.950964, 0.961513996, 14.6854324)
o124.Rotation = Vector3.new(180, -2.50129006e-006, 180)
o124.Anchored = true
o124.FormFactor = Enum.FormFactor.Custom
o124.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o124.CFrame = CFrame.new(18.950964, 0.961513996, 14.6854324, -1, -1.0960446e-021, -4.36557457e-008, 1.41269847e-021, 1, -1.6144448e-018, 4.36557457e-008, -5.38120031e-018, -1)
o124.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o124.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o124.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o124.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o124.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o124.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o124.Color = Color3.new(0.105882, 0.164706, 0.207843)
o125.Parent = o124
o125.Scale = Vector3.new(0.694444478, 0.277777761, 0.416666687)
o125.MeshType = Enum.MeshType.Wedge
o126.Parent = o1
o126.Material = Enum.Material.SmoothPlastic
o126.BrickColor = BrickColor.new("Really black")
o126.Position = Vector3.new(18.950964, 0.803216994, 14.6715384)
o126.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o126.Anchored = true
o126.FormFactor = Enum.FormFactor.Custom
o126.Size = Vector3.new(0.244444445, 0.200000003, 0.200000003)
o126.CFrame = CFrame.new(18.950964, 0.803216994, 14.6715384, 0, -1.0960446e-021, 1, 5.38120031e-018, 1, -1.0960446e-021, -1, -5.38120031e-018, 0)
o126.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o126.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o126.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o126.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o126.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o126.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o126.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o127.Parent = o126
o127.Scale = Vector3.new(1, 0.972222209, 0.666666687)
o128.Parent = o1
o128.Material = Enum.Material.SmoothPlastic
o128.BrickColor = BrickColor.new("Really black")
o128.Position = Vector3.new(18.950964, 0.672379017, 14.6450357)
o128.Rotation = Vector3.new(-30.0000038, 90, 0)
o128.Anchored = true
o128.FormFactor = Enum.FormFactor.Custom
o128.Size = Vector3.new(0.205555543, 0.200000003, 0.200000003)
o128.CFrame = CFrame.new(18.950964, 0.672379017, 14.6450357, 4.20376836e-008, -2.60188173e-008, 1, -0.50000006, 0.866025388, 4.35066809e-008, -0.866025388, -0.50000006, 2.33994797e-008)
o128.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o128.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o128.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o128.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o128.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o128.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o128.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o129.Parent = o128
o129.Scale = Vector3.new(1, 0.722222269, 0.666666687)
o130.Parent = o1
o130.Material = Enum.Material.SmoothPlastic
o130.BrickColor = BrickColor.new("Really black")
o130.Position = Vector3.new(18.950964, 0.619874001, 14.3270836)
o130.Rotation = Vector3.new(2.05579065e-016, -2.50796006e-006, 6.27987314e-020)
o130.Anchored = true
o130.FormFactor = Enum.FormFactor.Custom
o130.Size = Vector3.new(0.200000003, 0.705555558, 0.300000012)
o130.CFrame = CFrame.new(18.950964, 0.619874001, 14.3270836, 1, -1.0960446e-021, -4.3772161e-008, -7.78546341e-022, 1, -3.58803156e-018, 4.3772161e-008, -5.38120031e-018, 1)
o130.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o130.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o130.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o130.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o130.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o130.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o130.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o131.Parent = o130
o131.Scale = Vector3.new(0.694444478, 1, 1)
o131.MeshType = Enum.MeshType.Wedge
o132.Parent = o1
o132.Material = Enum.Material.SmoothPlastic
o132.BrickColor = BrickColor.new("Black")
o132.Position = Vector3.new(18.950964, 1.15317094, 14.2876415)
o132.Rotation = Vector3.new(30.0000019, 90, 0)
o132.Anchored = true
o132.FormFactor = Enum.FormFactor.Custom
o132.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o132.CFrame = CFrame.new(18.950964, 1.15317094, 14.2876415, 1.28167699e-010, -5.82076609e-011, 1, 0.5, 0.866025388, -1.0960446e-021, -0.866025388, 0.5, 0)
o132.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o132.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o132.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o132.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o132.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o132.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o132.Color = Color3.new(0.105882, 0.164706, 0.207843)
o133.Parent = o132
o133.Scale = Vector3.new(0.388888866, 0.194444433, 0.416666687)
o134.Parent = o1
o134.Material = Enum.Material.SmoothPlastic
o134.BrickColor = BrickColor.new("Black")
o134.Position = Vector3.new(18.950964, 1.10315704, 14.3126564)
o134.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o134.Anchored = true
o134.FormFactor = Enum.FormFactor.Custom
o134.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o134.CFrame = CFrame.new(18.950964, 1.10315704, 14.3126564, 0, -5.9604659e-008, 1, 5.38120031e-018, 1, 5.9604659e-008, -1, -5.38374141e-018, 0)
o134.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o134.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o134.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o134.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o134.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o134.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o134.Color = Color3.new(0.105882, 0.164706, 0.207843)
o135.Parent = o134
o135.Scale = Vector3.new(0.027777778, 0.861111045, 0.416666687)
o136.Parent = o1
o136.Material = Enum.Material.SmoothPlastic
o136.BrickColor = BrickColor.new("Black")
o136.Position = Vector3.new(18.950964, 0.969842017, 14.2187424)
o136.Rotation = Vector3.new(2.05579065e-016, -2.50796006e-006, 6.27987314e-020)
o136.Anchored = true
o136.FormFactor = Enum.FormFactor.Custom
o136.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o136.CFrame = CFrame.new(18.950964, 0.969842017, 14.2187424, 1, -1.0960446e-021, -4.3772161e-008, -7.78546341e-022, 1, -3.58803156e-018, 4.3772161e-008, -5.38120031e-018, 1)
o136.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o136.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o136.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o136.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o136.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o136.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o136.Color = Color3.new(0.105882, 0.164706, 0.207843)
o137.Parent = o136
o137.Scale = Vector3.new(0.666666687, 0.249999985, 0.74999994)
o137.MeshType = Enum.MeshType.Wedge
o138.Parent = o1
o138.Material = Enum.Material.SmoothPlastic
o138.BrickColor = BrickColor.new("Black")
o138.Position = Vector3.new(18.950964, 0.919857979, 14.2271004)
o138.Rotation = Vector3.new(-0.600734293, 89.980217, -5.99351438e-007)
o138.Anchored = true
o138.FormFactor = Enum.FormFactor.Custom
o138.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o138.CFrame = CFrame.new(18.950964, 0.919857979, 14.2271004, 4.06289615e-008, 4.25005558e-016, 0.99999994, -6.70552254e-008, 0.999999881, 4.68723726e-010, -1.00000012, -9.68575407e-008, 4.47034694e-008)
o138.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o138.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o138.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o138.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o138.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o138.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o138.Color = Color3.new(0.105882, 0.164706, 0.207843)
o139.Parent = o138
o139.Scale = Vector3.new(0.888888896, 0.249999985, 0.666666687)
o140.Parent = o1
o140.Material = Enum.Material.SmoothPlastic
o140.BrickColor = BrickColor.new("Black")
o140.Position = Vector3.new(18.950964, 1.17262495, 14.2539701)
o140.Rotation = Vector3.new(30.0000038, 1.24663654e-006, -90)
o140.Anchored = true
o140.FormFactor = Enum.FormFactor.Custom
o140.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o140.CFrame = CFrame.new(18.950964, 1.17262495, 14.2539701, -4.959292e-008, 1, 2.17579128e-008, -0.866025388, -3.19989653e-008, -0.50000006, -0.50000006, -4.36557457e-008, 0.866025388)
o140.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o140.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o140.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o140.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o140.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o140.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o140.Color = Color3.new(0.105882, 0.164706, 0.207843)
o141.Parent = o140
o141.Scale = Vector3.new(0.194444433, 0.416666687, 0.194444433)
o142.Parent = o1
o142.Material = Enum.Material.SmoothPlastic
o142.BrickColor = BrickColor.new("Really black")
o142.Position = Vector3.new(18.950964, 1.10038495, 14.3182096)
o142.Rotation = Vector3.new(3.08320072e-016, 90, 0)
o142.Anchored = true
o142.FormFactor = Enum.FormFactor.Custom
o142.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o142.CFrame = CFrame.new(18.950964, 1.10038495, 14.3182096, 0, -2.98023295e-008, 1, 5.38120031e-018, 1, 2.98023295e-008, -1, -1.91260039e-018, 0)
o142.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o142.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o142.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o142.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o142.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o142.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o142.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o143.Parent = o142
o143.Scale = Vector3.new(0.027777778, 0.722222269, 0.388888866)
o144.Parent = o1
o144.Material = Enum.Material.SmoothPlastic
o144.BrickColor = BrickColor.new("Black")
o144.Position = Vector3.new(18.950964, 0.986526012, 14.2826424)
o144.Rotation = Vector3.new(3.08320072e-016, 0, 6.27987314e-020)
o144.Anchored = true
o144.FormFactor = Enum.FormFactor.Custom
o144.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
o144.CFrame = CFrame.new(18.950964, 0.986526012, 14.2826424, 1, -1.0960446e-021, 0, -1.0960446e-021, 1, -5.38120031e-018, 0, -5.38120031e-018, 1)
o144.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o144.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o144.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o144.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o144.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o144.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o144.Color = Color3.new(0.105882, 0.164706, 0.207843)
o145.Parent = o144
o145.Scale = Vector3.new(0.666666687, 0.416666687, 0.333333343)
o145.MeshType = Enum.MeshType.Wedge
o146.Parent = o1
o146.Material = Enum.Material.SmoothPlastic
o146.BrickColor = BrickColor.new("Really black")
o146.Position = Vector3.new(18.950964, 0.872651994, 14.2770796)
o146.Rotation = Vector3.new(2.18855899e-013, 2.50129006e-006, 180)
o146.Anchored = true
o146.FormFactor = Enum.FormFactor.Custom
o146.Size = Vector3.new(0.200000003, 0.200000003, 0.211111099)
o146.CFrame = CFrame.new(18.950964, 0.872651994, 14.2770796, -1, -8.74227766e-008, 4.36557457e-008, 8.74227766e-008, -1, -3.81975606e-015, 4.36557457e-008, 6.83386182e-018, 1)
o146.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o146.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o146.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o146.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o146.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o146.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o146.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o147.Parent = o146
o147.Scale = Vector3.new(0.666666687, 0.277777761, 1)
o147.MeshType = Enum.MeshType.Wedge
o148.Name = "Handle"
o148.Parent = o1
o148.Material = Enum.Material.SmoothPlastic
o148.BrickColor = BrickColor.new("Really black")
o148.Transparency = 1
o148.Position = Vector3.new(18.9506321, 0.598004997, 14.4106464)
o148.Rotation = Vector3.new(180, -2.50129006e-006, 180)
o148.Anchored = true
o148.FormFactor = Enum.FormFactor.Custom
o148.Size = Vector3.new(0.200000003, 0.205555543, 0.200000003)
o148.CFrame = CFrame.new(18.9506321, 0.598004997, 14.4106464, -1, -1.0960446e-021, -4.36557457e-008, 1.41269847e-021, 1, -1.6144448e-018, 4.36557457e-008, -5.38120031e-018, -1)
o148.BackSurface = Enum.SurfaceType.SmoothNoOutlines
o148.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
o148.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
o148.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
o148.RightSurface = Enum.SurfaceType.SmoothNoOutlines
o148.TopSurface = Enum.SurfaceType.SmoothNoOutlines
o148.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
o149.Name = "FireSound"
o149.Parent = o148
o149.SoundId = "rbxassetid://330704232"
o149.Volume = 10
o150.Parent = o148
o150.Scale = Vector3.new(0.99999994, 1, 0.99999994)
Victim = game.Players.LocalPlayer.Character
function Suicide ()
	    Victim.Torso.Neck.C0 = CFrame.new(0,1.5,0) * CFrame.Angles(math.rad(25), -math.rad(0),-math.rad(0))
        Victim.Torso.Neck.C1 = CFrame.new(0,0,0)
		wait(.02)
	    Victim.Torso["Right Shoulder"].C0 = CFrame.new(2.3,.5,0) * CFrame.Angles(math.rad(-90), -math.rad(160),-math.rad(-70))
        Victim.Torso["Right Shoulder"].C1 = CFrame.new(0,0,0)
		ANGLE = -70
		ANGLE2 = -20
		for i=1,7 do
		ANGLE = ANGLE + 10
		ANGLE2 = ANGLE2 + 10
		Victim.Torso["Right Shoulder"].C0 = CFrame.new(2.3,.5,0) * CFrame.Angles(math.rad(-90), -math.rad(160),-math.rad(ANGLE))
        Victim.Torso["Right Shoulder"].C1 = CFrame.new(0,0,0)
		wait(1/30)
		wait(.3)
					                              game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('meme', '8', '1527622')
	lp = game:GetService'Players'.LocalPlayer
	hat = lp.Character:WaitForChild'meme'
	hat.Handle.Transparency=1
	hat.Handle.Mesh:Remove()
		game.Players.LocalPlayer.Character.Head.BrickColor = BrickColor.new("Maroon")
		player = game.Players[Victim.Name]
char = player.Character
			end
function DEATH ()
OHHNELLY = Instance.new("Part")
OHHNELLY.Parent = rg
OHHNELLY.Anchored = false
OHHNELLY.Material = Enum.Material.SmoothPlastic
OHHNELLY.BrickColor = BrickColor.new("Maroon")
OHHNELLY.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
OHHNELLY.Position = rg.Head.Position
OHHNELLY.Color = Color3.new(0.458824, 0, 0)
OHHNELLY.BackSurface = Enum.SurfaceType.SmoothNoOutlines
OHHNELLY.BottomSurface = Enum.SurfaceType.SmoothNoOutlines
OHHNELLY.FrontSurface = Enum.SurfaceType.SmoothNoOutlines
OHHNELLY.LeftSurface = Enum.SurfaceType.SmoothNoOutlines
OHHNELLY.RightSurface = Enum.SurfaceType.SmoothNoOutlines
OHHNELLY.TopSurface = Enum.SurfaceType.SmoothNoOutlines
end
for i=1, 10 do
	DEATH()
	print"BLOODY"
	wait()
end
end
function Weld(x,y)
	local W = Instance.new("Weld")
	W.Part0 = x
	W.Part1 = y
	local CJ = CFrame.new(x.Position)
	local C0 = x.CFrame:inverse()*CJ
	local C1 = y.CFrame:inverse()*CJ
	W.C0 = C0
	W.C1 = C1
	W.Parent = x
end

function Get(A)
	if A.className == "Part" then
		Weld(o1.Handle, A)
		A.Anchored = false
	else
		local C = A:GetChildren()
		for i=1, #C do
		Get(C[i])
		end
	end
end

function Finale()
	Get(o1)
end

o1.Equipped:connect(Finale)
o1.Unequipped:connect(Finale)
o1.Activated:connect(Suicide)
Finale()
end)

feadmin.Name = "feadmin"
feadmin.Parent = Scripts
feadmin.BackgroundColor3 = Color3.new(0, 0, 0)
feadmin.BackgroundTransparency = 0.5
feadmin.Position = UDim2.new(0, 0, 0, 807)
feadmin.Size = UDim2.new(0, 200, 0, 50)
feadmin.Font = Enum.Font.SourceSans
feadmin.FontSize = Enum.FontSize.Size14
feadmin.Text = "Reviz FE Admin"
feadmin.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
feadmin.TextSize = 14
feadmin.MouseButton1Down:connect(function()
--[[
	Welcome to Reviz Admin! (By illremember)
	An admin that is designed to work with FE games.
--]]
prefix = ";"
--[[
	---- CREDITS TO:
	xFunnieuss + Timeless for partial name support
	Timeless for Invisible command + Print remotes
	Creators of DEX explorer
	Creators of Infinite Yield (Ideas)
	Harkinian for Shutdown
	Creators of Mr.Spy remotespy
	TCP for Testing/Ideas/Fire Rapper
--]]
wait(0.3)
Commands = {
	'[-] cmdbar is shown when ; is pressed.',
	'[1] kill [plr] -- You need a tool! Will kill the player, use rkill to kill you and player',
	'[2] bring [plr] -- You need a tool! Will bring player to you',
	'[3] spin [plr] -- You need a tool! Makes you and the player spin crazy',
	'[4] unspin -- Use after using spin cmd and dying, so you stop loop teleporting',
	'[5] attach [plr] -- You need a tool! Attaches you to player',
	'[6] unattach [plr] -- Attempts to unattach you from a player',
	'[7] follow [plr] -- Makes you follow behind the player',
	'[8] unfollow',
	'[9] freefall [plr] -- You need a tool! Teleports you and the player up into the air',
	'[10] trail [plr] -- The opposite of follow, you stay infront of player',
	'[11] untrail',
	'[12] orbit [plr] -- Makes you orbit the player',
	'[13] unorbit',
	'[14] fling [plr] -- Makes you fling the player',
	'[15] unfling',
	'[16] fecheck -- Checks if the game is FE or not',
	'[17] void [plr] -- Teleports player to the void',
	'[18] noclip -- Gives you noclip to walk through walls',
	'[19] clip -- Removes noclip',
	'[20] speed [num]/ws [num] -- Changes how fast you walk 16 is default',
	'[21] jumppower [num]/jp [num] -- Changes how high you jump 50 is default',
	'[22] hipheight [num]/hh [num] -- Changes how high you float 0 is default',
	'[23] default -- Changes your speed, jumppower and hipheight to default values',
	'[24] annoy [plr] -- Loop teleports you to the player',
	'[25] unannoy',
	'[26] headwalk [plr] -- Loop teleports you to the player head',
	'[27] unheadwalk',
	'[28] nolimbs -- Removes your arms and legs',
	'[29] god -- Gives you FE Godmode',
	'[30] drophats -- Drops your accessories',
	'[31] droptool -- Drops any tool you have equipped',
	'[32] loopdhats -- Loop drops your accessories',
	'[33] unloopdhats',
	'[34] loopdtool -- Loop drops any tools you have equipped',
	'[35] unloopdtool',
	'[36] invisible -- Gives you invisibility CREDIT TO TIMELESS',
	'[37] view [plr] -- Changes your camera to the player character',
	'[38] unview',
	'[39] goto [plr] -- Teleports you to player',
	'[40] fly -- Allows you to fly',
	'[41] unfly',
	'[42] chat [msg] -- Makes you chat a message',
	'[43] spam [msg] -- Spams a message',
	'[44] unspam',
	'[45] spamwait [num] -- Changes delay of chatting a message for the spam command in seconds default is 1 second',
	'[46] pmspam [plr] -- Spams a player in private message',
	'[47] unpmspam',
	'[48] cfreeze [plr] -- Freezes a player on your client, they will only be frozen for you',
	'[49] uncfreeze [plr]',
	'[50] unlockws -- Unlocks the workspace',
	'[51] lockws -- Locks the workspace',
	'[52] btools -- Gives you btools that will only show to you useful for deleting certain blocks only for you',
	'[53] pstand -- Enables platform stand',
	'[54] unpstand -- Disables platform stand',
	'[55] blockhead -- Removes your head mesh',
	'[56] sit',
	'[57] bringobj [obj] -- Only shows on client, brings an object/part to you constantly, can be used to bring healing parts, weapons, money etc, type in exact name',
	'[58] wsvis [num] -- Changes visibility of workspace parts, num should be between 0 and 1, only shows client sided',
	'[59] hypertotal -- Loads in my FE GUI Hypertotal',
	'[60] cmds -- Prints all commands',
	'[61] rmeshhats/blockhats -- Removes the meshes of all your accessories aka block hats',
	'[62] rmeshtool/blocktool -- Removes the mesh of the tool you have equipped aka block tool',
	'[63] spinner -- Makes you spin',
	'[64] nospinner',
	'[65] reach [num] -- Gives you reach, mostly used for swords, say ;reachd for default and enter number after for custom',
	'[66] noreach -- Removes reach, must have tool equipped',
	'[67] rkill [plr] -- Kills you and the player, use kill to just kill the player without dying',
	'[68] tp me [plr] -- Alternative to goto',
	'[69] cbring [plr] -- Brings player infront of you, shows only on client, allows you to do damage to player',
	'[70] uncbring',
	'[71] swap [plr] -- You need a tool! Swaps players position with yours and your position with players',
	'[72] givetool [plr] -- Gives the tool you have equipped to the player',
	'[73] glitch [plr] -- Glitches you and the player, looks very cool',
	'[74] unglitch -- Unglitches you',
	'[75] grespawn -- Alternative to normal respawn and usually works best for when you want to reset with FE Godmode',
	'[76] explorer -- Loads up DEX',
	'[77] remotespy -- Loads up a remotespy',
	'[78] anim [id] -- Applies an animation on you, must be created by ROBLOX',
	'[79] animgui -- Loads up Energize animations GUI',
	'[80] savepos -- Saves your current position',
	'[81] loadpos -- Teleports you to your saved position',
	'[82] bang [plr] -- 18+',
	'[83] unbang',
	'[84] delcmdbar -- Removes the command bar completely',
	'[85] bringmod [obj] -- Brings all the parts in a model, client only, comes from ;bringobj enter exact name of model',
	'[86] shutdown -- Uses harkinians script to shutdown server',
	'[87] respawn -- If grespawn doesnt work you can use respawn',
	'[88] delobj [obj] -- Deletes a certain brick in workspace, client sided',
	'[89] getplrs -- Prints all players in game',
	'[90] deldecal -- Deletes all decals client sided',
	'[91] opfinality -- Loads in my FE GUI Opfinality',
	'[92] remotes -- Prints all remotes in the game in the console when added',
	'[93] noremotes -- Stops printing remotes',
	'[94] tpdefault -- Stops all loop teleports to a player',
	'[95] stopsit -- Will not allow you to sit',
	'[96] gosit -- Allows you to sit',
	'[97] clicktp -- Enables click tp',
	'[98] noclicktp -- Disables click tp',
	'[99] toolson -- If any tools are dropped in the workspace you will automatically get them',
	'[100] toolsoff -- Stops ;toolson',
	'[101] version -- Gets the admin version'
}

lplayer = game.Players.LocalPlayer

function GetPlayer(String) -- Credit to Timeless/xFunnieuss
    local Found = {}
    local strl = String:lower()
    if strl == "all" then
        for i,v in pairs(game.Players:GetPlayers()) do
            table.insert(Found,v)
        end
    elseif strl == "others" then
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name ~= game.Players.LocalPlayer.Name then
                table.insert(Found,v)
            end
        end   
	elseif strl == "me" then
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name == game.Players.LocalPlayer.Name then
                table.insert(Found,v)
            end
        end  
    else
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name:lower():sub(1, #String) == String:lower() then
                table.insert(Found,v)
            end
        end    
    end
    return Found    
end

local Mouse = game.Players.LocalPlayer:GetMouse()

spin = false
followed = false
traill = false
noclip = false
annoying = false
hwalk = false
droppinghats = false
droppingtools = false
flying = false
spamdelay = 1
spamming = false
spammingpm = false
cbringing = false
remotes = true
added = true
binds = false
stopsitting = false
clickgoto = false
gettingtools = false

adminversion = "Reviz admin by illremember, Version 1.0"

local CMDS = Instance.new("ScreenGui")
local CMDSFRAME = Instance.new("Frame")
local ScrollingFrame = Instance.new("ScrollingFrame")
local TextLabel = Instance.new("TextLabel")
local closegui = Instance.new("TextButton")
CMDS.Name = "CMDS"
CMDS.Parent = game.Players.LocalPlayer.PlayerGui
CMDSFRAME.Name = "CMDSFRAME"
CMDSFRAME.Parent = CMDS
CMDSFRAME.Active = true
CMDSFRAME.BackgroundColor3 = Color3.new(0.223529, 0.231373, 0.309804)
CMDSFRAME.BorderSizePixel = 0
CMDSFRAME.Draggable = true
CMDSFRAME.Position = UDim2.new(0, 315, 0, 100)
CMDSFRAME.Size = UDim2.new(0, 275, 0, 275)
CMDSFRAME.Visible = false
ScrollingFrame.Parent = CMDSFRAME
ScrollingFrame.BackgroundColor3 = Color3.new(0.160784, 0.160784, 0.203922)
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.Position = UDim2.new(0, 0, 0.0729999989, 0)
ScrollingFrame.Size = UDim2.new(1.04999995, 0, 0.92900002, 0)
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 10, 0)
TextLabel.Parent = ScrollingFrame
TextLabel.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel.BackgroundTransparency = 1
TextLabel.Size = UDim2.new(0.930000007, 0, 1, 0)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.FontSize = Enum.FontSize.Size18
TextLabel.Text = "[-] cmdbar is shown when ; is pressed.,\n[1] kill [plr] -- You need a tool! Will kill the player, use rkill to kill you and player,\n[2] bring [plr] -- You need a tool! Will bring player to you,\n[3] spin [plr] -- You need a tool! Makes you and the player spin crazy,\n[4] unspin -- Use after using spin cmd and dying, so you stop loop teleporting,\n[5] attach [plr] -- You need a tool! Attaches you to player,\n[6] unattach [plr] -- Attempts to unattach you from a player,\n[7] follow [plr] -- Makes you follow behind the player,\n[8] unfollow,\n[9] freefall [plr] -- You need a tool! Teleports you and the player up into the air,\n[10] trail [plr] -- The opposite of follow, you stay infront of player,\n[11] untrail,\n[12] orbit [plr] -- Makes you orbit the player,\n[13] unorbit,\n[14] fling [plr] -- Makes you fling the player,\n[15] unfling,\n[16] fecheck -- Checks if the game is FE or not,\n[17] void [plr] -- Teleports player to the void,\n[18] noclip -- Gives you noclip to walk through walls,\n[19] clip -- Removes noclip,\n[20] speed [num]/ws [num] -- Changes how fast you walk 16 is default,\n[21] jumppower [num]/jp [num] -- Changes how high you jump 50 is default,\n[22] hipheight [num]/hh [num] -- Changes how high you float 0 is default,\n[23] default -- Changes your speed, jumppower and hipheight to default values,\n[24] annoy [plr] -- Loop teleports you to the player,\n[25] unannoy,\n[26] headwalk [plr] -- Loop teleports you to the player head,\n[27] unheadwalk,\n[28] nolimbs -- Removes your arms and legs,\n[29] god -- Gives you FE Godmode,\n[30] drophats -- Drops your accessories,\n[31] droptool -- Drops any tool you have equipped,\n[32] loopdhats -- Loop drops your accessories,\n[33] unloopdhats,\n[34] loopdtool -- Loop drops any tools you have equipped,\n[35] unloopdtool,\n[36] invisible -- Gives you invisibility CREDIT TO TIMELESS,\n[37] view [plr] -- Changes your camera to the player character,\n[38] unview,\n[39] goto [plr] -- Teleports you to player,\n[40] fly -- Allows you to fly,\n[41] unfly,\n[42] chat [msg] -- Makes you chat a message,\n[43] spam [msg] -- Spams a message,\n[44] unspam,\n[45] spamwait [num] -- Changes delay of chatting a message for the spam command in seconds default is 1 second,\n[46] pmspam [plr] -- Spams a player in private message,\n[47] unpmspam,\n[48] cfreeze [plr] -- Freezes a player on your client, they will only be frozen for you,\n[49] uncfreeze [plr],\n[50] unlockws -- Unlocks the workspace,\n[51] lockws -- Locks the workspace,\n[52] btools -- Gives you btools that will only show to you useful for deleting certain blocks only for you,\n[53] pstand -- Enables platform stand,\n[54] unpstand -- Disables platform stand,\n[55] blockhead -- Removes your head mesh,\n[56] sit,\n[57] bringobj [obj] -- Only shows on client, brings an object/part to you constantly, can be used to bring healing parts, weapons, money etc, type in exact name,\n[58] wsvis [num] -- Changes visibility of workspace parts, num should be between 0 and 1, only shows client sided,\n[59] hypertotal -- Loads in my FE GUI Hypertotal,\n[60] cmds -- Prints all commands,\n[61] rmeshhats/blockhats -- Removes the meshes of all your accessories aka block hats,\n[62] rmeshtool/blocktool -- Removes the mesh of the tool you have equipped aka block tool,\n[63] spinner -- Makes you spin,\n[64] nospinner,\n[65] reach [num] -- Gives you reach, mostly used for swords, say ;reachd for default and enter number after for custom,\n[66] noreach -- Removes reach, must have tool equipped,\n[67] rkill [plr] -- Kills you and the player, use kill to just kill the player without dying,\n[68] tp me [plr] -- Alternative to goto,\n[69] cbring [plr] -- Brings player infront of you, shows only on client, allows you to do damage to player,\n[70] uncbring,\n[71] swap [plr] -- You need a tool! Swaps players position with yours and your position with players,\n[72] givetool [plr] -- Gives the tool you have equipped to the player,\n[73] glitch [plr] -- Glitches you and the player, looks very cool,\n[74] unglitch -- Unglitches you,\n[75] grespawn -- Alternative to normal respawn and usually works best for when you want to reset with FE Godmode,\n[76] explorer -- Loads up DEX,\n[77] remotespy -- Loads up a remotespy,\n[78] anim [id] -- Applies an animation on you, must be created by ROBLOX,\n[79] animgui -- Loads up Energize animations GUI,\n[80] savepos -- Saves your current position,\n[81] loadpos -- Teleports you to your saved position,\n[82] bang [plr] -- 18+,\n[83] unbang,\n[84] delcmdbar -- Removes the command bar completely,\n[85] bringmod [obj] -- Brings all the parts in a model, client only, comes from ;bringobj enter exact name of model,\n[86] shutdown -- Uses harkinians script to shutdown server,\n[87] respawn -- If grespawn doesnt work you can use respawn,\n[88] delobj [obj] -- Deletes a certain brick in workspace, client sided,\n[89] getplrs -- Prints all players in game,\n[90] deldecal -- Deletes all decals client sided,\n[91] opfinality -- Loads in my FE GUI Opfinality,\n[92] remotes -- Prints all remotes in the game in the console when added,\n[93] noremotes -- Stops printing remotes,\n[94] tpdefault -- Stops all loop teleports to a player,\n[95] stopsit -- Will not allow you to sit,\n[96] gosit -- Allows you to sit,\n[97] clicktp -- Enables click tp,\n[98] noclicktp -- Disables click tp,\n[99] toolson -- If any tools are dropped in the workspace you will automatically get them,\n[100] toolsoff -- Stops ;toolson,\n[101] version -- Gets the admin version"
TextLabel.TextColor3 = Color3.new(1, 1, 1)
TextLabel.TextSize = 15
TextLabel.TextWrapped = true
TextLabel.TextXAlignment = Enum.TextXAlignment.Left
TextLabel.TextYAlignment = Enum.TextYAlignment.Top
closegui.Name = "closegui"
closegui.Parent = CMDSFRAME
closegui.BackgroundColor3 = Color3.new(0.890196, 0.223529, 0.0588235)
closegui.BorderSizePixel = 0
closegui.Position = UDim2.new(0.995000005, 0, 0, 0)
closegui.Size = UDim2.new(0.0545952693, 0, 0.0728644878, 0)
closegui.Font = Enum.Font.SourceSansBold
closegui.FontSize = Enum.FontSize.Size24
closegui.Text = "X"
closegui.TextColor3 = Color3.new(1, 1, 1)
closegui.TextSize = 20

closegui.MouseButton1Click:connect(function()
	CMDSFRAME.Visible = false
end)

game:GetService('RunService').Stepped:connect(function()
	if spin then
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[spinplr.Name].Character.HumanoidRootPart.CFrame
	end
	if followed then
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[flwplr.Name].Character.HumanoidRootPart.CFrame + game.Players[flwplr.Name].Character.HumanoidRootPart.CFrame.lookVector * -5
	end
	if traill then
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[trlplr.Name].Character.HumanoidRootPart.CFrame + game.Players[trlplr.Name].Character.HumanoidRootPart.CFrame.lookVector * 5
	end
	if annoying then
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[annplr.Name].Character.HumanoidRootPart.CFrame
	end
	if hwalk then
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[hdwplr.Name].Character.HumanoidRootPart.CFrame + Vector3.new(0, 4, 0)
	end
end)
game:GetService('RunService').Stepped:connect(function()
	if noclip then
		game.Players.LocalPlayer.Character.Head.CanCollide = false
		game.Players.LocalPlayer.Character.Torso.CanCollide = false
		game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
		game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
	end
end)
game:GetService('RunService').Stepped:connect(function()
	if droppinghats then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Accessory")) or (v:IsA("Hat")) then
				v.Parent = workspace
			end
		end
	end
	if droppingtools then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Tool")) then
				v.Parent = workspace
			end
		end
	end
end)
game:GetService('RunService').Stepped:connect(function()
	if banpl then
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[bplrr].Character.HumanoidRootPart.CFrame
	end
end)
game:GetService('RunService').Stepped:connect(function()
	if stopsitting then
		game.Players.LocalPlayer.Character.Humanoid.Sit = false
	end
end)

plr = game.Players.LocalPlayer 
hum = plr.Character.HumanoidRootPart
mouse = plr:GetMouse() 
mouse.KeyDown:connect(function(key) 
	if key == "e" then 
		if mouse.Target then 
			if clickgoto then
				hum.CFrame = CFrame.new(mouse.Hit.x, mouse.Hit.y + 5, mouse.Hit.z) 
			end
		end 
	end 
end)

lplayer.Chatted:Connect(function(msg)
	if string.sub(msg, 1, 6) == (prefix.."kill ") then
		if string.sub(msg, 7) == "me" then
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(100000,0,100000)
		else
			for i,v in pairs(GetPlayer(string.sub(msg, 7)))do
				local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				local function tp(player,player2)
				local char1,char2=player.Character,player2.Character
				if char1 and char2 then
				char1:MoveTo(char2.Head.Position)
				end
				end
				wait(0.1)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.2)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.5)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(-100000,10,-100000))
				wait(0.7)
				tp(game.Players.LocalPlayer,game.Players[v.Name])
				wait(0.7)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."bring ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 8)))do
			local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			local function tp(player,player2)
			local char1,char2=player.Character,player2.Character
			if char1 and char2 then
			char1.HumanoidRootPart.CFrame = char2.HumanoidRootPart.CFrame
			end
			end
			local function getout(player,player2)
			local char1,char2=player.Character,player2.Character
			if char1 and char2 then
			char1:MoveTo(char2.Head.Position)
			end
			end
			tp(game.Players[v.Name], game.Players.LocalPlayer)
			wait(0.2)
			tp(game.Players[v.Name], game.Players.LocalPlayer)
			wait(0.5)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
			wait(0.5)
			getout(game.Players.LocalPlayer, game.Players[v.Name])
			wait(0.3)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 6) == (prefix.."spin ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 7))) do
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
			spinplr = v
			wait(0.5)
			spin = true
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."unspin") then
		spin = false
		local function getout(player,player2)
		local char1,char2=player.Character,player2.Character
		if char1 and char2 then
		char1:MoveTo(char2.Head.Position)
		end
		end
		getout(game.Players.LocalPlayer, game.Players.LocalPlayer)
	end
	if string.sub(msg, 1, 8) == (prefix.."attach ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 9))) do
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
			wait(0.3)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
			attplr = v
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 9) == (prefix.."unattach ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 10))) do
			local function getout(player,player2)
			local char1,char2=player.Character,player2.Character
			if char1 and char2 then
			char1:MoveTo(char2.Head.Position)
			end
			end
			getout(game.Players.LocalPlayer, game.Players[v.Name])
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."follow ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 9))) do
			followed = true
			flwplr = v
		end
	end
	if string.sub(msg, 1, 9) == (prefix.."unfollow") then
		followed = false
	end
	if string.sub(msg, 1, 10) == (prefix.."freefall ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 11))) do
			local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.2)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.6)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
			wait(0.6)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(0,50000,0)
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."trail ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 8))) do
			traill = true
			trlplr = v
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."untrail") then
		traill = false
	end
	if string.sub(msg, 1, 7) == (prefix.."orbit ") then
		if string.sub(msg, 8) == "all" or string.sub(msg, 8) == "others" or string.sub(msg, 8) == "me" then
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		else
			for i,v in pairs(GetPlayer(string.sub(msg, 8))) do
				local o = Instance.new("RocketPropulsion")
				o.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
				o.Name = "Orbit"
				o.Target = game.Players[v.Name].Character.HumanoidRootPart
				o:Fire()
				noclip = true
			end
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."unorbit") then
		game.Players.LocalPlayer.Character.HumanoidRootPart.Orbit:Destroy()
		noclip = false
	end
	if string.sub(msg, 1, 7) == (prefix.."fling ") then
		if string.sub(msg, 8) == "all" or string.sub(msg, 8) == "others" or string.sub(msg, 8) == "me" then
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		else
			for i,v in pairs(GetPlayer(string.sub(msg, 8))) do
				local y = Instance.new("RocketPropulsion")
				y.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
				y.CartoonFactor = 1
				y.MaxThrust = 500000
				y.MaxSpeed = 1000
				y.ThrustP = 100000
				y.Name = "Fling"
				game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
				y.Target = game.Players[v.Name].Character.HumanoidRootPart
				y:Fire()
				noclip = true
			end
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."unfling") then
		noclip = false
		game.Players.LocalPlayer.Character.HumanoidRootPart.Fling:Destroy()
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Head
		wait(0.4)
		game.Players.LocalPlayer.Character.HumanoidRootPart.Fling:Destroy()
	end
	if string.sub(msg, 1, 8) == (prefix.."fecheck") then
		if game.Workspace.FilteringEnabled == true then
			warn("FE is Enabled (Filtering Enabled)")
			game.StarterGui:SetCore("SendNotification", {
				Title = "FE is Enabled";
				Text = "Filtering Enabled. Enjoy using Reviz Admin!";
			})
		else
			warn("FE is Disabled (Filtering Disabled) Consider using a different admin script.")
			game.StarterGui:SetCore("SendNotification", {
				Title = "FE is Disabled";
				Text = "Filtering Disabled. Consider using a different admin script.";
			})
		end
	end
	if string.sub(msg, 1, 6) == (prefix.."void ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 7))) do
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.2)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.6)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(999999999999999,0,999999999999999)
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."noclip") then
		noclip = true
		game.StarterGui:SetCore("SendNotification", {
		Title = "Noclip enabled";
		Text = "Type ;clip to disable";
		})
	end
	if string.sub(msg, 1, 5) == (prefix.."clip") then
		noclip = false
		game.StarterGui:SetCore("SendNotification", {
		Title = "Noclip disabled";
		Text = "Type ;noclip to enable";
		})
	end
	if string.sub(msg, 1, 7) == (prefix.."speed ") then
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = (string.sub(msg, 8))
	end
	if string.sub(msg, 1, 4) == (prefix.."ws ") then
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = (string.sub(msg, 5))
	end
	if string.sub(msg, 1, 11) == (prefix.."hipheight ") then
		game.Players.LocalPlayer.Character.Humanoid.HipHeight = (string.sub(msg, 12))
	end
	if string.sub(msg, 1, 4) == (prefix.."hh ") then
		game.Players.LocalPlayer.Character.Humanoid.HipHeight = (string.sub(msg, 5))
	end
	if string.sub(msg, 1, 11) == (prefix.."jumppower ") then
		game.Players.LocalPlayer.Character.Humanoid.JumpPower = (string.sub(msg, 12))
	end
	if string.sub(msg, 1, 4) == (prefix.."jp ") then
		game.Players.LocalPlayer.Character.Humanoid.JumpPower = (string.sub(msg, 5))
	end
	if string.sub(msg, 1, 8) == (prefix.."default") then
		game.Players.LocalPlayer.Character.Humanoid.JumpPower = 50
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 16
		game.Players.LocalPlayer.Character.Humanoid.HipHeight = 0
	end
	if string.sub(msg, 1, 7) == (prefix.."annoy ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 8))) do
			annoying = true
			annplr = v
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."unannoy") then
		annoying = false
	end
	if string.sub(msg, 1, 10) == (prefix.."headwalk ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 11))) do
			hwalk = true
			hdwplr = v
		end
	end
	if string.sub(msg, 1, 11) == (prefix.."unheadwalk") then
		hwalk = false
	end
	if string.sub(msg, 1, 8) == (prefix.."nolimbs") then
		game.Players.LocalPlayer.Character["Left Leg"]:Destroy()
		game.Players.LocalPlayer.Character["Left Arm"]:Destroy()
		game.Players.LocalPlayer.Character["Right Leg"]:Destroy()
		game.Players.LocalPlayer.Character["Right Arm"]:Destroy()
	end
	if string.sub(msg, 1, 4) == (prefix.."god") then
		game.Players.LocalPlayer.Character.Humanoid.Name = 1
		local l = game.Players.LocalPlayer.Character["1"]:Clone()
		l.Parent = game.Players.LocalPlayer.Character
		l.Name = "Humanoid"
		wait(0.1)
		game.Players.LocalPlayer.Character["1"]:Destroy()
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.Animate.Disabled = true
		wait(0.1)
		game.Players.LocalPlayer.Character.Animate.Disabled = false
		game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
		game.StarterGui:SetCore("SendNotification", {
		Title = "FE Godmode enabled";
		Text = "Use ;kill me OR ;respawn to reset";
		})
	end
	if string.sub(msg, 1, 9) == (prefix.."drophats") then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Accessory")) or (v:IsA("Hat")) then
				v.Parent = workspace
			end
		end
	end
	if string.sub(msg, 1, 9) == (prefix.."droptool") then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Tool")) then
				v.Parent = workspace
			end
		end
	end
	if string.sub(msg, 1, 10) == (prefix.."loopdhats") then
		droppinghats = true
		game.StarterGui:SetCore("SendNotification", {
		Title = "Loop Drop Enabled";
		Text = "Type ;unloopdhats to disable";
		})
	end
	if string.sub(msg, 1, 12) == (prefix.."unloopdhats") then
		droppinghats = false
		game.StarterGui:SetCore("SendNotification", {
		Title = "Loop Drop Disabled";
		Text = "Type ;loopdhats to enable.";
		})
	end
	if string.sub(msg, 1, 10) == (prefix.."loopdtool") then
		droppingtools = true
		game.StarterGui:SetCore("SendNotification", {
		Title = "Loop Drop Enabled";
		Text = "Type ;unloopdtool to disable";
		})
	end
	if string.sub(msg, 1, 12) == (prefix.."unloopdtool") then
		droppingtools = false
		game.StarterGui:SetCore("SendNotification", {
		Title = "Loop Drop Disabled";
		Text = "Type ;loopdtool to enable.";
		})
	end
	if string.sub(msg, 1, 10) == (prefix.."invisible") then -- Credit to Timeless
		Local = game:GetService('Players').LocalPlayer
		Char  = Local.Character
		touched,tpdback = false, false
		box = Instance.new('Part',workspace)
		box.Anchored = true
		box.CanCollide = true
		box.Size = Vector3.new(10,1,10)
		box.Position = Vector3.new(0,10000,0)
		box.Touched:connect(function(part)
		    if (part.Parent.Name == Local.Name) then
		        if touched == false then
		            touched = true
		            function apply()
		                if script.Disabled ~= true then
		                    no = Char.HumanoidRootPart:Clone()
		                    wait(.25)
		                    Char.HumanoidRootPart:Destroy()
		                    no.Parent = Char
		                    Char:MoveTo(loc)
		                    touched = false
		                end end
		            if Char then
		                apply()
		            end
		        end
		    end
		end)
		repeat wait() until Char
		loc = Char.HumanoidRootPart.Position
		Char:MoveTo(box.Position + Vector3.new(0,.5,0))
		game.StarterGui:SetCore("SendNotification", {
		Title = "Invisibility enabled!";
		Text = "Reset or use ;respawn to remove.";
		})
	end
	if string.sub(msg, 1, 6) == (prefix.."view ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 7))) do
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."unview") then
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Head
	end
	if string.sub(msg, 1, 6) == (prefix.."goto ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 7))) do
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
		end
	end
	if string.sub(msg, 1, 4) == (prefix.."fly") then
		flying = true
		repeat wait()
		until game.Players.LocalPlayer and game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:findFirstChild("Torso") and game.Players.LocalPlayer.Character:findFirstChild("Humanoid")
		local mouse = game.Players.LocalPlayer:GetMouse()
		repeat wait() until mouse
		local plr = game.Players.LocalPlayer
		local torso = plr.Character.Torso
		local deb = true
		local ctrl = {f = 0, b = 0, l = 0, r = 0}
		local lastctrl = {f = 0, b = 0, l = 0, r = 0}
		local maxspeed = 80
		local speed = 0
		 
		function FlyFunction()
		local bg = Instance.new("BodyGyro", torso)
		bg.P = 9e4
		bg.maxTorque = Vector3.new(9e9, 9e9, 9e9)
		bg.cframe = torso.CFrame
		local bv = Instance.new("BodyVelocity", torso)
		bv.velocity = Vector3.new(0,0.1,0)
		bv.maxForce = Vector3.new(9e9, 9e9, 9e9)
		repeat wait()
		plr.Character.Humanoid.PlatformStand = true
		if ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0 then
		speed = speed+.5+(speed/maxspeed)
		if speed > maxspeed then
		speed = maxspeed
		end
		elseif not (ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0) and speed ~= 0 then
		speed = speed-1
		if speed < 0 then
		speed = 0
		end
		end
		if (ctrl.l + ctrl.r) ~= 0 or (ctrl.f + ctrl.b) ~= 0 then
		bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (ctrl.f+ctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(ctrl.l+ctrl.r,(ctrl.f+ctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
		lastctrl = {f = ctrl.f, b = ctrl.b, l = ctrl.l, r = ctrl.r}
		elseif (ctrl.l + ctrl.r) == 0 and (ctrl.f + ctrl.b) == 0 and speed ~= 0 then
		bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (lastctrl.f+lastctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(lastctrl.l+lastctrl.r,(lastctrl.f+lastctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
		else
		bv.velocity = Vector3.new(0,0.1,0)
		end
		bg.cframe = game.Workspace.CurrentCamera.CoordinateFrame * CFrame.Angles(-math.rad((ctrl.f+ctrl.b)*50*speed/maxspeed),0,0)
		until not flying
		ctrl = {f = 0, b = 0, l = 0, r = 0}
		lastctrl = {f = 0, b = 0, l = 0, r = 0}
		speed = 0
		bg:Destroy()
		bv:Destroy()
		plr.Character.Humanoid.PlatformStand = false
		end
		mouse.KeyDown:connect(function(key)
		if key:lower() == "w" then
		ctrl.f = 1
		elseif key:lower() == "s" then
		ctrl.b = -1
		elseif key:lower() == "a" then
		ctrl.l = -1
		elseif key:lower() == "d" then
		ctrl.r = 1
		end
		end)
		mouse.KeyUp:connect(function(key)
		if key:lower() == "w" then
		ctrl.f = 0
		elseif key:lower() == "s" then
		ctrl.b = 0
		elseif key:lower() == "a" then
		ctrl.l = 0
		elseif key:lower() == "d" then
		ctrl.r = 0
		end
		end)
		FlyFunction()
	end
	if string.sub(msg, 1, 6) == (prefix.."unfly") then
		flying = false
	end
	if string.sub(msg, 1, 6) == (prefix.."chat ") then
		game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer((string.sub(msg, 7)), "All")
	end
	if string.sub(msg, 1, 6) == (prefix.."spam ") then
		spamtext = (string.sub(msg, 7))
		spamming = true
	end
	if string.sub(msg, 1, 7) == (prefix.."unspam") then
		spamming = false
	end
	if string.sub(msg, 1, 10) == (prefix.."spamwait ") then
		spamdelay = (string.sub(msg, 11))
	end
	if string.sub(msg, 1, 8) == (prefix.."pmspam ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 9))) do
			pmspammed = v.Name
			spammingpm = true
		end
	end
	if string.sub(msg, 1, 9) == (prefix.."unpmspam") then
		spammingpm = false
	end
	if string.sub(msg, 1, 9) == (prefix.."cfreeze ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 10))) do
			v.Character["Left Leg"].Anchored = true
			v.Character["Left Arm"].Anchored = true
			v.Character["Right Leg"].Anchored = true
			v.Character["Right Arm"].Anchored = true
			v.Character.Torso.Anchored = true
			v.Character.Head.Anchored = true
		end
	end
	if string.sub(msg, 1, 11) == (prefix.."uncfreeze ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 12))) do
			v.Character["Left Leg"].Anchored = false
			v.Character["Left Arm"].Anchored = false
			v.Character["Right Leg"].Anchored = false
			v.Character["Right Arm"].Anchored = false
			v.Character.Torso.Anchored = false
			v.Character.Head.Anchored = false
		end
	end
	if string.sub(msg, 1, 9) == (prefix.."unlockws") then
		local a = game.Workspace:getChildren()
		for i = 1, #a do
			if a[i].className == "Part" then
				a[i].Locked = false
			elseif a[i].className == "Model" then
				local r = a[i]:getChildren()
				for i = 1, #r do
					if r[i].className == "Part" then
					r[i].Locked = false
					end
				end
			end
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "Success!";
		Text = "Workspace unlocked. Use ;lockws to lock.";
		})
	end
	if string.sub(msg, 1, 7) == (prefix.."lockws") then
		local a = game.Workspace:getChildren()
		for i = 1, #a do
			if a[i].className == "Part" then
				a[i].Locked = true
			elseif a[i].className == "Model" then
				local r = a[i]:getChildren()
				for i = 1, #r do
					if r[i].className == "Part" then
					r[i].Locked = true
					end
				end
			end
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."btools") then
		local Clone_T = Instance.new("HopperBin",game.Players.LocalPlayer.Backpack)
		Clone_T.BinType = "Clone"
		local Destruct = Instance.new("HopperBin",game.Players.LocalPlayer.Backpack)
		Destruct.BinType = "Hammer"
		local Hold_T = Instance.new("HopperBin",game.Players.LocalPlayer.Backpack)
		Hold_T.BinType = "Grab"
	end
	if string.sub(msg, 1, 7) == (prefix.."pstand") then
		game.Players.LocalPlayer.Character.Humanoid.PlatformStand = true
	end
	if string.sub(msg, 1, 9) == (prefix.."unpstand") then
		game.Players.LocalPlayer.Character.Humanoid.PlatformStand = false
	end
	if string.sub(msg, 1, 10) == (prefix.."blockhead") then
		game.Players.LocalPlayer.Character.Head.Mesh:Destroy()
	end
	if string.sub(msg, 1, 4) == (prefix.."sit") then
		game.Players.LocalPlayer.Character.Humanoid.Sit = true
	end
	if string.sub(msg, 1, 10) == (prefix.."bringobj ") then
		local function bringobjw()
		for i,obj in ipairs(game.Workspace:GetDescendants()) do
		if obj.Name == (string.sub(msg, 11)) then
		obj.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		obj.CanCollide = false
		obj.Transparency = 0.7
		wait()
		obj.CFrame = game.Players.LocalPlayer.Character["Left Leg"].CFrame
		wait()
		obj.CFrame = game.Players.LocalPlayer.Character["Right Leg"].CFrame
		wait()
		obj.CFrame = game.Players.LocalPlayer.Character["Head"].CFrame
		end
		end
		end
		while wait() do
			bringobjw()
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "BringObj";
		Text = "BringObj enabled.";
		})
	end
	if string.sub(msg, 1, 7) == (prefix.."wsvis ") then
		vis = (string.sub(msg, 8))
		local a = game.Workspace:GetDescendants()
		for i = 1, #a do
			if a[i].className == "Part" then
				a[i].Transparency = vis
			elseif a[i].className == "Model" then
				local r = a[i]:getChildren()
				for i = 1, #r do
					if r[i].className == "Part" then
					r[i].Transparency = vis
					end
				end
			end
		end
	end
	if string.sub(msg, 1, 11) == (prefix.."hypertotal") then
		loadstring(game:GetObjects("rbxassetid://1255063809")[1].Source)()
		game.StarterGui:SetCore("SendNotification", {
		Title = "Success!";
		Text = "HyperTotal GUI Loaded!";
		})
	end
	if string.sub(msg, 1, 5) == (prefix.."cmds") then
		CMDSFRAME.Visible = true
	end
	if string.sub(msg, 1, 10) == (prefix.."rmeshhats") then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Accessory")) or (v:IsA("Hat")) then
				v.Handle.Mesh:Destroy()
			end
		end
	end
	if string.sub(msg, 1, 10) == (prefix.."blockhats") then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Accessory")) or (v:IsA("Hat")) then
				v.Handle.Mesh:Destroy()
			end
		end
	end
	if string.sub(msg, 1, 10) == (prefix.."rmeshtool") then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Tool")) then
				v.Handle.Mesh:Destroy()
			end
		end
	end
	if string.sub(msg, 1, 10) == (prefix.."blocktool") then
		for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
			if (v:IsA("Tool")) then
				v.Handle.Mesh:Destroy()
			end
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."spinner") then
		local p = Instance.new("RocketPropulsion")
		p.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		p.Name = "Spinner"
		p.Target = game.Players.LocalPlayer.Character["Left Arm"]
		p:Fire()
		game.StarterGui:SetCore("SendNotification", {
		Title = "Spinner enabled";
		Text = "Type ;nospinner to disable.";
		})
	end
	if string.sub(msg, 1, 10) == (prefix.."nospinner") then
		game.Players.LocalPlayer.Character.HumanoidRootPart.Spinner:Destroy()
	end
	if string.sub(msg, 1, 7) == (prefix.."reachd") then
		for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
			if v:isA("Tool") then
				local a = Instance.new("SelectionBox",v.Handle)
				a.Adornee = v.Handle
				v.Handle.Size = Vector3.new(0.5,0.5,60)
				v.GripPos = Vector3.new(0,0,0)
				game.Players.LocalPlayer.Character.Humanoid:UnequipTools()
			end
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "Reach applied!";
		Text = "Applied to equipped sword. Use ;noreach to disable.";
		})
	end
	if string.sub(msg, 1, 7) == (prefix.."reach ") then
		for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
			if v:isA("Tool") then
				local a = Instance.new("SelectionBox",v.Handle)
				a.Name = "Reach"
				a.Adornee = v.Handle
				v.Handle.Size = Vector3.new(0.5,0.5,(string.sub(msg, 8)))
				v.GripPos = Vector3.new(0,0,0)
				game.Players.LocalPlayer.Character.Humanoid:UnequipTools()
			end
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "Reach applied!";
		Text = "Applied to equipped sword. Use ;noreach to disable.";
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."noreach") then
		for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
			if v:isA("Tool") then
				v.Handle.Reach:Destroy()
			end
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "Reach removed!";
		Text = "Removed reach from equipped sword.";
		})
	end
	if string.sub(msg, 1, 7) == (prefix.."rkill ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 8)))do
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			wait(0.1)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.2)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.5)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(-100000,10,-100000))
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."tp me ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 8))) do
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."cbring ") then
		if (string.sub(msg, 9)) == "all" or (string.sub(msg, 9)) == "All" or (string.sub(msg, 9)) == "ALL" then
			cbringall = true
		else
			for i,v in pairs(GetPlayer(string.sub(msg, 9))) do
				brplr = v.Name
			end
		end
		cbring = true
	end
	if string.sub(msg, 1, 9) == (prefix.."uncbring") then
		cbring = false
		cbringall = false
	end
	if string.sub(msg, 1, 6) == (prefix.."swap ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 7))) do
			local NOWPLR = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			local function tp(player,player2)
			local char1,char2=player.Character,player2.Character
			if char1 and char2 then
			char1:MoveTo(char2.Head.Position)
			end
			end
			wait(0.1)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.2)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			wait(0.5)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
			wait(0.6)
			tp(game.Players.LocalPlayer, game.Players[v.Name])
			wait(0.4)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOWPLR
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 9) == (prefix.."givetool") then
		for i,v in pairs(GetPlayer(string.sub(msg, 10))) do
			for i,tool in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
				if (tool:IsA("Tool")) then
					tool.Parent = game.Workspace[v.Name]
				end
			end
		end
	end
	if string.sub(msg, 1, 8) == (prefix.."glitch ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 9))) do
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
			wait(0.3)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
			wait(0.4)
			b = Instance.new("BodyForce")
			b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
			b.Name = "Glitch"
			b.Force = Vector3.new(100000000,5000,0)
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools needed!";
			Text = "You need a tool in your backpack for this command!";
			})
		end
	end
	if string.sub(msg, 1, 9) == (prefix.."unglitch") then
		game.Players.LocalPlayer.Character.HumanoidRootPart.Glitch:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(10000,0,10000)
		b = Instance.new("BodyForce")
		b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		b.Name = "unGlitch"
		b.Force = Vector3.new(0,-5000000,0)
		wait(2)
		game.Players.LocalPlayer.Character.HumanoidRootPart.unGlitch:Destroy()
	end
	if string.sub(msg, 1, 9) == (prefix.."grespawn") then
		game.Players.LocalPlayer.Character.Humanoid.Health = 0
		wait(1)
		game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(1000000,0,1000000)
		game.Players.LocalPlayer.Character.Torso.CFrame = CFrame.new(1000000,0,1000000)
	end
	if string.sub(msg, 1, 9) == (prefix.."explorer") then
		loadstring(game:GetObjects("rbxassetid://492005721")[1].Source)()
		game.StarterGui:SetCore("SendNotification", {
		Title = "Success!";
		Text = "DEX Explorer has loaded.";
		})
	end
	if string.sub(msg, 1, 6) == (prefix.."anim ") then
		local Anim = Instance.new("Animation")
		Anim.AnimationId = "rbxassetid://"..(string.sub(msg, 7))
		local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
		track:Play(.1, 1, 1)
	end
	if string.sub(msg, 1, 8) == (prefix.."animgui") then
		loadstring(game:GetObjects("rbxassetid://1202558084")[1].Source)()
		game.StarterGui:SetCore("SendNotification", {
		Title = "Success!";
		Text = "Energize Animations GUI has loaded.";
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."savepos") then
		saved = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		game.StarterGui:SetCore("SendNotification", {
		Title = "Position Saved";
		Text = "Use ;loadpos to return to saved position.";
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."loadpos") then
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = saved
	end
	if string.sub(msg, 1, 6) == (prefix.."bang ") then
		for i,v in pairs(GetPlayer(string.sub(msg, 7))) do
			local Anim2 = Instance.new("Animation")
			Anim2.AnimationId = "rbxassetid://148840371"
			local track2 = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim2)
			track2:Play(.1, 1, 1)
			bplrr = v.Name
			banpl = true
		end
	end
	if string.sub(msg, 1, 7) == (prefix.."unbang") then
		banpl = false
	end
	if string.sub(msg, 1, 10) == (prefix.."bringmod ") then
		local function bringmodw()
		for i,obj in ipairs(game.Workspace:GetDescendants()) do
		if obj.Name == (string.sub(msg, 11)) then
		for i,ch in pairs(obj:GetDescendants()) do
		if (ch:IsA("BasePart")) then
		ch.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		ch.CanCollide = false
		ch.Transparency = 0.7
		wait()
		ch.CFrame = game.Players.LocalPlayer.Character["Left Leg"].CFrame
		wait()
		ch.CFrame = game.Players.LocalPlayer.Character["Right Leg"].CFrame
		wait()
		ch.CFrame = game.Players.LocalPlayer.Character["Head"].CFrame
		end
		end
		end
		end
		end
		while wait() do
			bringmodw()
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "BringMod";
		Text = "BringMod enabled.";
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."respawn") then
		local mod = Instance.new('Model', workspace) mod.Name = 're '..game.Players.LocalPlayer.Name
		local hum = Instance.new('Humanoid', mod)
		local ins = Instance.new('Part', mod) ins.Name = 'Torso' ins.CanCollide = false ins.Transparency = 1
		game.Players.LocalPlayer.Character = mod
	end
	if string.sub(msg, 1, 9) == (prefix.."shutdown") then
		game:GetService'RunService'.Stepped:Connect(function()
		pcall(function()
		    for i,v in pairs(game:GetService'Players':GetPlayers()) do
		        if v.Character ~= nil and v.Character:FindFirstChild'Head' then
		            for _,x in pairs(v.Character.Head:GetChildren()) do
		                if x:IsA'Sound' then x.Playing = true x.CharacterSoundEvent:FireServer(true, true) end
		            end
		        end
		    end
		end)
		end)
		game.StarterGui:SetCore("SendNotification", {
		Title = "Attempting Shutdown";
		Text = "Shutdown Attempt has begun.";
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."delobj ") then
		objtodel = (string.sub(msg, 9))
		delobject()
	end
	if string.sub(msg, 1, 8) == (prefix.."getplrs") then
		for i,v in pairs(game:GetService("Players"):GetChildren())do
			print(v)
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "Printed";
		Text = "Players have been printed to console. (F9)";
		})
	end
	if string.sub(msg, 1, 9) == (prefix.."deldecal") then
		for i,v in pairs(game.Workspace:GetDescendants())do
			if (v:IsA("Decal")) then
				v:Destroy()
			end
		end
	end
	if string.sub(msg, 1, 11) == (prefix.."opfinality") then
		loadstring(game:GetObjects("rbxassetid://1294358929")[1].Source)()
		game.StarterGui:SetCore("SendNotification", {
		Title = "Success!";
		Text = "OpFinality GUI has loaded.";
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."remotes") then
		remotes = true
		added = true
		game.DescendantAdded:connect(function(rmt)
		if added == true then
		if remotes == true then 
		if rmt:IsA("RemoteEvent") then
		print("A RemoteEvent was added!")
		print(" game." .. rmt:GetFullName() .. " | RemoteEvent")
		print(" game." .. rmt:GetFullName() .. " | RemoteEvent", 247, 0, 0, true)
		end end end
		end)
		game.DescendantAdded:connect(function(rmtfnctn)
		if added == true then
		if remotes == true then 
		if rmtfnctn:IsA("RemoteFunction") then
		warn("A RemoteFunction was added!")
		warn(" game." .. rmtfnctn:GetFullName() .. " | RemoteFunction")
		print(" game." .. rmtfnctn:GetFullName() .. " | RemoteFunction", 5, 102, 198, true)
		end end end
		end)
		
		game.DescendantAdded:connect(function(bndfnctn)
		if added == true then
		if binds == true then 
		if bndfnctn:IsA("BindableFunction") then
		print("A BindableFunction was added!")
		print(" game." .. bndfnctn:GetFullName() .. " | BindableFunction")
		print(" game." .. bndfnctn:GetFullName() .. " | BindableFunction", 239, 247, 4, true)
		end end end
		end)
		
		game.DescendantAdded:connect(function(bnd)
		if added == true then
		if binds == true then 
		if bnd:IsA("BindableEvent") then
		warn("A BindableEvent was added!")
		warn(" game." .. bnd:GetFullName() .. " | BindableEvent")
		print(" game." .. bnd:GetFullName() .. " | BindableEvent", 13, 193, 22, true)
		end end end
		end)
		
		
		if binds == true then
		for i,v in pairs(game:GetDescendants()) do
		if v:IsA("BindableFunction") then
		print(" game." .. v:GetFullName() .. " | BindableFunction")
		print(" game." .. v:GetFullName() .. " | BindableFunction", 239, 247, 4, true)
		end end
		for i,v in pairs(game:GetDescendants()) do
		if v:IsA("BindableEvent") then
		warn(" game." .. v:GetFullName() .. " | BindableEvent")
		print(" game." .. v:GetFullName() .. " | BindableEvent", 13, 193, 22, true)
		end end
		else
		print("Off")
		end
		if remotes == true then
		for i,v in pairs(game:GetDescendants()) do
		if v:IsA("RemoteFunction") then
		warn(" game." .. v:GetFullName() .. " | RemoteFunction")
		print(" game." .. v:GetFullName() .. " | RemoteFunction", 5, 102, 198, true)
		end end
		wait()
		for i,v in pairs(game:GetDescendants()) do
		if v:IsA("RemoteEvent") then
		print(" game." .. v:GetFullName() .. " | RemoteEvent")
		print(" game." .. v:GetFullName() .. " | RemoteEvent", 247, 0, 0, true)
		end end
		else
		print("Off")
		end
		game.StarterGui:SetCore("SendNotification", {
		Title = "Printing Remotes";
		Text = "Type ;noremotes to disable.";
		})
	end
	if string.sub(msg, 1, 10) == (prefix.."noremotes") then
		remotes = false
		added = false
		game.StarterGui:SetCore("SendNotification", {
		Title = "Printing Remotes Disabled";
		Text = "Type ;remotes to enable.";
		})
	end
	if string.sub(msg, 1, 10) == (prefix.."tpdefault") then
		spin = false
		followed = false
		traill = false
		noclip = false
		annoying = false
		hwalk = false
		cbringing = false
	end
	if string.sub(msg, 1, 8) == (prefix.."stopsit") then
		stopsitting = true
	end
	if string.sub(msg, 1, 6) == (prefix.."gosit") then
		stopsitting = false
	end
	if string.sub(msg, 1, 8) == (prefix.."version") then
		print(adminversion)
		game.StarterGui:SetCore("SendNotification", {
		Title = "Version";
		Text = adminversion;
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."clicktp") then
		clickgoto = true
		game.StarterGui:SetCore("SendNotification", {
		Title = "Click TP";
		Text = "Press E to teleport to mouse position";
		})
	end
	if string.sub(msg, 1, 10) == (prefix.."noclicktp") then
		clickgoto = false
		game.StarterGui:SetCore("SendNotification", {
		Title = "Click TP";
		Text = "Click TP has been disabled.";
		})
	end
	if string.sub(msg, 1, 8) == (prefix.."toolson") then
		gettingtools = true
		game.StarterGui:SetCore("SendNotification", {
		Title = "Tools Enabled";
		Text = "Automatically colleting tools dropped.";
		})
	end
	if string.sub(msg, 1, 9) == (prefix.."toolsoff") then
		gettingtools = false
		game.StarterGui:SetCore("SendNotification", {
		Title = "Tools Disabled";
		Text = "Click TP has been disabled.";
		})
	end
end)

local function tp()
	for i, player in ipairs(game.Players:GetChildren()) do
		if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
			if player.Name == brplr then
				player.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame + game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame.lookVector * 2
			end
		end
	end
end
local function tpall()
	for i, player in ipairs(game.Players:GetChildren()) do
		if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
			player.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame + game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame.lookVector * 3
		end
	end
end
local function delobject()
	for i,v in pairs(game.Workspace:GetDescendants()) do
		if v.Name == objtodel then
			v:Destroy()
		end
	end
end
spawn(function()
	while wait(spamdelay) do
		if spamming == true then
			game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(spamtext, "All")
		end
	end
end)
spawn(function()
	while wait(spamdelay) do
		if spammingpm == true then
			game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("/w "..pmspammed.." @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@", "All")
		end
	end
end)
spawn(function()
	while wait() do
		if cbring == true then
			tp()
		end
	end
end)
spawn(function()
	while wait() do
		if cbringall == true then
			tpall()
		end
	end
end)
------------------------------------------
local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local CMDBAR = Instance.new("TextBox")
ScreenGui.Parent = game.Players.LocalPlayer.PlayerGui
Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.new(0.3, 0.1, 0.1)
Frame.BackgroundTransparency = 0.3
Frame.Position = UDim2.new(0.5, 0, 0, 10)
Frame.Size = UDim2.new(0, 200, 0, 40)
Frame.Active = true
Frame.Draggable = true
CMDBAR.Name = "CMDBAR"
CMDBAR.Parent = Frame
CMDBAR.BackgroundColor3 = Color3.new(0.105882, 0.164706, 0.207843)
CMDBAR.BackgroundTransparency = 0.20000000298023
CMDBAR.Size = UDim2.new(0, 180, 0, 20)
CMDBAR.Position = UDim2.new(0.05, 0, 0.25, 0)
CMDBAR.Font = Enum.Font.SourceSansLight
CMDBAR.FontSize = Enum.FontSize.Size14
CMDBAR.TextColor3 = Color3.new(0.945098, 0.945098, 0.945098)
CMDBAR.TextScaled = true
CMDBAR.TextSize = 14
CMDBAR.TextWrapped = true
CMDBAR.Text = "Press ; to type, Enter to execute"

Mouse.KeyDown:connect(function(Key)
	if Key == prefix then
		CMDBAR:CaptureFocus()
	end
end)

CMDBAR.FocusLost:connect(function(enterPressed)
	if enterPressed then
		if string.sub(CMDBAR.Text, 1, 5) == ("kill ") then
			if string.sub(CMDBAR.Text, 6) == "me" then
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(100000,0,100000)
			else
				for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 6)))do
					local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
					game.Players.LocalPlayer.Character.Humanoid.Name = 1
					local l = game.Players.LocalPlayer.Character["1"]:Clone()
					l.Parent = game.Players.LocalPlayer.Character
					l.Name = "Humanoid"
					wait(0.1)
					game.Players.LocalPlayer.Character["1"]:Destroy()
					game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
					game.Players.LocalPlayer.Character.Animate.Disabled = true
					wait(0.1)
					game.Players.LocalPlayer.Character.Animate.Disabled = false
					game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
					for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
					game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
					end
					local function tp(player,player2)
					local char1,char2=player.Character,player2.Character
					if char1 and char2 then
					char1:MoveTo(char2.Head.Position)
					end
					end
					wait(0.1)
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
					wait(0.2)
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
					wait(0.5)
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(-100000,10,-100000))
					wait(0.7)
					tp(game.Players.LocalPlayer,game.Players[v.Name])
					wait(0.7)
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
					game.StarterGui:SetCore("SendNotification", {
					Title = "Tools needed!";
					Text = "You need a tool in your backpack for this command!";
					})
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("bring ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 7)))do
				local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				local function tp(player,player2)
				local char1,char2=player.Character,player2.Character
				if char1 and char2 then
				char1.HumanoidRootPart.CFrame = char2.HumanoidRootPart.CFrame
				end
				end
				local function getout(player,player2)
				local char1,char2=player.Character,player2.Character
				if char1 and char2 then
				char1:MoveTo(char2.Head.Position)
				end
				end
				tp(game.Players[v.Name], game.Players.LocalPlayer)
				wait(0.2)
				tp(game.Players[v.Name], game.Players.LocalPlayer)
				wait(0.5)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
				wait(0.5)
				getout(game.Players.LocalPlayer, game.Players[v.Name])
				wait(0.3)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("spin ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 6))) do
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
				spinplr = v
				wait(0.5)
				spin = true
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("unspin") then
			spin = false
			local function getout(player,player2)
			local char1,char2=player.Character,player2.Character
			if char1 and char2 then
			char1:MoveTo(char2.Head.Position)
			end
			end
			getout(game.Players.LocalPlayer, game.Players.LocalPlayer)
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("attach ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 8))) do
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
				wait(0.3)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
				attplr = v
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("unattach ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 9))) do
				local function getout(player,player2)
				local char1,char2=player.Character,player2.Character
				if char1 and char2 then
				char1:MoveTo(char2.Head.Position)
				end
				end
				getout(game.Players.LocalPlayer, game.Players[v.Name])
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("follow ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 8))) do
				followed = true
				flwplr = v
			end
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("unfollow") then
			followed = false
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("freefall ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 10))) do
				local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.2)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.6)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
				wait(0.6)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(0,50000,0)
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("trail ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 7))) do
				traill = true
				trlplr = v
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("untrail") then
			traill = false
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("orbit ") then
			if string.sub(CMDBAR.Text, 7) == "all" or string.sub(CMDBAR.Text, 7) == "others" or string.sub(CMDBAR.Text, 7) == "me" then
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			else
				for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 7))) do
					local o = Instance.new("RocketPropulsion")
					o.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
					o.Name = "Orbit"
					o.Target = game.Players[v.Name].Character.HumanoidRootPart
					o:Fire()
					noclip = true
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("unorbit") then
			game.Players.LocalPlayer.Character.HumanoidRootPart.Orbit:Destroy()
			noclip = false
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("fling ") then
			if string.sub(CMDBAR.Text, 7) == "all" or string.sub(CMDBAR.Text, 7) == "others" or string.sub(CMDBAR.Text, 7) == "me" then
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			else
				for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 7))) do
					local y = Instance.new("RocketPropulsion")
					y.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
					y.CartoonFactor = 1
					y.MaxThrust = 500000
					y.MaxSpeed = 1000
					y.ThrustP = 100000
					y.Name = "Fling"
					game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
					y.Target = game.Players[v.Name].Character.HumanoidRootPart
					y:Fire()
					noclip = true
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("unfling") then
			noclip = false
			game.Players.LocalPlayer.Character.HumanoidRootPart.Fling:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Head
			wait(0.4)
			game.Players.LocalPlayer.Character.HumanoidRootPart.Fling:Destroy()
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("fecheck") then
			if game.Workspace.FilteringEnabled == true then
				warn("FE is Enabled (Filtering Enabled)")
				game.StarterGui:SetCore("SendNotification", {
					Title = "FE is Enabled";
					Text = "Filtering Enabled. Enjoy using Reviz Admin!";
				})
			else
				warn("FE is Disabled (Filtering Disabled) Consider using a different admin script.")
				game.StarterGui:SetCore("SendNotification", {
					Title = "FE is Disabled";
					Text = "Filtering Disabled. Consider using a different admin script.";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("void ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 6))) do
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.2)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.6)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(999999999999999,0,999999999999999)
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("noclip") then
			noclip = true
			game.StarterGui:SetCore("SendNotification", {
			Title = "Noclip enabled";
			Text = "Type ;clip to disable";
			})
		end
		if string.sub(CMDBAR.Text, 1, 4) == ("clip") then
			noclip = false
			game.StarterGui:SetCore("SendNotification", {
			Title = "Noclip disabled";
			Text = "Type ;noclip to enable";
			})
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("speed ") then
			game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = (string.sub(CMDBAR.Text, 7))
		end
		if string.sub(CMDBAR.Text, 1, 3) == ("ws ") then
			game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = (string.sub(CMDBAR.Text, 4))
		end
		if string.sub(CMDBAR.Text, 1, 10) == ("hipheight ") then
			game.Players.LocalPlayer.Character.Humanoid.HipHeight = (string.sub(CMDBAR.Text, 11))
		end
		if string.sub(CMDBAR.Text, 1, 3) == ("hh ") then
			game.Players.LocalPlayer.Character.Humanoid.HipHeight = (string.sub(CMDBAR.Text, 4))
		end
		if string.sub(CMDBAR.Text, 1, 10) == ("jumppower ") then
			game.Players.LocalPlayer.Character.Humanoid.JumpPower = (string.sub(CMDBAR.Text, 11))
		end
		if string.sub(CMDBAR.Text, 1, 3) == ("jp ") then
			game.Players.LocalPlayer.Character.Humanoid.JumpPower = (string.sub(CMDBAR.Text, 4))
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("default") then
			game.Players.LocalPlayer.Character.Humanoid.JumpPower = 50
			game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 16
			game.Players.LocalPlayer.Character.Humanoid.HipHeight = 0
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("annoy ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 7))) do
				annoying = true
				annplr = v
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("unannoy") then
			annoying = false
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("headwalk ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 10))) do
				hwalk = true
				hdwplr = v
			end
		end
		if string.sub(CMDBAR.Text, 1, 10) == ("unheadwalk") then
			hwalk = false
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("nolimbs") then
			game.Players.LocalPlayer.Character["Left Leg"]:Destroy()
			game.Players.LocalPlayer.Character["Left Arm"]:Destroy()
			game.Players.LocalPlayer.Character["Right Leg"]:Destroy()
			game.Players.LocalPlayer.Character["Right Arm"]:Destroy()
		end
		if string.sub(CMDBAR.Text, 1, 3) == ("god") then
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			game.StarterGui:SetCore("SendNotification", {
			Title = "FE Godmode enabled";
			Text = "Use ;kill me OR ;respawn to reset";
			})
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("drophats") then
			for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
				if (v:IsA("Accessory")) or (v:IsA("Hat")) then
					v.Parent = workspace
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("droptool") then
			for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
				if (v:IsA("Tool")) then
					v.Parent = workspace
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("loopdhats") then
			droppinghats = true
			game.StarterGui:SetCore("SendNotification", {
			Title = "Loop Drop Enabled";
			Text = "Type ;unloopdhats to disable";
			})
		end
		if string.sub(CMDBAR.Text, 1, 11) == ("unloopdhats") then
			droppinghats = false
			game.StarterGui:SetCore("SendNotification", {
			Title = "Loop Drop Disabled";
			Text = "Type ;loopdhats to enable.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("loopdtool") then
			droppingtools = true
			game.StarterGui:SetCore("SendNotification", {
			Title = "Loop Drop Enabled";
			Text = "Type ;unloopdtool to disable";
			})
		end
		if string.sub(CMDBAR.Text, 1, 11) == ("unloopdtool") then
			droppingtools = false
			game.StarterGui:SetCore("SendNotification", {
			Title = "Loop Drop Disabled";
			Text = "Type ;loopdtool to enable.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("invisible") then -- Credit to Timeless
			Local = game:GetService('Players').LocalPlayer
			Char  = Local.Character
			touched,tpdback = false, false
			box = Instance.new('Part',workspace)
			box.Anchored = true
			box.CanCollide = true
			box.Size = Vector3.new(10,1,10)
			box.Position = Vector3.new(0,10000,0)
			box.Touched:connect(function(part)
			    if (part.Parent.Name == Local.Name) then
			        if touched == false then
			            touched = true
			            function apply()
			                if script.Disabled ~= true then
			                    no = Char.HumanoidRootPart:Clone()
			                    wait(.25)
			                    Char.HumanoidRootPart:Destroy()
			                    no.Parent = Char
			                    Char:MoveTo(loc)
			                    touched = false
			                end end
			            if Char then
			                apply()
			            end
			        end
			    end
			end)
			repeat wait() until Char
			loc = Char.HumanoidRootPart.Position
			Char:MoveTo(box.Position + Vector3.new(0,.5,0))
			game.StarterGui:SetCore("SendNotification", {
			Title = "Invisibility enabled!";
			Text = "Reset or use ;respawn to remove.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("view ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 6))) do
				game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("unview") then
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Head
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("goto ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 6))) do
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			end
		end
		if string.sub(CMDBAR.Text, 1, 3) == ("fly") then
			flying = true
			repeat wait()
			until game.Players.LocalPlayer and game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:findFirstChild("Torso") and game.Players.LocalPlayer.Character:findFirstChild("Humanoid")
			local mouse = game.Players.LocalPlayer:GetMouse()
			repeat wait() until mouse
			local plr = game.Players.LocalPlayer
			local torso = plr.Character.Torso
			local deb = true
			local ctrl = {f = 0, b = 0, l = 0, r = 0}
			local lastctrl = {f = 0, b = 0, l = 0, r = 0}
			local maxspeed = 80
			local speed = 0
			 
			function FlyFunction()
			local bg = Instance.new("BodyGyro", torso)
			bg.P = 9e4
			bg.maxTorque = Vector3.new(9e9, 9e9, 9e9)
			bg.cframe = torso.CFrame
			local bv = Instance.new("BodyVelocity", torso)
			bv.velocity = Vector3.new(0,0.1,0)
			bv.maxForce = Vector3.new(9e9, 9e9, 9e9)
			repeat wait()
			plr.Character.Humanoid.PlatformStand = true
			if ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0 then
			speed = speed+.5+(speed/maxspeed)
			if speed > maxspeed then
			speed = maxspeed
			end
			elseif not (ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0) and speed ~= 0 then
			speed = speed-1
			if speed < 0 then
			speed = 0
			end
			end
			if (ctrl.l + ctrl.r) ~= 0 or (ctrl.f + ctrl.b) ~= 0 then
			bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (ctrl.f+ctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(ctrl.l+ctrl.r,(ctrl.f+ctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
			lastctrl = {f = ctrl.f, b = ctrl.b, l = ctrl.l, r = ctrl.r}
			elseif (ctrl.l + ctrl.r) == 0 and (ctrl.f + ctrl.b) == 0 and speed ~= 0 then
			bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (lastctrl.f+lastctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(lastctrl.l+lastctrl.r,(lastctrl.f+lastctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
			else
			bv.velocity = Vector3.new(0,0.1,0)
			end
			bg.cframe = game.Workspace.CurrentCamera.CoordinateFrame * CFrame.Angles(-math.rad((ctrl.f+ctrl.b)*50*speed/maxspeed),0,0)
			until not flying
			ctrl = {f = 0, b = 0, l = 0, r = 0}
			lastctrl = {f = 0, b = 0, l = 0, r = 0}
			speed = 0
			bg:Destroy()
			bv:Destroy()
			plr.Character.Humanoid.PlatformStand = false
			end
			mouse.KeyDown:connect(function(key)
			if key:lower() == "w" then
			ctrl.f = 1
			elseif key:lower() == "s" then
			ctrl.b = -1
			elseif key:lower() == "a" then
			ctrl.l = -1
			elseif key:lower() == "d" then
			ctrl.r = 1
			end
			end)
			mouse.KeyUp:connect(function(key)
			if key:lower() == "w" then
			ctrl.f = 0
			elseif key:lower() == "s" then
			ctrl.b = 0
			elseif key:lower() == "a" then
			ctrl.l = 0
			elseif key:lower() == "d" then
			ctrl.r = 0
			end
			end)
			FlyFunction()
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("unfly") then
			flying = false
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("chat ") then
			game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer((string.sub(CMDBAR.Text, 6)), "All")
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("spam ") then
			spamtext = (string.sub(CMDBAR.Text, 6))
			spamming = true
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("unspam") then
			spamming = false
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("spamwait ") then
			spamdelay = (string.sub(CMDBAR.Text, 10))
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("pmspam ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 8))) do
				pmspammed = v.Name
				spammingpm = true
			end
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("unpmspam") then
			spammingpm = false
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("cfreeze ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 9))) do
				v.Character["Left Leg"].Anchored = true
				v.Character["Left Arm"].Anchored = true
				v.Character["Right Leg"].Anchored = true
				v.Character["Right Arm"].Anchored = true
				v.Character.Torso.Anchored = true
				v.Character.Head.Anchored = true
			end
		end
		if string.sub(CMDBAR.Text, 1, 10) == ("uncfreeze ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 11))) do
				v.Character["Left Leg"].Anchored = false
				v.Character["Left Arm"].Anchored = false
				v.Character["Right Leg"].Anchored = false
				v.Character["Right Arm"].Anchored = false
				v.Character.Torso.Anchored = false
				v.Character.Head.Anchored = false
			end
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("unlockws") then
			local a = game.Workspace:getChildren()
			for i = 1, #a do
				if a[i].className == "Part" then
					a[i].Locked = false
				elseif a[i].className == "Model" then
					local r = a[i]:getChildren()
					for i = 1, #r do
						if r[i].className == "Part" then
						r[i].Locked = false
						end
					end
				end
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "Success!";
			Text = "Workspace unlocked. Use ;lockws to lock.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("lockws") then
			local a = game.Workspace:getChildren()
			for i = 1, #a do
				if a[i].className == "Part" then
					a[i].Locked = true
				elseif a[i].className == "Model" then
					local r = a[i]:getChildren()
					for i = 1, #r do
						if r[i].className == "Part" then
						r[i].Locked = true
						end
					end
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("btools") then
			local Clone_T = Instance.new("HopperBin",game.Players.LocalPlayer.Backpack)
			Clone_T.BinType = "Clone"
			local Destruct = Instance.new("HopperBin",game.Players.LocalPlayer.Backpack)
			Destruct.BinType = "Hammer"
			local Hold_T = Instance.new("HopperBin",game.Players.LocalPlayer.Backpack)
			Hold_T.BinType = "Grab"
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("pstand") then
			game.Players.LocalPlayer.Character.Humanoid.PlatformStand = true
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("unpstand") then
			game.Players.LocalPlayer.Character.Humanoid.PlatformStand = false
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("blockhead") then
			game.Players.LocalPlayer.Character.Head.Mesh:Destroy()
		end
		if string.sub(CMDBAR.Text, 1, 3) == ("sit") then
			game.Players.LocalPlayer.Character.Humanoid.Sit = true
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("bringobj ") then
			local function bringobjw()
			for i,obj in ipairs(game.Workspace:GetDescendants()) do
			if obj.Name == (string.sub(CMDBAR.Text, 10)) then
			obj.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			obj.CanCollide = false
			obj.Transparency = 0.7
			wait()
			obj.CFrame = game.Players.LocalPlayer.Character["Left Leg"].CFrame
			wait()
			obj.CFrame = game.Players.LocalPlayer.Character["Right Leg"].CFrame
			wait()
			obj.CFrame = game.Players.LocalPlayer.Character["Head"].CFrame
			end
			end
			end
			while wait() do
				bringobjw()
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "BringObj";
			Text = "BringObj enabled.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("wsvis ") then
			vis = (string.sub(CMDBAR.Text, 7))
			local a = game.Workspace:GetDescendants()
			for i = 1, #a do
				if a[i].className == "Part" then
					a[i].Transparency = vis
				elseif a[i].className == "Model" then
					local r = a[i]:getChildren()
					for i = 1, #r do
						if r[i].className == "Part" then
						r[i].Transparency = vis
						end
					end
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 10) == ("hypertotal") then
			loadstring(game:GetObjects("rbxassetid://1255063809")[1].Source)()
			game.StarterGui:SetCore("SendNotification", {
			Title = "Success!";
			Text = "HyperTotal GUI Loaded!";
			})
		end
		if string.sub(CMDBAR.Text, 1, 4) == ("cmds") then
			CMDSFRAME.Visible = true
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("rmeshhats") then
			for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
				if (v:IsA("Accessory")) or (v:IsA("Hat")) then
					v.Handle.Mesh:Destroy()
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("blockhats") then
			for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
				if (v:IsA("Accessory")) or (v:IsA("Hat")) then
					v.Handle.Mesh:Destroy()
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("rmeshtool") then
			for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
				if (v:IsA("Tool")) then
					v.Handle.Mesh:Destroy()
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("blocktool") then
			for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
				if (v:IsA("Tool")) then
					v.Handle.Mesh:Destroy()
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("spinner") then
			local p = Instance.new("RocketPropulsion")
			p.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
			p.Name = "Spinner"
			p.Target = game.Players.LocalPlayer.Character["Left Arm"]
			p:Fire()
			game.StarterGui:SetCore("SendNotification", {
			Title = "Spinner enabled";
			Text = "Type ;nospinner to disable.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("nospinner") then
			game.Players.LocalPlayer.Character.HumanoidRootPart.Spinner:Destroy()
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("reachd") then
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
				if v:isA("Tool") then
					local a = Instance.new("SelectionBox",v.Handle)
					a.Adornee = v.Handle
					v.Handle.Size = Vector3.new(0.5,0.5,60)
					v.GripPos = Vector3.new(0,0,0)
					game.Players.LocalPlayer.Character.Humanoid:UnequipTools()
				end
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "Reach applied!";
			Text = "Applied to equipped sword. Use ;noreach to disable.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("reach ") then
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
				if v:isA("Tool") then
					local a = Instance.new("SelectionBox",v.Handle)
					a.Name = "Reach"
					a.Adornee = v.Handle
					v.Handle.Size = Vector3.new(0.5,0.5,(string.sub(CMDBAR.Text, 7)))
					v.GripPos = Vector3.new(0,0,0)
					game.Players.LocalPlayer.Character.Humanoid:UnequipTools()
				end
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "Reach applied!";
			Text = "Applied to equipped sword. Use ;noreach to disable.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("noreach") then
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
				if v:isA("Tool") then
					v.Handle.Reach:Destroy()
				end
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "Reach removed!";
			Text = "Removed reach from equipped sword.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("rkill ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 7)))do
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				wait(0.1)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.2)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.5)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(-100000,10,-100000))
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("tp me ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 7))) do
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("cbring ") then
			if (string.sub(CMDBAR.Text, 8)) == "all" or (string.sub(CMDBAR.Text, 8)) == "All" or (string.sub(CMDBAR.Text, 8)) == "ALL" then
				cbringall = true
			else
				for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 8))) do
					brplr = v.Name
				end
			end
			cbring = true
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("uncbring") then
			cbring = false
			cbringall = false
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("swap ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 6))) do
				local NOWPLR = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				local function tp(player,player2)
				local char1,char2=player.Character,player2.Character
				if char1 and char2 then
				char1:MoveTo(char2.Head.Position)
				end
				end
				wait(0.1)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.2)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				wait(0.5)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
				wait(0.6)
				tp(game.Players.LocalPlayer, game.Players[v.Name])
				wait(0.4)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOWPLR
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("givetool") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 9))) do
				for i,tool in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
					if (tool:IsA("Tool")) then
						tool.Parent = game.Workspace[v.Name]
					end
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("glitch ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 8))) do
				game.Players.LocalPlayer.Character.Humanoid.Name = 1
				local l = game.Players.LocalPlayer.Character["1"]:Clone()
				l.Parent = game.Players.LocalPlayer.Character
				l.Name = "Humanoid"
				wait(0.1)
				game.Players.LocalPlayer.Character["1"]:Destroy()
				game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
				game.Players.LocalPlayer.Character.Animate.Disabled = true
				wait(0.1)
				game.Players.LocalPlayer.Character.Animate.Disabled = false
				game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
				for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
				game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
				end
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
				wait(0.3)
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
				wait(0.4)
				b = Instance.new("BodyForce")
				b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
				b.Name = "Glitch"
				b.Force = Vector3.new(100000000,5000,0)
				game.StarterGui:SetCore("SendNotification", {
				Title = "Tools needed!";
				Text = "You need a tool in your backpack for this command!";
				})
			end
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("unglitch") then
			game.Players.LocalPlayer.Character.HumanoidRootPart.Glitch:Destroy()
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(10000,0,10000)
			b = Instance.new("BodyForce")
			b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
			b.Name = "unGlitch"
			b.Force = Vector3.new(0,-5000000,0)
			wait(2)
			game.Players.LocalPlayer.Character.HumanoidRootPart.unGlitch:Destroy()
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("grespawn") then
			game.Players.LocalPlayer.Character.Humanoid.Health = 0
			wait(1)
			game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(1000000,0,1000000)
			game.Players.LocalPlayer.Character.Torso.CFrame = CFrame.new(1000000,0,1000000)
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("explorer") then
			loadstring(game:GetObjects("rbxassetid://492005721")[1].Source)()
			game.StarterGui:SetCore("SendNotification", {
			Title = "Success!";
			Text = "DEX Explorer has loaded.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("anim ") then
			local Anim = Instance.new("Animation")
			Anim.AnimationId = "rbxassetid://"..(string.sub(CMDBAR.Text, 6))
			local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
			track:Play(.1, 1, 1)
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("animgui") then
			loadstring(game:GetObjects("rbxassetid://1202558084")[1].Source)()
			game.StarterGui:SetCore("SendNotification", {
			Title = "Success!";
			Text = "Energize Animations GUI has loaded.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("savepos") then
			saved = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			game.StarterGui:SetCore("SendNotification", {
			Title = "Position Saved";
			Text = "Use ;loadpos to return to saved position.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("loadpos") then
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = saved
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("bang ") then
			for i,v in pairs(GetPlayer(string.sub(CMDBAR.Text, 6))) do
				local Anim2 = Instance.new("Animation")
				Anim2.AnimationId = "rbxassetid://148840371"
				local track2 = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim2)
				track2:Play(.1, 1, 1)
				bplrr = v.Name
				banpl = true
			end
		end
		if string.sub(CMDBAR.Text, 1, 6) == ("unbang") then
			banpl = false
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("bringmod ") then
			local function bringmodw()
			for i,obj in ipairs(game.Workspace:GetDescendants()) do
			if obj.Name == (string.sub(CMDBAR.Text, 10)) then
			for i,ch in pairs(obj:GetDescendants()) do
			if (ch:IsA("BasePart")) then
			ch.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
			ch.CanCollide = false
			ch.Transparency = 0.7
			wait()
			ch.CFrame = game.Players.LocalPlayer.Character["Left Leg"].CFrame
			wait()
			ch.CFrame = game.Players.LocalPlayer.Character["Right Leg"].CFrame
			wait()
			ch.CFrame = game.Players.LocalPlayer.Character["Head"].CFrame
			end
			end
			end
			end
			end
			while wait() do
				bringmodw()
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "BringMod";
			Text = "BringMod enabled.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("respawn") then
			local mod = Instance.new('Model', workspace) mod.Name = 're '..game.Players.LocalPlayer.Name
			local hum = Instance.new('Humanoid', mod)
			local ins = Instance.new('Part', mod) ins.Name = 'Torso' ins.CanCollide = false ins.Transparency = 1
			game.Players.LocalPlayer.Character = mod
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("shutdown") then
			game:GetService'RunService'.Stepped:Connect(function()
			pcall(function()
			    for i,v in pairs(game:GetService'Players':GetPlayers()) do
			        if v.Character ~= nil and v.Character:FindFirstChild'Head' then
			            for _,x in pairs(v.Character.Head:GetChildren()) do
			                if x:IsA'Sound' then x.Playing = true x.CharacterSoundEvent:FireServer(true, true) end
			            end
			        end
			    end
			end)
			end)
			game.StarterGui:SetCore("SendNotification", {
			Title = "Attempting Shutdown";
			Text = "Shutdown Attempt has begun.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("delobj ") then
			objtodel = (string.sub(CMDBAR.Text, 8))
			delobject()
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("getplrs") then
			for i,v in pairs(game:GetService("Players"):GetChildren())do
				print(v)
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "Printed";
			Text = "Players have been printed to console. (F9)";
			})
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("deldecal") then
			for i,v in pairs(game.Workspace:GetDescendants())do
				if (v:IsA("Decal")) then
					v:Destroy()
				end
			end
		end
		if string.sub(CMDBAR.Text, 1, 10) == ("opfinality") then
			loadstring(game:GetObjects("rbxassetid://1294358929")[1].Source)()
			game.StarterGui:SetCore("SendNotification", {
			Title = "Success!";
			Text = "OpFinality GUI has loaded.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("remotes") then
			remotes = true
			added = true
			game.DescendantAdded:connect(function(rmt)
			if added == true then
			if remotes == true then 
			if rmt:IsA("RemoteEvent") then
			print("A RemoteEvent was added!")
			print(" game." .. rmt:GetFullName() .. " | RemoteEvent")
			print(" game." .. rmt:GetFullName() .. " | RemoteEvent", 247, 0, 0, true)
			end end end
			end)
			game.DescendantAdded:connect(function(rmtfnctn)
			if added == true then
			if remotes == true then 
			if rmtfnctn:IsA("RemoteFunction") then
			warn("A RemoteFunction was added!")
			warn(" game." .. rmtfnctn:GetFullName() .. " | RemoteFunction")
			print(" game." .. rmtfnctn:GetFullName() .. " | RemoteFunction", 5, 102, 198, true)
			end end end
			end)
			
			game.DescendantAdded:connect(function(bndfnctn)
			if added == true then
			if binds == true then 
			if bndfnctn:IsA("BindableFunction") then
			print("A BindableFunction was added!")
			print(" game." .. bndfnctn:GetFullName() .. " | BindableFunction")
			print(" game." .. bndfnctn:GetFullName() .. " | BindableFunction", 239, 247, 4, true)
			end end end
			end)
			
			game.DescendantAdded:connect(function(bnd)
			if added == true then
			if binds == true then 
			if bnd:IsA("BindableEvent") then
			warn("A BindableEvent was added!")
			warn(" game." .. bnd:GetFullName() .. " | BindableEvent")
			print(" game." .. bnd:GetFullName() .. " | BindableEvent", 13, 193, 22, true)
			end end end
			end)
			
			
			if binds == true then
			for i,v in pairs(game:GetDescendants()) do
			if v:IsA("BindableFunction") then
			print(" game." .. v:GetFullName() .. " | BindableFunction")
			print(" game." .. v:GetFullName() .. " | BindableFunction", 239, 247, 4, true)
			end end
			for i,v in pairs(game:GetDescendants()) do
			if v:IsA("BindableEvent") then
			warn(" game." .. v:GetFullName() .. " | BindableEvent")
			print(" game." .. v:GetFullName() .. " | BindableEvent", 13, 193, 22, true)
			end end
			else
			print("Off")
			end
			if remotes == true then
			for i,v in pairs(game:GetDescendants()) do
			if v:IsA("RemoteFunction") then
			warn(" game." .. v:GetFullName() .. " | RemoteFunction")
			print(" game." .. v:GetFullName() .. " | RemoteFunction", 5, 102, 198, true)
			end end
			wait()
			for i,v in pairs(game:GetDescendants()) do
			if v:IsA("RemoteEvent") then
			print(" game." .. v:GetFullName() .. " | RemoteEvent")
			print(" game." .. v:GetFullName() .. " | RemoteEvent", 247, 0, 0, true)
			end end
			else
			print("Off")
			end
			game.StarterGui:SetCore("SendNotification", {
			Title = "Printing Remotes";
			Text = "Type ;noremotes to disable.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("noremotes") then
			remotes = false
			added = false
			game.StarterGui:SetCore("SendNotification", {
			Title = "Printing Remotes Disabled";
			Text = "Type ;remotes to enable.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("tpdefault") then
			spin = false
			followed = false
			traill = false
			noclip = false
			annoying = false
			hwalk = false
			cbringing = false
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("stopsit") then
			stopsitting = true
		end
		if string.sub(CMDBAR.Text, 1, 5) == ("gosit") then
			stopsitting = false
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("version") then
			print(adminversion)
			game.StarterGui:SetCore("SendNotification", {
			Title = "Version";
			Text = adminversion;
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("clicktp") then
			clickgoto = true
			game.StarterGui:SetCore("SendNotification", {
			Title = "Click TP";
			Text = "Press E to teleport to mouse position";
			})
		end
		if string.sub(CMDBAR.Text, 1, 9) == ("noclicktp") then
			clickgoto = false
			game.StarterGui:SetCore("SendNotification", {
			Title = "Click TP";
			Text = "Click TP has been disabled.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 7) == ("toolson") then
			gettingtools = true
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools Enabled";
			Text = "Automatically colleting tools dropped.";
			})
		end
		if string.sub(CMDBAR.Text, 1, 8) == ("toolsoff") then
			gettingtools = false
			game.StarterGui:SetCore("SendNotification", {
			Title = "Tools Disabled";
			Text = "Click TP has been disabled.";
			})
		end
		CMDBAR.Text = ""
	end
end)

wait(0.3)
game.StarterGui:SetCore("SendNotification", {
	Title = "Loaded successfully!";
	Text = "Reviz Admin by illremember";
})
wait(0.1)
if game.Workspace.FilteringEnabled == true then
	warn("FE is Enabled (Filtering Enabled)")
	game.StarterGui:SetCore("SendNotification", {
		Title = "FE is Enabled";
		Text = "Filtering Enabled. Enjoy using Reviz Admin!";
	})
else
	warn("FE is Disabled (Filtering Disabled) Consider using a different admin script.")
	game.StarterGui:SetCore("SendNotification", {
		Title = "FE is Disabled";
		Text = "Filtering Disabled. Consider using a different admin script.";
	})
end

end)

shutdown.Name = "shutdown"
shutdown.Parent = Scripts
shutdown.BackgroundColor3 = Color3.new(0, 0, 0)
shutdown.BackgroundTransparency = 0.5
shutdown.Position = UDim2.new(0, 0, 0, 857)
shutdown.Size = UDim2.new(0, 200, 0, 50)
shutdown.Font = Enum.Font.SourceSans
shutdown.FontSize = Enum.FontSize.Size14
shutdown.Text = "Shutdown"
shutdown.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
shutdown.TextSize = 14
shutdown.MouseButton1Down:connect(function()
sounds = {}

function getSounds(loc)
if loc:IsA("Sound") then
table.insert(sounds,loc)
end
for _,obj in pairs(loc:GetChildren()) do
getSounds(obj)
end
end

getSounds(game)

game.DescendantAdded:connect(function(obj)
if obj:IsA("Sound") then
table.insert(sounds,obj)
end
end)

while wait(0.2) do
for _,sound in pairs(sounds) do
pcall(function()
sound:Play()
end)
end
end
end)

bomb.Name = "bomb"
bomb.Parent = Scripts
bomb.BackgroundColor3 = Color3.new(0, 0, 0)
bomb.BackgroundTransparency = 0.5
bomb.Position = UDim2.new(0, 0, 0, 907)
bomb.Size = UDim2.new(0, 200, 0, 50)
bomb.Font = Enum.Font.SourceSans
bomb.FontSize = Enum.FontSize.Size14
bomb.Text = "Bomb Vest (City Life)"
bomb.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
bomb.TextSize = 14
bomb.MouseButton1Down:connect(function()
Player=game:GetService("Players").LocalPlayer
Character=Player.Character
PlayerGui=Player.PlayerGui
Backpack=Player.Backpack
Torso=Character.Torso
Head=Character.Head
Humanoid=Character.Humanoid
m=Instance.new('Model',Character)
LeftArm=Character["Left Arm"]
LeftLeg=Character["Left Leg"]
RightArm=Character["Right Arm"]
RightLeg=Character["Right Leg"]
LS=Torso["Left Shoulder"]
LH=Torso["Left Hip"]
RS=Torso["Right Shoulder"]
RH=Torso["Right Hip"]
Face = Head.face
Neck=Torso.Neck
it=Instance.new
attacktype=1
vt=Vector3.new
cf=CFrame.new
euler=CFrame.fromEulerAnglesXYZ
angles=CFrame.Angles
cloaked=false
necko=cf(0, 1, 0, -1, -0, -0, 0, 0, 1, 0, 1, 0)
necko2=cf(0, -0.5, 0, -1, -0, -0, 0, 0, 1, 0, 1, 0)
LHC0=cf(-1,-1,0,-0,-0,-1,0,1,0,1,0,0)
LHC1=cf(-0.5,1,0,-0,-0,-1,0,1,0,1,0,0)
RHC0=cf(1,-1,0,0,0,1,0,1,0,-1,-0,-0)
RHC1=cf(0.5,1,0,0,0,1,0,1,0,-1,-0,-0)
RootPart=Character.HumanoidRootPart
RootJoint=RootPart.RootJoint
RootCF=euler(-1.57,0,3.14)
attack = false
attackdebounce = false
deb=false
equipped=true
hand=false
MMouse=nil
combo=0
mana=0
trispeed=.2
attackmode='none'
local idle=0
local Anim="Idle"
local Effects={}
local gun=false
local shoot=false
player=nil
mana=0
 
mouse=Player:GetMouse()
--save shoulders
RSH, LSH=nil, nil
--welds
RW, LW=Instance.new("Weld"), Instance.new("Weld")
RW.Name="Right Shoulder" LW.Name="Left Shoulder"
LH=Torso["Left Hip"]
RH=Torso["Right Hip"]
TorsoColor=Torso.BrickColor
function NoOutline(Part)
Part.TopSurface,Part.BottomSurface,Part.LeftSurface,Part.RightSurface,Part.FrontSurface,Part.BackSurface = 10,10,10,10,10,10
end
player=Player
ch=Character
RSH=ch.Torso["Right Shoulder"]
LSH=ch.Torso["Left Shoulder"]
-- 
RSH.Parent=nil
LSH.Parent=nil
-- 
RW.Name="Right Shoulder"
RW.Part0=ch.Torso
RW.C0=cf(1.5, 0.5, 0) --* CFrame.fromEulerAnglesXYZ(1.3, 0, -0.5)
RW.C1=cf(0, 0.5, 0)
RW.Part1=ch["Right Arm"]
RW.Parent=ch.Torso
-- 
LW.Name="Left Shoulder"
LW.Part0=ch.Torso
LW.C0=cf(-1.5, 0.5, 0) --* CFrame.fromEulerAnglesXYZ(1.7, 0, 0.8)
LW.C1=cf(0, 0.5, 0)
LW.Part1=ch["Left Arm"]
LW.Parent=ch.Torso
 
        Player=game:GetService('Players').LocalPlayer
        Character=Player.Character
        Mouse=Player:GetMouse()
        m=Instance.new('Model',Character)
 
 
        local function weldBetween(a, b)
            local weldd = Instance.new("ManualWeld")
            weldd.Part0 = a
            weldd.Part1 = b
            weldd.C0 = CFrame.new()
            weldd.C1 = b.CFrame:inverse() * a.CFrame
            weldd.Parent = a
            return weldd
        end
       
        function swait(num)
    if num==0 or num==nil then
    game:service'RunService'.Stepped:wait(0)
    else
    for i=0,num do
    game:service'RunService'.Stepped:wait(0)
    end
    end
            end
       
        function nooutline(part)
                part.TopSurface,part.BottomSurface,part.LeftSurface,part.RightSurface,part.FrontSurface,part.BackSurface = 10,10,10,10,10,10
        end
       
        function part(formfactor,parent,material,reflectance,transparency,brickcolor,name,size)
                local fp=it("Part")
                fp.formFactor=formfactor
                fp.Parent=parent
                fp.Reflectance=reflectance
                fp.Transparency=transparency
                fp.CanCollide=false
                fp.Locked=true
                fp.BrickColor=BrickColor.new(tostring(brickcolor))
                fp.Name=name
                fp.Size=size
                fp.Position=Character.Torso.Position
                nooutline(fp)
                fp.Material=material
                fp:BreakJoints()
                return fp
        end
       
        function mesh(Mesh,part,meshtype,meshid,offset,scale)
                local mesh=it(Mesh)
                mesh.Parent=part
                if Mesh=="SpecialMesh" then
                        mesh.MeshType=meshtype
                        mesh.MeshId=meshid
                end
                mesh.Offset=offset
                mesh.Scale=scale
                return mesh
        end
       
        function weld(parent,part0,part1,c0,c1)
                local weld=it("Weld")
                weld.Parent=parent
                weld.Part0=part0
                weld.Part1=part1
                weld.C0=c0
                weld.C1=c1
                return weld
        end
       
       
local function CFrameFromTopBack(at, top, back)
local right = top:Cross(back)
return CFrame.new(at.x, at.y, at.z,
right.x, top.x, back.x,
right.y, top.y, back.y,
right.z, top.z, back.z)
end
 
function Triangle(a, b, c)
local edg1 = (c-a):Dot((b-a).unit)
local edg2 = (a-b):Dot((c-b).unit)
local edg3 = (b-c):Dot((a-c).unit)
if edg1 <= (b-a).magnitude and edg1 >= 0 then
a, b, c = a, b, c
elseif edg2 <= (c-b).magnitude and edg2 >= 0 then
a, b, c = b, c, a
elseif edg3 <= (a-c).magnitude and edg3 >= 0 then
a, b, c = c, a, b
else
assert(false, "unreachable")
end
 
local len1 = (c-a):Dot((b-a).unit)
local len2 = (b-a).magnitude - len1
local width = (a + (b-a).unit*len1 - c).magnitude
 
local maincf = CFrameFromTopBack(a, (b-a):Cross(c-b).unit, -(b-a).unit)
 
local list = {}
 
local TrailColor = ("Dark grey")
 
if len1 > 0.01 then
local w1 = Instance.new('WedgePart', m)
game:GetService("Debris"):AddItem(w1,5)
w1.Material = "SmoothPlastic"
w1.FormFactor = 'Custom'
w1.BrickColor = BrickColor.new(TrailColor)
w1.Transparency = 0
w1.Reflectance = 0
w1.Material = "SmoothPlastic"
w1.CanCollide = false
NoOutline(w1)
local sz = Vector3.new(0.2, width, len1)
w1.Size = sz
local sp = Instance.new("SpecialMesh",w1)
sp.MeshType = "Wedge"
sp.Scale = Vector3.new(0,1,1) * sz/w1.Size
w1:BreakJoints()
w1.Anchored = true
w1.Parent = workspace
w1.Transparency = 0.7
table.insert(Effects,{w1,"Disappear",.01})
w1.CFrame = maincf*CFrame.Angles(math.pi,0,math.pi/2)*CFrame.new(0,width/2,len1/2)
table.insert(list,w1)
end
 
if len2 > 0.01 then
local w2 = Instance.new('WedgePart', m)
game:GetService("Debris"):AddItem(w2,5)
w2.Material = "SmoothPlastic"
w2.FormFactor = 'Custom'
w2.BrickColor = BrickColor.new(TrailColor)
w2.Transparency = 0
w2.Reflectance = 0
w2.Material = "SmoothPlastic"
w2.CanCollide = false
NoOutline(w2)
local sz = Vector3.new(0.2, width, len2)
w2.Size = sz
local sp = Instance.new("SpecialMesh",w2)
sp.MeshType = "Wedge"
sp.Scale = Vector3.new(0,1,1) * sz/w2.Size
w2:BreakJoints()
w2.Anchored = true
w2.Parent = workspace
w2.Transparency = 0.7
table.insert(Effects,{w2,"Disappear",.01})
w2.CFrame = maincf*CFrame.Angles(math.pi,math.pi,-math.pi/2)*CFrame.new(0,width/2,-len1 - len2/2)
table.insert(list,w2)
end
return unpack(list)
end
       
       
so = function(id,par,vol,pit)
coroutine.resume(coroutine.create(function()
local sou = Instance.new("Sound",par or workspace)
sou.Volume=vol
sou.Pitch=pit or 1
sou.SoundId=id
swait()
sou:play()
game:GetService("Debris"):AddItem(sou,6)
end))
end
 
function clerp(a,b,t)
local qa = {QuaternionFromCFrame(a)}
local qb = {QuaternionFromCFrame(b)}
local ax, ay, az = a.x, a.y, a.z
local bx, by, bz = b.x, b.y, b.z
local _t = 1-t
return QuaternionToCFrame(_t*ax + t*bx, _t*ay + t*by, _t*az + t*bz,QuaternionSlerp(qa, qb, t))
end
 
function QuaternionFromCFrame(cf)
local mx, my, mz, m00, m01, m02, m10, m11, m12, m20, m21, m22 = cf:components()
local trace = m00 + m11 + m22
if trace > 0 then
local s = math.sqrt(1 + trace)
local recip = 0.5/s
return (m21-m12)*recip, (m02-m20)*recip, (m10-m01)*recip, s*0.5
else
local i = 0
if m11 > m00 then
i = 1
end
if m22 > (i == 0 and m00 or m11) then
i = 2
end
if i == 0 then
local s = math.sqrt(m00-m11-m22+1)
local recip = 0.5/s
return 0.5*s, (m10+m01)*recip, (m20+m02)*recip, (m21-m12)*recip
elseif i == 1 then
local s = math.sqrt(m11-m22-m00+1)
local recip = 0.5/s
return (m01+m10)*recip, 0.5*s, (m21+m12)*recip, (m02-m20)*recip
elseif i == 2 then
local s = math.sqrt(m22-m00-m11+1)
local recip = 0.5/s return (m02+m20)*recip, (m12+m21)*recip, 0.5*s, (m10-m01)*recip
end
end
end
 
function QuaternionToCFrame(px, py, pz, x, y, z, w)
local xs, ys, zs = x + x, y + y, z + z
local wx, wy, wz = w*xs, w*ys, w*zs
local xx = x*xs
local xy = x*ys
local xz = x*zs
local yy = y*ys
local yz = y*zs
local zz = z*zs
return CFrame.new(px, py, pz,1-(yy+zz), xy - wz, xz + wy,xy + wz, 1-(xx+zz), yz - wx, xz - wy, yz + wx, 1-(xx+yy))
end
 
function QuaternionSlerp(a, b, t)
local cosTheta = a[1]*b[1] + a[2]*b[2] + a[3]*b[3] + a[4]*b[4]
local startInterp, finishInterp;
if cosTheta >= 0.0001 then
if (1 - cosTheta) > 0.0001 then
local theta = math.acos(cosTheta)
local invSinTheta = 1/math.sin(theta)
startInterp = math.sin((1-t)*theta)*invSinTheta
finishInterp = math.sin(t*theta)*invSinTheta  
else
startInterp = 1-t
finishInterp = t
end
else
if (1+cosTheta) > 0.0001 then
local theta = math.acos(-cosTheta)
local invSinTheta = 1/math.sin(theta)
startInterp = math.sin((t-1)*theta)*invSinTheta
finishInterp = math.sin(t*theta)*invSinTheta
else
startInterp = t-1
finishInterp = t
end
end
return a[1]*startInterp + b[1]*finishInterp, a[2]*startInterp + b[2]*finishInterp, a[3]*startInterp + b[3]*finishInterp, a[4]*startInterp + b[4]*finishInterp
end
 
--Example: Torso.Weld.C0 = clerp(Torso.Weld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0)), 0.4)
 
 
function rayCast(Pos, Dir, Max, Ignore)  -- Origin Position , Direction, MaxDistance , IgnoreDescendants
return game:service("Workspace"):FindPartOnRay(Ray.new(Pos, Dir.unit * (Max or 999.999)), Ignore)
end
 
Damagefunc=function(hit,minim,maxim,knockback,Type,Property,Delay,KnockbackType,decreaseblock)
        if hit.Parent==nil then
                return
        end
        h=hit.Parent:FindFirstChild("Humanoid")
        for _,v in pairs(hit.Parent:children()) do
        if v:IsA("Humanoid") then
        h=v
        end
        end
        if hit.Parent.Parent:FindFirstChild("Torso")~=nil then
        h=hit.Parent.Parent:FindFirstChild("Humanoid")
        end
        if hit.Parent.className=="Hat" then
        hit=hit.Parent.Parent:findFirstChild("Head")
        end
        if h~=nil and hit.Parent.Name~=Character.Name and hit.Parent:FindFirstChild("Torso")~=nil then
        if hit.Parent:findFirstChild("DebounceHit")~=nil then if hit.Parent.DebounceHit.Value==true then return end end
        --[[                if game.Players:GetPlayerFromCharacter(hit.Parent)~=nil then
                        return
                end]]
--                        hs(hit,1.2)
                        c=Instance.new("ObjectValue")
                        c.Name="creator"
                        c.Value=game:service("Players").LocalPlayer
                        c.Parent=h
                        game:GetService("Debris"):AddItem(c,.5)
                Damage=math.random(minim,maxim)
--                h:TakeDamage(Damage)
                blocked=false
                block=hit.Parent:findFirstChild("Block")
                if block~=nil then
                print(block.className)
                if block.className=="NumberValue" then
                if block.Value>0 then
                blocked=true
                if decreaseblock==nil then
                block.Value=block.Value-1
                end
                end
                end
                if block.className=="IntValue" then
                if block.Value>0 then
                blocked=true
                if decreaseblock~=nil then
                block.Value=block.Value-1
                end
                end
                end
                end
                if blocked==false then
--                h:TakeDamage(Damage)
                h.Health=h.Health-Damage
                showDamage(hit.Parent,Damage,.5,BrickColor.new("New Yeller"))
                else
                h.Health=h.Health-(Damage/2)
                showDamage(hit.Parent,Damage/2,.5,BrickColor.new("Bright blue"))
                end
                if Type=="Knockdown" then
                hum=hit.Parent.Humanoid
hum.PlatformStand=true
coroutine.resume(coroutine.create(function(HHumanoid)
swait(1)
HHumanoid.PlatformStand=false
end),hum)
                local angle=(hit.Position-(Property.Position+Vector3.new(0,0,0))).unit
--hit.CFrame=CFrame.new(hit.Position,Vector3.new(angle.x,hit.Position.y,angle.z))*CFrame.fromEulerAnglesXYZ(math.pi/4,0,0)
local bodvol=Instance.new("BodyVelocity")
bodvol.velocity=angle*knockback
bodvol.P=5000
bodvol.maxForce=Vector3.new(8e+003, 8e+003, 8e+003)
bodvol.Parent=hit
rl=Instance.new("BodyAngularVelocity")
rl.P=3000
rl.maxTorque=Vector3.new(500000,500000,500000)*50000000000000
rl.angularvelocity=Vector3.new(math.random(-10,10),math.random(-10,10),math.random(-10,10))
rl.Parent=hit
game:GetService("Debris"):AddItem(bodvol,.5)
game:GetService("Debris"):AddItem(rl,.5)
                elseif Type=="Normal" then
                vp=Instance.new("BodyVelocity")
                vp.P=500
                vp.maxForce=Vector3.new(math.huge,0,math.huge)
--                vp.velocity=Character.Torso.CFrame.lookVector*Knockback
                if KnockbackType==1 then
                vp.velocity=Property.CFrame.lookVector*knockback+Property.Velocity/1.05
                elseif KnockbackType==2 then
                vp.velocity=Property.CFrame.lookVector*knockback
                end
                if knockback>0 then
                        vp.Parent=hit.Parent.Torso
                end
                game:GetService("Debris"):AddItem(vp,.5)
                elseif Type=="Up" then
                local bodyVelocity=Instance.new("BodyVelocity")
                bodyVelocity.velocity=vt(0,60,0)
                bodyVelocity.P=5000
                bodyVelocity.maxForce=Vector3.new(8e+003, 8e+003, 8e+003)
                bodyVelocity.Parent=hit
                game:GetService("Debris"):AddItem(bodyVelocity,1)
                rl=Instance.new("BodyAngularVelocity")
                rl.P=3000
                rl.maxTorque=Vector3.new(500000,500000,500000)*50000000000000
                rl.angularvelocity=Vector3.new(math.random(-30,30),math.random(-30,30),math.random(-30,30))
                rl.Parent=hit
                game:GetService("Debris"):AddItem(rl,.5)
                elseif Type=="Snare" then
                bp=Instance.new("BodyPosition")
                bp.P=2000
                bp.D=100
                bp.maxForce=Vector3.new(math.huge,math.huge,math.huge)
                bp.position=hit.Parent.Torso.Position
                bp.Parent=hit.Parent.Torso
                game:GetService("Debris"):AddItem(bp,1)
                elseif Type=="Target" then
                if Targetting==false then
                ZTarget=hit.Parent.Torso
                coroutine.resume(coroutine.create(function(Part)
                so("http://www.roblox.com/asset/?id=15666462",Part,1,1.5)
                swait(5)
                so("http://www.roblox.com/asset/?id=15666462",Part,1,1.5)
                end),ZTarget)
                TargHum=ZTarget.Parent:findFirstChild("Humanoid")
                targetgui=Instance.new("BillboardGui")
                targetgui.Parent=ZTarget
                targetgui.Size=UDim2.new(10,100,10,100)
                targ=Instance.new("ImageLabel")
                targ.Parent=targetgui
                targ.BackgroundTransparency=1
                targ.Image="rbxassetid://4834067"
                targ.Size=UDim2.new(1,0,1,0)
                cam.CameraType="Scriptable"
                cam.CoordinateFrame=CFrame.new(Head.CFrame.p,ZTarget.Position)
                dir=Vector3.new(cam.CoordinateFrame.lookVector.x,0,cam.CoordinateFrame.lookVector.z)
                workspace.CurrentCamera.CoordinateFrame=CFrame.new(Head.CFrame.p,ZTarget.Position)
                Targetting=true
                RocketTarget=ZTarget
                for i=1,Property do
                --while Targetting==true and Humanoid.Health>0 and Character.Parent~=nil do
                if Humanoid.Health>0 and Character.Parent~=nil and TargHum.Health>0 and TargHum.Parent~=nil and Targetting==true then
                swait()
                end
                --workspace.CurrentCamera.CoordinateFrame=CFrame.new(Head.CFrame.p,Head.CFrame.p+rmdir*100)
                cam.CoordinateFrame=CFrame.new(Head.CFrame.p,ZTarget.Position)
                dir=Vector3.new(cam.CoordinateFrame.lookVector.x,0,cam.CoordinateFrame.lookVector.z)
                cam.CoordinateFrame=CFrame.new(Head.CFrame.p,ZTarget.Position)*cf(0,5,10)*euler(-0.3,0,0)
                end
                Targetting=false
                RocketTarget=nil
                targetgui.Parent=nil
                cam.CameraType="Custom"
                end
                end
                        debounce=Instance.new("BoolValue")
                        debounce.Name="DebounceHit"
                        debounce.Parent=hit.Parent
                        debounce.Value=true
                        game:GetService("Debris"):AddItem(debounce,Delay)
                        c=Instance.new("ObjectValue")
                        c.Name="creator"
                        c.Value=Player
                        c.Parent=h
                        game:GetService("Debris"):AddItem(c,.5)
                CRIT=false
                hitDeb=true
                AttackPos=6
        end
end
 
showDamage=function(Char,Dealt,du,Color)
        m=Instance.new("Model")
        m.Name=tostring(Dealt)
        h=Instance.new("Humanoid")
        h.Health=0
        h.MaxHealth=0
        h.Parent=m
        c=Instance.new("Part")
        c.Transparency=0
        c.BrickColor=Color
        c.Name="Head"
        c.TopSurface=0
        c.BottomSurface=0
        c.formFactor="Plate"
        c.Size=Vector3.new(1,.4,1)
        ms=Instance.new("CylinderMesh")
        ms.Scale=Vector3.new(.8,.8,.8)
        if CRIT==true then
                ms.Scale=Vector3.new(1,1.25,1)
        end
        ms.Parent=c
        c.Reflectance=0
        Instance.new("BodyGyro").Parent=c
        c.Parent=m
        if Char:findFirstChild("Head")~=nil then
        c.CFrame=CFrame.new(Char["Head"].CFrame.p+Vector3.new(0,1.5,0))
        elseif Char.Parent:findFirstChild("Head")~=nil then
        c.CFrame=CFrame.new(Char.Parent["Head"].CFrame.p+Vector3.new(0,1.5,0))
        end
        f=Instance.new("BodyPosition")
        f.P=2000
        f.D=100
        f.maxForce=Vector3.new(math.huge,math.huge,math.huge)
        f.position=c.Position+Vector3.new(0,3,0)
        f.Parent=c
        game:GetService("Debris"):AddItem(m,.5+du)
        c.CanCollide=false
        m.Parent=workspace
        c.CanCollide=false
end
 
VestHandle=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Handle",Vector3.new(2.01999998, 1.39999998, 1.01999998))
handleweld=weld(m,Character["Torso"],VestHandle,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(1.52587891e-005, 0.300115585, 3.05175781e-005, 0.999999642, 0, 0, 0, 1, 0, 0, 0, 0.999999642))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"White","Part",Vector3.new(1, 0.76000005, 0.600000024))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.509597778, -0.490081787, 0.200000286, -0.999999642, 0, 0, 0, 0, 0.999999642, 0, 1, 0))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=104516854",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.01999998, 0.600000024, 0.800000012))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.000152587891, -0.999994516, -0.200134277, -4.47035475e-008, 0, 0.999999642, 0, 1, 0, -0.999999642, 0, -4.4703544e-008))
mesh("SpecialMesh",Part,Enum.MeshType.Wedge,"",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.200000003, 0.620000005, 1.01999998))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.700012207, -1.00999117, 1.52587891e-005, 0.999999046, 0, 0, 0, 1, 0, 0, 0, 0.999999046))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.200000003, 0.620000005, 1.01999998))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.699127197, -1.00999379, 0.000549316406, 0.999997914, 6.38506317e-005, -2.78951497e-015, -6.38804122e-005, 1.00000012, 2.10474918e-015, 2.78942159e-015, 1.39239913e-015, 0.999997854))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Bright red","Part",Vector3.new(0.200000003, 0.400000036, 1.19999993))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.609390259, 0.811340332, -0.0999908447, 3.08029073e-018, -2.69585922e-014, -0.999999642, -0.999999642, -6.39334685e-005, -1.35697087e-018, -6.39334467e-005, 1, -2.6958582e-014))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=12891705",Vector3.new(0, 0, 0),Vector3.new(0.200000003, 0.200000003, 0.200000003))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Bright red","Part",Vector3.new(0.200000003, 0.400000036, 1.19999993))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.609359741, -0.788131714, -0.0999910831, 3.06354694e-018, -2.34616979e-014, -0.999999642, -0.999999642, -6.39629943e-005, -1.56279636e-018, -6.39629725e-005, 1, -2.34616895e-014))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=12891705",Vector3.new(0, 0, 0),Vector3.new(0.200000003, 0.200000003, 0.200000003))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Bright red","Part",Vector3.new(0.200000003, 0.400000036, 1.19999993))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.609375, 0.0116882324, -0.0999908447, 3.06355067e-018, -2.34617301e-014, -0.999999642, -0.999999642, -6.39631544e-005, -1.56279822e-018, -6.39631326e-005, 1, -2.34617217e-014))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=12891705",Vector3.new(0, 0, 0),Vector3.new(0.200000003, 0.200000003, 0.200000003))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Bright red","Part",Vector3.new(0.200000003, 0.400000036, 1.19999993))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.609313965, -0.388046265, -0.0999908447, 3.0635486e-018, -2.34617301e-014, -0.999998927, -0.999998927, -6.39631544e-005, -1.56279719e-018, -6.39630889e-005, 1, -2.34617047e-014))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=12891705",Vector3.new(0, 0, 0),Vector3.new(0.200000003, 0.200000003, 0.200000003))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Bright red","Part",Vector3.new(0.200000003, 0.400000036, 1.19999993))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.609329224, 0.411483765, -0.0999908447, 3.08028867e-018, -2.69585922e-014, -0.999998927, -0.999998927, -6.39334685e-005, -1.35696984e-018, -6.3933403e-005, 1, -2.69585617e-014))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=12891705",Vector3.new(0, 0, 0),Vector3.new(0.200000003, 0.200000003, 0.200000003))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.01999998, 0.200000003, 0.200000003))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.000305175781, -0.800010204, 0.89906311, -4.47035724e-008, 6.26018334e-015, 0.999997854, -8.34552054e-008, 1.00000012, -5.15634779e-015, -0.999997914, -5.35364961e-008, -4.47035653e-008))
mesh("SpecialMesh",Part,Enum.MeshType.Wedge,"",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.01999998, 0.600000024, 0.800000012))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.000228881836, -0.99998498, -0.199783325, -4.47038211e-008, -2.85946115e-012, -0.999997854, -6.3955762e-005, 1.00000012, 1.77753083e-015, 0.999997914, 6.39259815e-005, -4.47038175e-008))
mesh("SpecialMesh",Part,Enum.MeshType.Wedge,"",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Mid gray","Part",Vector3.new(0.400000006, 3.79999971, 0.200000003))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.356018066, -0.311279297, -0.609542847, 0.865768671, 0.500441432, 0, -0.5004403, 0.865770638, 3.55271241e-015, 3.55271241e-015, 3.02253882e-015, 0.999997854))
mesh("CylinderMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.01999998, 0.200000003, 0.200000003))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.000122070313, -0.799995899, 0.900177002, 1.49011559e-008, 0, -0.999995232, 0, 1, 0, 0.999995232, 0, 1.49011559e-008))
mesh("SpecialMesh",Part,Enum.MeshType.Wedge,"",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
FlagLogo=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","FlagLogo",Vector3.new(3, 1.99999988, 0.200000003))
FlagLogoweld=weld(m,VestHandle,FlagLogo,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(1.14234924, -3.41108704, -0.610244751, 0.865850091, 0.500302911, -3.55240239e-015, -0.500302792, 0.865850449, 9.79956736e-019, 3.07633938e-015, 1.77642947e-015, 0.999999642))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Mid gray","Part",Vector3.new(0.400000006, 0.200000003, 0.400000036))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.356628418, -2.31108093, -0.620269775, 0.865850091, 0.500302911, 7.10581953e-015, -0.500302792, 0.865850449, 9.79956736e-019, 6.15238443e-015, 3.55382075e-015, 0.999999642))
mesh("CylinderMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Mid gray","Part",Vector3.new(0.400000036, 0.200000003, 0.400000036))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.354736328, -4.51108551, -0.620117188, 0.865849495, 0.500302911, 1.77640292e-014, -0.500302434, 0.865850449, 9.79956115e-019, 9.22842142e-015, 5.33121097e-015, 0.999998927))
mesh("CylinderMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Mid gray","Part",Vector3.new(0.400000006, 1.99999964, 0.200000003))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.356216431, -3.41107178, -0.610137939, 0.865848899, 0.500302911, 1.77639292e-014, -0.500302076, 0.865850449, 9.79955495e-019, 1.53807173e-014, 8.88612016e-015, 0.999998212))
mesh("CylinderMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Mid gray","Part",Vector3.new(0.400000006, 0.200000003, 0.400000036))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.356292725, 1.6887207, -0.619628906, 0.865768075, 0.500441432, 0, -0.500439942, 0.865770638, 3.55270987e-015, 3.55270987e-015, 3.02253882e-015, 0.999997139))
mesh("CylinderMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Bright red","Part",Vector3.new(0.200000003, 0.400000036, 1.19999993))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.589828491, 0.808547974, -0.0999956131, -3.90798369e-014, 8.06646416e-017, -0.999997854, -0.999997914, -6.36497934e-005, 3.90798369e-014, -6.36795739e-005, 1.00000012, 3.58011901e-015))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=12891705",Vector3.new(0, 0, 0),Vector3.new(0.200000003, 0.200000003, 0.200000003))
Part=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"White","Part",Vector3.new(1, 0.76000005, 0.600000024))
Partweld=weld(m,VestHandle,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.509597778, -0.490081787, -0.399998188, -0.999999642, 0, 0, 0, 0, 0.999999642, 0, 1, 0))
mesh("SpecialMesh",Part,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=104516854",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
handle=part(Enum.FormFactor.Custom,m,Enum.Material.SmoothPlastic,0,0,"Really black","Handle",Vector3.new(0.200000003, 0.200000003, 1.4000001))
handleweld=weld(m,Character["Right Arm"],handle,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(3.05175781e-005, -1.10011411, -1.52587891e-005, 0.999999404, -4.47034765e-008, 0, -4.47034836e-008, -0.999999285, 0, 0, 0, -1))
mesh("SpecialMesh",handle,Enum.MeshType.FileMesh,"http://www.roblox.com/asset/?id=74322546",Vector3.new(0, 0, 0),Vector3.new(1.5, 1.5, 1.5))
local Decal1 = Instance.new("Decal",FlagLogo)
Decal1.Texture = "http://www.roblox.com/asset/?id=147337085"
Decal1.Face = "Front"
local Decal2 = Instance.new("Decal",FlagLogo)
Decal2.Texture = "http://www.roblox.com/asset/?id=147337085"
Decal2.Face = "Back"
Humanoid.WalkSpeed = 50
 
function ALLAHUAKBAR()
attack = true
local speak = {"ALLAHUAKBAR"}
local colors = {"Red","Red","Red"} -- The only 3 colors, adding more will error.
local chat = game:GetService("Chat")
chat:Chat(Head,speak[math.random(1,#speak)], colors[math.random(1,3)] )
for i = 0,1,0.05 do
swait()
RootJoint.C0 = clerp(RootJoint.C0,RootCF*cf(0,0,0)* angles(math.rad(0),math.rad(0),math.rad(50)),.3)
Torso.Neck.C0 = clerp(Torso.Neck.C0,necko *angles(math.rad(0),math.rad(0),math.rad(-50)),.3)
RW.C0 = clerp(RW.C0, CFrame.new(1.5, 0.5, 0) * angles(math.rad(90), math.rad(0), math.rad(50)), 0.3)
LW.C0 = clerp(LW.C0, CFrame.new(-1.5, 0.5, 0) * angles(math.rad(0), math.rad(0), math.rad(-20)), 0.3)
RH.C0=clerp(RH.C0,cf(1,-1,0)*angles(math.rad(0),math.rad(90),math.rad(0))*angles(math.rad(-5),math.rad(0),math.rad(0)),.3)
LH.C0=clerp(LH.C0,cf(-1,-1,0)*angles(math.rad(0),math.rad(-90),math.rad(0))*angles(math.rad(-5),math.rad(0),math.rad(0)),.3)
end
for i = 0,1,0.05 do
swait()
RootJoint.C0 = clerp(RootJoint.C0,RootCF*cf(0,0,0)* angles(math.rad(0),math.rad(0),math.rad(50)),.3)
Torso.Neck.C0 = clerp(Torso.Neck.C0,necko *angles(math.rad(0),math.rad(0),math.rad(-50)),.3)
RW.C0 = clerp(RW.C0, CFrame.new(1.5, 0.5, 0) * angles(math.rad(80), math.rad(0), math.rad(50)), 0.3)
LW.C0 = clerp(LW.C0, CFrame.new(-1.5, 0.5, 0) * angles(math.rad(0), math.rad(0), math.rad(-20)), 0.3)
RH.C0=clerp(RH.C0,cf(1,-1,0)*angles(math.rad(0),math.rad(90),math.rad(0))*angles(math.rad(-5),math.rad(0),math.rad(0)),.3)
LH.C0=clerp(LH.C0,cf(-1,-1,0)*angles(math.rad(0),math.rad(-90),math.rad(0))*angles(math.rad(-5),math.rad(0),math.rad(0)),.3)
end
for i = 1,20 do
--so("http://roblox.com/asset/?id=197815953",workspace,1,1)
so("rbxassetid://134854740",Torso,1,1.3)
so("rbxassetid://247893371",workspace,1,1)
so("rbxassetid://137994058",Torso,1,1)
so("rbxassetid://165969964",Torso,1,1)
game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('meme', '8', '1527622')
end
attack = false
end
 
mouse.Button1Down:connect(function()
ALLAHUAKBAR()
end)
 
mouse.KeyDown:connect(function(k)
        k=k:lower()
       
end)
 
 
local sine = 0
local change = 1
local val = 0
 
while true do
swait()
sine = sine + change
local torvel=(RootPart.Velocity*Vector3.new(1,0,1)).magnitude
local velderp=RootPart.Velocity.y
hitfloor,posfloor=rayCast(RootPart.Position,(CFrame.new(RootPart.Position,RootPart.Position - Vector3.new(0,1,0))).lookVector,4,Character)
if equipped==true or equipped==false then
if attack==false then
idle=idle+1
else
idle=0
end
if idle>=500 then
if attack==false then
--Sheath()
end
end
if RootPart.Velocity.y > 1 and hitfloor==nil then
Anim="Jump"
if attack==false then
RootJoint.C0 = clerp(RootJoint.C0,RootCF*cf(0,0,0)* angles(math.rad(0),math.rad(0),math.rad(0)),.3)
Torso.Neck.C0 = clerp(Torso.Neck.C0,necko *angles(math.rad(-20),math.rad(0),math.rad(0)),.3)
RW.C0 = clerp(RW.C0, CFrame.new(1.5, 0.5, 0) * angles(math.rad(20), math.rad(0), math.rad(10)), 0.3)
LW.C0 = clerp(LW.C0, CFrame.new(-1.5, 0.5, 0) * angles(math.rad(0), math.rad(0), math.rad(-10)), 0.3)
RH.C0=clerp(RH.C0,cf(1,-1,0)*angles(math.rad(0),math.rad(90),math.rad(0))*angles(math.rad(-2),math.rad(0),math.rad(0)),.3)
LH.C0=clerp(LH.C0,cf(-1,-1,0)*angles(math.rad(0),math.rad(-90),math.rad(0))*angles(math.rad(-2),math.rad(0),math.rad(0)),.3)
end
elseif RootPart.Velocity.y < -1 and hitfloor==nil then
Anim="Fall"
if attack==false then
RootJoint.C0 = clerp(RootJoint.C0,RootCF*cf(0,0,0)* angles(math.rad(20),math.rad(0),math.rad(0)),.3)
Torso.Neck.C0 = clerp(Torso.Neck.C0,necko *angles(math.rad(10),math.rad(0),math.rad(0)),.3)
RW.C0 = clerp(RW.C0, CFrame.new(1.5, 0.5, 0) * angles(math.rad(20), math.rad(0), math.rad(30)), 0.3)
LW.C0 = clerp(LW.C0, CFrame.new(-1.5, 0.5, 0) * angles(math.rad(0), math.rad(0), math.rad(-30)), 0.3)
RH.C0=clerp(RH.C0,cf(1,-1,0)*angles(math.rad(0),math.rad(90),math.rad(0))*angles(math.rad(-10),math.rad(0),math.rad(0)),.3)
LH.C0=clerp(LH.C0,cf(-1,-1,0)*angles(math.rad(0),math.rad(-90),math.rad(0))*angles(math.rad(-10),math.rad(0),math.rad(0)),.3)
end
elseif torvel<1 and hitfloor~=nil then
Anim="Idle"
if attack==false then
RootJoint.C0 = clerp(RootJoint.C0,RootCF*cf(0,0,0)* angles(math.rad(0),math.rad(0),math.rad(10)),.3)
Torso.Neck.C0 = clerp(Torso.Neck.C0,necko *angles(math.rad(0),math.rad(0),math.rad(-10)),.3)
RW.C0 = clerp(RW.C0, CFrame.new(1.5, 0.5, 0) * angles(math.rad(20), math.rad(0), math.rad(20)), 0.3)
LW.C0 = clerp(LW.C0, CFrame.new(-1.5, 0.5, 0) * angles(math.rad(0), math.rad(0), math.rad(-20)), 0.3)
RH.C0=clerp(RH.C0,cf(1,-1,0)*angles(math.rad(0),math.rad(90),math.rad(0))*angles(math.rad(-5),math.rad(0),math.rad(0)),.3)
LH.C0=clerp(LH.C0,cf(-1,-1,0)*angles(math.rad(0),math.rad(-90),math.rad(0))*angles(math.rad(-5),math.rad(0),math.rad(0)),.3)
end
elseif torvel>2 and hitfloor~=nil then
Anim="Walk"
if attack==false then
change=3
RootJoint.C0 = clerp(RootJoint.C0,RootCF*cf(0,0,0)* angles(math.rad(20),math.rad(0),math.rad(0)),.3)
Torso.Neck.C0 = clerp(Torso.Neck.C0,necko *angles(math.rad(-20),math.rad(0),math.rad(0)),.3)
RW.C0 = clerp(RW.C0, CFrame.new(1.5, 0.5, 0) * angles(math.rad(50*math.cos(sine/20)), math.rad(0), math.rad(10)), 0.3)
LW.C0 = clerp(LW.C0, CFrame.new(-1.5, 0.5, 0) * angles(math.rad(-50*math.cos(sine/20)), math.rad(0), math.rad(-10)), 0.3)
RH.C0=clerp(RH.C0,cf(1,-1,0)*angles(math.rad(0),math.rad(90),math.rad(0))*angles(math.rad(0),math.rad(0),math.rad(0)),.3)
LH.C0=clerp(LH.C0,cf(-1,-1,0)*angles(math.rad(0),math.rad(-90),math.rad(0))*angles(math.rad(0),math.rad(0),math.rad(0)),.3)
end
end
end
if #Effects>0 then
--table.insert(Effects,{prt,"Block1",delay})
for e=1,#Effects do
if Effects[e]~=nil then
--for j=1,#Effects[e] do
local Thing=Effects[e]
if Thing~=nil then
local Part=Thing[1]
local Mode=Thing[2]
local Delay=Thing[3]
local IncX=Thing[4]
local IncY=Thing[5]
local IncZ=Thing[6]
if Thing[1].Transparency<=1 then
if Thing[2]=="Block1" then
Thing[1].CFrame=Thing[1].CFrame*euler(math.random(-50,50),math.random(-50,50),math.random(-50,50))
Mesh=Thing[1].Mesh
Mesh.Scale=Mesh.Scale+vt(Thing[4],Thing[5],Thing[6])
Thing[1].Transparency=Thing[1].Transparency+Thing[3]
elseif Thing[2]=="Cylinder" then
Mesh=Thing[1].Mesh
Mesh.Scale=Mesh.Scale+vt(Thing[4],Thing[5],Thing[6])
Thing[1].Transparency=Thing[1].Transparency+Thing[3]
elseif Thing[2]=="Blood" then
Mesh=Thing[7]
Thing[1].CFrame=Thing[1].CFrame*cf(0,.5,0)
Mesh.Scale=Mesh.Scale+vt(Thing[4],Thing[5],Thing[6])
Thing[1].Transparency=Thing[1].Transparency+Thing[3]
elseif Thing[2]=="Elec" then
Mesh=Thing[1].Mesh
Mesh.Scale=Mesh.Scale+vt(Thing[7],Thing[8],Thing[9])
Thing[1].Transparency=Thing[1].Transparency+Thing[3]
elseif Thing[2]=="Disappear" then
Thing[1].Transparency=Thing[1].Transparency+Thing[3]
end
else
Part.Parent=nil
table.remove(Effects,e)
end
end
--end
end
end
end
end
end)

spamarrest.Name = "spamarrest"
spamarrest.Parent = Scripts
spamarrest.BackgroundColor3 = Color3.new(0, 0, 0)
spamarrest.BackgroundTransparency = 0.5
spamarrest.Position = UDim2.new(0, 0, 0, 957)
spamarrest.Size = UDim2.new(0, 200, 0, 50)
spamarrest.Font = Enum.Font.SourceSans
spamarrest.FontSize = Enum.FontSize.Size14
spamarrest.Text = "JailBreak Spam Arrest"
spamarrest.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
spamarrest.TextSize = 14
spamarrest.MouseButton1Down:connect(function()
	local Player = game.Players.LocalPlayer
	wait(0.5)
	for i,v in pairs(game.Teams.Criminal:GetPlayers()) do
		repeat
			wait()
			Player.Character.HumanoidRootPart.CFrame = v.Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, 1)
		until v.Team.Name ~= "Criminal"
	end
end)

killaura.Name = "killaura"
killaura.Parent = Scripts
killaura.BackgroundColor3 = Color3.new(0, 0, 0)
killaura.BackgroundTransparency = 0.5
killaura.Position = UDim2.new(0, 0, 0, 1007)
killaura.Size = UDim2.new(0, 200, 0, 50)
killaura.Font = Enum.Font.SourceSans
killaura.FontSize = Enum.FontSize.Size14
killaura.Text = "Prison Life Killaura"
killaura.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
killaura.TextSize = 14
killaura.MouseButton1Down:connect(function()
while wait(0.1) do
  for i, plr in pairs(game.Players:GetChildren()) do
  if plr.Name ~= game.Players.LocalPlayer.Name then
  for i = 1, 10 do
  game.ReplicatedStorage.meleeEvent:FireServer(plr)
  end
  end
  end
  end
end)

tpgunsmelees.Name = "tpgunsmelees"
tpgunsmelees.Parent = Scripts
tpgunsmelees.BackgroundColor3 = Color3.new(0, 0, 0)
tpgunsmelees.BackgroundTransparency = 0.5
tpgunsmelees.Position = UDim2.new(0, 0, 0, 1057)
tpgunsmelees.Size = UDim2.new(0, 200, 0, 50)
tpgunsmelees.Font = Enum.Font.SourceSans
tpgunsmelees.FontSize = Enum.FontSize.Size14
tpgunsmelees.Text = "Prison Life TP Guns/Melees"
tpgunsmelees.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
tpgunsmelees.TextSize = 14
tpgunsmelees.MouseButton1Down:connect(function()
local weapons = {"Remington 870", "M9", "AK-47", "M4A1", "Riot Shield"}
  for i, v in pairs(game.Workspace["Prison_ITEMS"].giver:GetChildren()) do
  for j, k in pairs(weapons) do
  if v.Name == k then
  v:MoveTo(game.Players.LocalPlayer.Character.Torso.Position)
  end
  end
  end
wait( )
local weapons = {"Crude Knife", "Sharpened stick", "Extendo mirror"}
  for i, v in pairs(game.ReplicatedStorage.Tools:GetChildren()) do
  for j, k in pairs(weapons) do
  if v.Name == k then
  v:Clone().Parent = game.Players.LocalPlayer.Backpack
  end
  end
  end
end)

tpto.Name = "tpto"
tpto.Parent = Scripts
tpto.BackgroundColor3 = Color3.new(0, 0, 0)
tpto.BackgroundTransparency = 0.5
tpto.Position = UDim2.new(0, 0, 0, 1107)
tpto.Size = UDim2.new(0, 200, 0, 50)
tpto.Font = Enum.Font.SourceSans
tpto.FontSize = Enum.FontSize.Size14
tpto.Text = "TP To"
tpto.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
tpto.TextSize = 14
tpto.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton = "Teleport"
end)

bring.Name = "bring"
bring.Parent = Scripts
bring.BackgroundColor3 = Color3.new(0, 0, 0)
bring.BackgroundTransparency = 0.5
bring.Position = UDim2.new(0, 0, 0, 1157)
bring.Size = UDim2.new(0, 200, 0, 50)
bring.Font = Enum.Font.SourceSans
bring.FontSize = Enum.FontSize.Size14
bring.Text = "Bring (Tools needed)"
bring.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
bring.TextSize = 14
bring.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton.Text = "Bring"
end)

torturebaby.Name = "torturebaby"
torturebaby.Parent = Scripts
torturebaby.BackgroundColor3 = Color3.new(0, 0, 0)
torturebaby.BackgroundTransparency = 0.5
torturebaby.Position = UDim2.new(0, 0, 0, 1207)
torturebaby.Size = UDim2.new(0, 200, 0, 50)
torturebaby.Font = Enum.Font.SourceSans
torturebaby.FontSize = Enum.FontSize.Size14
torturebaby.Text = "Adopt Me Torture Baby"
torturebaby.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
torturebaby.TextSize = 14
torturebaby.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton.Text = "Torture"
end)

explode.Name = "explode"
explode.Parent = Scripts
explode.BackgroundColor3 = Color3.new(0, 0, 0)
explode.BackgroundTransparency = 0.5
explode.Position = UDim2.new(0, 0, 0, 1257)
explode.Size = UDim2.new(0, 200, 0, 50)
explode.Font = Enum.Font.SourceSans
explode.FontSize = Enum.FontSize.Size14
explode.Text = "Explode (takes sum time)"
explode.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
explode.TextSize = 14
explode.MouseButton1Down:connect(function()
if game.PlaceId == "192800" then
game.ReplicatedStorage.Channels.PlayerChannel:FireServer("LoadAvatarAsset", 1527622)
end

if game.PlaceId == "367959224" then
game.ReplicatedStorage.ClothingService:FireServer("Hat", 001527622)
end

if game.PlaceId == "92604236" then
game.ReplicatedStorage.Events.OutfitChang:FireServer("Hat", "1527622")
end

if game.PlaceId == "597114278" then
game.ReplicatedStorage.UpdateClothes:FireServer({[1]= "Outfit1", [2]= "1527622", [3]= "1527622", [4]= "none", [5]= "none", [6]= "none", [7]= "none"})
game.ReplicatedStorage.Clothes:FireServer({[1]= "1527622", [2]= "1527622", [3]= "1527622", [4]= "none", [5]= "none", [6]= "none"})
end
end)

frspam.Name = "frspam"
frspam.Parent = Scripts
frspam.BackgroundColor3 = Color3.new(0, 0, 0)
frspam.BackgroundTransparency = 0.5
frspam.Position = UDim2.new(0, 0, 0, 1307)
frspam.Size = UDim2.new(0, 200, 0, 50)
frspam.Font = Enum.Font.SourceSans
frspam.FontSize = Enum.FontSize.Size14
frspam.Text = "Friend Request Spam"
frspam.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
frspam.TextSize = 14
frspam.MouseButton1Down:connect(function()
local obese = game:GetService('Players')
for _,kachow in pairs(obese:GetPlayers()) do
obese.LocalPlayer:RequestFriendship(kachow, kachow)
end
end)

isis.Name = "isis"
isis.Parent = Scripts
isis.BackgroundColor3 = Color3.new(0, 0, 0)
isis.BackgroundTransparency = 0.5
isis.Position = UDim2.new(0, 0, 0, 1357)
isis.Size = UDim2.new(0, 200, 0, 50)
isis.Font = Enum.Font.SourceSans
isis.FontSize = Enum.FontSize.Size14
isis.Text = "ISIS Soldier (City Life)"
isis.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
isis.TextSize = 14
isis.MouseButton1Down:connect(function()
--not sure why i added this one since its leaked 2934823948 times















assets = {540034631, 178993946, 461493477, 110288809}
me = game:GetService'Players'.LocalPlayer.Character:FindFirstChildOfClass'Humanoid'
for i,v in pairs(me.Parent:GetChildren()) do
if v:IsA'Accoutrement' then v.Parent = nil end
end
for i,v in pairs(assets) do
  game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('xdd', tostring(game:GetService'MarketplaceService':GetProductInfo(v).AssetTypeId), v)
end
me.WalkSpeed = 50 --same
mouse = game:GetService'Players'.LocalPlayer:GetMouse()
exploded = false
boom = mouse.Button1Down:connect(function()
if exploded == true then return end
exploded = true
game:GetService'ReplicatedStorage'.ITEM_PURCHASE:InvokeServer('boom', '8', '1527622')
print'exploding!!!'
exploded = true
boom:Disconnect()
end)
end)

botesp.Name = "botesp"
botesp.Parent = Scripts
botesp.BackgroundColor3 = Color3.new(0, 0, 0)
botesp.BackgroundTransparency = 0.5
botesp.Position = UDim2.new(0, 0, 0, 1407)
botesp.Size = UDim2.new(0, 200, 0, 50)
botesp.Font = Enum.Font.SourceSans
botesp.FontSize = Enum.FontSize.Size14
botesp.Text = "Aimbot/ESP"
botesp.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
botesp.TextSize = 14
botesp.MouseButton1Down:connect(function()
-- @Lilith.lua
-- author: lenny
local f_print, printing = print, true
local function print ( ... )
	if printing then
		f_print("[Lilith] - ", ...)
	end
end
print "Version 1.4b, official release;"
print "Aimbot will not work in every game, such as Phantom Forces."

-- configuration:
local settings = {	
	-- hotkeys:
	commandbar_Hotkey = "Minus",
	esp_Hotkey = "RightAlt",
	aimbot_Hotkey = "RightControl";
	
	-- defaults:
	esp_boxColor = "Bright red",
	esp_boxTransparent = true,
	esp_useTeamColorIfApplicable = true,
	esp_showDistance = true,
	esp_holdHotkey = false,
	esp_showCharacterEspd = true,
	aimbot_clickToLock = true,
	aimbot_clickToLockDistanceOverride = true,
	aimbot_maxDistance = 250,
	aimbot_aimFor = "Head";
	
	-- ignores:
	esp_ignoreTeam = true,
	esp_dont_ignoreSelf = false,
	aimbot_ignoreWalls = false,
	aimbot_ignoreTeam = false;
}

-- mainscript:
local Players = game:GetService("Players")
local Teams = game:GetService("Teams")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local localPlayer = Players.LocalPlayer
local Mouse = localPlayer:GetMouse()
local CoreGui = game:GetService("CoreGui")

local function findFirstChild (obj, name, sensitive)
	local children = obj:GetChildren()
	for i = 1, #children do
		local objN = children[i].Name
		if not sensitive then
			objN, name = objN:lower(), name:lower()
		end
		if objN:sub(1, name:len()) == name then
			return children[i]
		end
	end	
end
local function setHotkey (section, keyName)
	if Enum.KeyCode[keyName] then
		settings[section .. '_Hotkey'] = Enum.KeyCode[keyName]
		print ("Sucessfully set " .. section .. "'s hotkey to " .. keyName)
	end
end setHotkey("esp", settings.esp_Hotkey); setHotkey("aimbot", settings.aimbot_Hotkey); setHotkey("commandbar", settings.commandbar_Hotkey)
local function splitString (str, delimeter)	
	local strParts = {}
	local pattern = ("([^%s]+)"):format(delimeter)
	
	str:gsub(pattern, function(section)
		strParts[#strParts + 1] = section
	end)
	return strParts	
end
local function isHumanoidAlive (character)
	if character then
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if humanoid and humanoid.Health > 0 then 
			return character, humanoid
		end
	end
end
local function getCharacterFromPart (obj) -- made this in haste, so its unorganized!
	while (obj ~= game and obj ~= workspace) and (obj.Parent and not Players:GetPlayerFromCharacter(obj.Parent)) do
		obj = obj.Parent
	end
	return obj	
end
local function viewNotObstructed (lookingAt, parent)
	local character, _ = isHumanoidAlive(localPlayer.Character)
	if character then
		local headPos = character.Head.CFrame.p
		local viewRay = Ray.new(headPos, (lookingAt.CFrame.p - headPos).unit * 
			settings.aimbot_maxDistance)
		local object = workspace:FindPartOnRay(viewRay, character, true, true)
		if object then
			return object:IsDescendantOf(parent)
		end
	end
end
local function setColor (color)
	return select(2, pcall(function()
		if typeof(color) == "BrickColor" then
			color = color.Color
		elseif typeof(color) == "string" then
			color = BrickColor.new(color).Color
		end
		return color
	end))	
end

-- @create objects
local ESPOBJF do
	ESPOBJF = findFirstChild(CoreGui, "ESPOBJF")
	if not ESPOBJF then
		ESPOBJF = Instance.new("Folder", CoreGui)
		ESPOBJF.Name = "ESPOBJF"
	end
end
local Box, espText, aimbotText
local commandBar do	
	commandBar = Instance.new("ScreenGui")
	commandBar.Name = "%$#@$!&"
	
	local frame = Instance.new("Frame", commandBar)
	frame.BackgroundTransparency = 1; frame.Size, frame.Position = UDim2.new(0.221, 0,0.111, 0), UDim2.new(0.407, 0,0.644, 0); frame.Draggable = true; frame.Active = true
	
	local textlabel = Instance.new("TextLabel", frame)
	textlabel.BackgroundTransparency = 1; textlabel.TextSize = 16; textlabel.TextColor3 = Color3.fromRGB(255, 255, 255); textlabel.Font = Enum.Font.SourceSansLight; textlabel.Position, textlabel.Size = UDim2.new(0.132, 0,0.1, 0), UDim2.new(0.75, 0, 0.201, 0); textlabel.ZIndex = 1; textlabel.Text = "[Lilith]"
	
	Box = Instance.new("TextBox", frame)
	Box.BackgroundColor3 = Color3.fromRGB(58, 58, 58); Box.BackgroundTransparency = 0.5; Box.BorderSizePixel = 0; Box.TextSize = 16; Box.TextColor3 = Color3.fromRGB(255, 255, 255); Box.Font = Enum.Font.SourceSansItalic; Box.ClipsDescendants = true; Box.ZIndex = 1; Box.Text = "press to `-` to type"; Box.Size, Box.Position = UDim2.new(0.922, 0,0.402, 0), UDim2.new(0.026, 0,0.402, 0) ; Box.TextTransparency = 0.5	

	aimbotText = textlabel:Clone()
	aimbotText.Size, aimbotText.Position =UDim2.new(0.079, 0,0.201, 0), UDim2.new(0.74, 0,0.1, 0); aimbotText.TextColor3, aimbotText.Font = Color3.fromRGB(48, 48, 48), Enum.Font.SourceSansBold; aimbotText.Text = "bot"; aimbotText.Parent = frame
	
	espText = textlabel:Clone()
	espText.Size, espText.Position =UDim2.new(0.079, 0,0.201, 0), UDim2.new(0.184, 0,0.1, 0); espText.TextColor3, espText.Font = Color3.fromRGB(48, 48, 48), Enum.Font.SourceSansBold; espText.Text = "esp"; espText.Parent = frame
end
local active_espObjects = {}
local function clear_active_espObjects (ofParent)
	if not ofParent then
		ESPOBJF:ClearAllChildren()
		local a = 1
		while active_espObjects[a] do
			if active_espObjects[a] then
				active_espObjects[a]:Destroy()
			end
			active_espObjects[a] = nil
			a = a + 1
		end
	else
		local j = 1
		while active_espObjects[j] do
			local espObj = active_espObjects[j]
			if espObj and espObj:IsDescendantOf(ofParent) or ((espObj:IsA("BoxHandleAdornment") or espObj:IsA("BillboardGui")) and espObj.Adornee and espObj.Adornee:IsDescendantOf(ofParent)) then
				espObj:Destroy()
				espObj = nil
			end
			j = j + 1
		end
	end
end
local function createEspBoxOnObj (obj, color)	
	local espBox do
		espBox = Instance.new("BoxHandleAdornment")
		espBox.AlwaysOnTop = true
		espBox.ZIndex = 10
		espBox.Color3 = BrickColor.new(settings.esp_boxColor).Color
	end

	local color = setColor(color)
	if color then
		espBox.Color3 = color
	end
	
	if settings.esp_boxTransparent then
		espBox.Transparency = 0.8
	end
	
	espBox.Size = obj.Size
	espBox.Adornee = obj
	espBox.Parent = ESPOBJF
	active_espObjects[#active_espObjects + 1] = espBox
	
	return espBox	
end
local function getDistanceFrom (object)
	if localPlayer.Character and localPlayer.Character.Head then
		return math.floor((object.Position - localPlayer.Character.Head.Position).magnitude)
	else
		return "err"
	end
end
local function createDistTagOnCharacter (character, removeTag, color)
	local _, humanoid = isHumanoidAlive(character) 
	if humanoid then	
		humanoid.Died:Connect(function()
			clear_active_espObjects(character)
		end)
		local head = character:FindFirstChild("Head")	
		if head then
			if ESPOBJF:findFirstChild(character.Name) then
				ESPOBJF[character.Name]:Destroy()
				if removeTag then
					return
				end
			end
			
			local textLabel
			local distTag do
				distTag = Instance.new("BillboardGui")
				distTag.AlwaysOnTop = true
				distTag.Enabled = true
				distTag.Size = UDim2.new(0, 10,0, 50)
				
				textLabel = Instance.new("TextLabel", distTag)
				textLabel.Size = UDim2.new(0, 75,0, 25)
				textLabel.BackgroundColor3 = (color ~= nil and color) or Color3.fromRGB(48, 48, 48)  
				textLabel.BackgroundTransparency = 0.5
				textLabel.Font = Enum.Font.SourceSansBold
				textLabel.TextSize = 18
				textLabel.TextColor3 = Color3.fromRGB(255, 255 ,255)
				textLabel.ClipsDescendants = true
				textLabel.BorderSizePixel = 0	
			end
			distTag.Adornee = head
			distTag.Parent = ESPOBJF
			distTag.Name = character.Name
			textLabel.Text = character.Name
			active_espObjects[#active_espObjects + 1] = distTag

			coroutine.resume(coroutine.create(function()
				local now = tick()
				while isHumanoidAlive(character) and distTag do
					local t = tick() - now
					if t < 5 then
						if textLabel.Text ~= character.Name then
							textLabel.Text = character.Name 
						end
					elseif t < 10 and t > 5 then
						textLabel.Text = getDistanceFrom(head)
					elseif t > 10 then
						now = tick()
					end						
					wait()
				end
			end))
			return distTag	
		end
	end
end
 
-- @esp component
local function esp_getPlayers ()	
	local players = {}
	for _, player in next, Players:GetPlayers() do
		if (not settings.esp_ignoreTeam and player.Team ~= localPlayer.Team) or settings.esp_ignoreTeam then
			if settings.esp_dont_ignoreSelf or player ~= localPlayer then
				players[#players + 1] = player
			end
		end
	end
	return players
end
function espCharacter (character, color, override)
	local alreadyESPdTag = character:FindFirstChild("AESPT")
	if alreadyESPdTag then
		if override then
			clear_active_espObjects(character)
		else
			return
		end
	end		
	
	local _, humanoid = isHumanoidAlive(character)
	if humanoid then
		
		humanoid.Died:Connect(function()
			clear_active_espObjects(character)
		end)
		for _, part in next, character:GetChildren() do
			if part:IsA("BasePart") then
				createEspBoxOnObj(part, color)
			end
		end
		
		alreadyESPdTag = Instance.new("BoolValue", character)
		alreadyESPdTag.Name = "AESPT"
		active_espObjects[#active_espObjects + 1] = alreadyESPdTag
	end	
end
local espEnabled = false
local esp_Cache = {}
function clear_esp_Cache ()
	local a = 1
	while esp_Cache[a] do
		esp_Cache[a]:Disconnect()
		esp_Cache[a] = nil
		a = a + 1
	end
	esp_Cache = {}
end
local function handle_Esp (character)

	local timeout = tick()
	if not isHumanoidAlive(character) then 
		repeat wait() until isHumanoidAlive(character) or (tick() - timeout) >= 2
		if not isHumanoidAlive(character) then return end
	end
	
	local teamColor = Players:GetPlayerFromCharacter(character).TeamColor
	local color = (settings.esp_useTeamColorIfApplicable and teamColor) or settings.esp_boxColor
	color = setColor(color)
	if settings.esp_showCharacterEspd then
		espCharacter(character, color)
	end	
	if settings.esp_showDistance then
		createDistTagOnCharacter(character, false, color)
	end
	
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	humanoid.Died:Connect(function()
		clear_active_espObjects(character)
	end)
	
end
local function toggle_Esp (turnOff)
	if turnOff then
		clear_esp_Cache()
		clear_active_espObjects()
		espEnabled = false
		espText.TextColor3 = Color3.fromRGB(48, 48, 48)
		print "ESP successfully disabled"
		return	
	elseif not turnOff and not espEnabled then
		print "Attempting to enabled ESP .."
		clear_esp_Cache()
		clear_active_espObjects()
		local players = esp_getPlayers()
		for _, player in next, players do
			local rbxScriptSignal = player.CharacterAdded:Connect(function(character)
				if (not espEnabled and rbxScriptSignal) then rbxScriptSignal:Disconnect(); rbxScriptSignal = nil return end
				handle_Esp(character)
			end); esp_Cache[#esp_Cache + 1] = rbxScriptSignal
			if player.Character and isHumanoidAlive(player.Character) then
				handle_Esp(player.Character)
			end	
		end
		espText.TextColor3 = Color3.fromRGB(0, 255, 0)
		print "ESP successfully enabled"
	end		
end

-- @aimbot component
local targetPlayer, targetTeam, currentLock
local function clickToTarget (target, override_maxDistance)
	if target and (override_maxDistance or (not override_maxDistance and getDistanceFrom(target) <= settings.aimbot_maxDistance)) then
		if target.Parent and isHumanoidAlive(target.Parent) then
			targetPlayer = game.Players:GetPlayerFromCharacter(target.Parent)
			return true
		end
	end
end
local function getClosestCharacter ()
	if isHumanoidAlive(localPlayer.Character) then
		local closestDist, chrctr
		if targetPlayer then
			chrctr, _ = isHumanoidAlive(targetPlayer.Character)
			if not chrctr then
				chrctr = targetPlayer.CharacterAdded:wait()
			end
		else
			local players = (targetTeam and targetTeam:GetPlayers()) or Players:GetPlayers()
			for i = 1, #players do
				if players[i] ~= localPlayer and (targetTeam or settings.aimbot_ignoreTeam or (not settings.aimbot_ignoreTeam and players[i].Team ~= localPlayer.Team)) then
					local player = players[i]
					if isHumanoidAlive(player.Character) then
						local bodyPart = player.Character:FindFirstChild(settings.aimbot_aimFor)
						if bodyPart then
							local distanceBetween = getDistanceFrom(bodyPart)
							if distanceBetween <= settings.aimbot_maxDistance and (not closestDist or distanceBetween < closestDist) then
								if (settings.aimbot_ignoreWalls or (not settings.aimbot_ignoreWalls and viewNotObstructed(bodyPart, player.Character))) then
									closestDist = distanceBetween
									chrctr = player.character
								end
							end
						end
					end
				end
			end
		end		
		return chrctr
	end
end
local function targetCamera ()
	if isHumanoidAlive(localPlayer.Character) then
		local head = localPlayer.Character.Head
		local camera = workspace.CurrentCamera
		local character = (targetPlayer and isHumanoidAlive(targetPlayer.Character) and targetPlayer.Character) or getClosestCharacter()
		if character and character:FindFirstChild(settings.aimbot_aimFor) then
			currentLock = Players:GetPlayerFromCharacter(character)
			camera.CFrame = CFrame.new(camera.CFrame.p, character[settings.aimbot_aimFor].CFrame.p)
		end
	end	
end
aimbotEnabled = false
local function toggle_Aimbot ()
	aimbotEnabled = not aimbotEnabled
	print ("Aimbot successfully " .. ((aimbotEnabled and "enabled") or "disabled"))
	aimbotText.TextColor3 = (aimbotEnabled and Color3.fromRGB(0, 255, 0)) or Color3.fromRGB(48, 48, 48)
end

-- @commandbar component
local function isSetting (settingName)
	for k in next, settings do
		if k:lower() == settingName:lower() then
			return k
		end
	end
	return nil
end
local function changeSetting (settingName, newValue, notBoolean)
	if typeof(newValue) == "string" and not notBoolean then
		if (newValue:lower() == "enable" or newValue:lower() == "true") then newValue = true
	elseif (newValue:lower() == "disable" or newValue:lower() == "false") then newValue = false end
	end
	local k = isSetting(settingName)
	if k then
		settings[k] = newValue
		print("changed", k, newValue)
	end
end
function execute_Command (contents)
	local section = contents[1]:lower()
	local command = contents[2] and contents[2]:lower()
	
	if (section == "enable" or section == "on") or (section == "disable" or section == "off")	then
		if command == "aimbot" then	
			aimbotEnabled = (section == "enable" or section == "on")
	print ("Aimbot successfully " .. ((aimbotEnabled and "enabled") or "disabled"))
		aimbotText.TextColor3 = (aimbotEnabled and Color3.fromRGB(0, 255, 0)) or Color3.fromRGB(48, 48, 48)
		elseif command == "esp" then
			toggle_Esp((section == "disable" or section == "off") and true)
			espEnabled = (section == "enable" or section == "on")
		end
		
	--
	
	elseif section == "esp" then
		if (command == "enable" or command == "on") or (command == "disable" or command == "off") then	
			toggle_Esp((command == "disable" or command == "off") and true)
			espEnabled = (command == "enable" or command == "on")
		elseif command == "find" or command == "hide" or command:find("dist") then
			local plyr = findFirstChild(Players, contents[3]:lower())	
			local color = (#contents > 4 and table.concat(contents, " ", 4)) or contents[4]
			if color == "" or color == " " then
				color = nil
			end
			if plyr then
				if command == "showdist" or command == "hidedist" then
					createDistTagOnCharacter(plyr.Character, command == "hidedist", color)
					return
				else
						if command == "find" then
						espCharacter(plyr.Character, color, true)
						espEnabled = true
						espText.TextColor3 = Color3.fromRGB(0, 255, 0)
					elseif command == "hide" then
						clear_active_espObjects(plyr.Character)
					end
				end
			end					
		elseif command == "boxcolor" then
			local color = (#contents > 3 and table.concat(contents, " ", 3)) or contents[3]
			if color ~= " " and color ~= "" then
				changeSetting("esp_boxColor", color)
				toggle_Esp(true); toggle_Esp()
				print "Esp reset due to setting change."
			end
		elseif command == "ignoreteam" or command == "dontignoreself" or command == "showdistance" or command == "showcharacterespd" or command == "holdhotkey" or command == "useteamcolorifapplicable" or command == "boxtransparent" then
			
			local value = contents[3]:lower()
			if command ~= "holdhotkey" then
				if command == "ignoreteam" then
					changeSetting("esp_ignoreTeam", value)
				elseif command == "dontignoreself" then
					changeSetting("esp_dont_ignoreSelf", value)
				elseif command == "showdistance" then
					changeSetting("esp_showDistance", value)
				elseif command == "boxtransparent" then
					changeSetting("esp_boxTransparent", value)
				elseif command == "showcharacterespd" then
					changeSetting("esp_showCharacterEspd", value)
				elseif command == "useteamcolorifapplicable" then
					changeSetting("esp_useTeamColorIfApplicable", value)
				end
				toggle_Esp(true); toggle_Esp()
				print "Esp reset due to setting change."
			else
				changeSetting("esp_holdHotkey", value)
				if settings.esp_holdHotkey then
					print "Esp must now be activated by holding the hotkey."
				else
					print "Esp must now be toggled by pressing the hotkey."
				end
				toggle_Esp(true)
				print "Esp turned off due to activation change."
			end			
		elseif command == "hotkey" or command == "sethotkey" then
			setHotkey("esp", contents[3])
			toggle_Esp(true)
			print "Esp turned off due to activation change."
		end
	
	--
	
	elseif section == "aimbot" then
		if (command == "enable" or command == "on") or (command == "disable" or command == "off") then	
			aimbotEnabled = (command == "enable" or command == "on")
			aimbotText.TextColor3 = (aimbotEnabled and Color3.fromRGB(0, 255, 0)) or Color3.fromRGB(48, 48, 48)
			print ("Aimbot successfully " .. ((aimbotEnabled and "enabled") or "disabled"))
		elseif command == "target" then
			local content3 = contents[3]:lower()
			local plyr = findFirstChild(Players, content3)
			if not plyr then
				if content3 == "team" then
					local content4 = (#contents > 4 and table.concat(contents, " ", 4)) or contents[4]
					local team = findFirstChild(Teams, content4)
					if not team and (content4 == "disable" or content4 == "__disable") then
						targetTeam = nil
						aimbotEnabled = false
						aimbotText.TextColor3 = Color3.fromRGB(48, 48, 48)
						print "Aimbot disabled; target team removed."
					else
						targetTeam = team 
						if aimbotEnabled then
							aimbotEnabled = false
						end
						aimbotEnabled = true
						aimbotText.TextColor3 = Color3.fromRGB(0, 255, 0)
						print "Aimbot enabled; target team set."
					end
				elseif content3 == "disable" or content3 == "__disable" then
					targetPlayer = nil
					aimbotEnabled = false
					aimbotText.TextColor3 = Color3.fromRGB(48, 48, 48)
					print "Aimbot disabled; target player removed."
				end
			else
				targetPlayer = plyr
				if aimbotEnabled then
					aimbotEnabled = false
				end
				aimbotEnabled = true
				aimbotText.TextColor3 = Color3.fromRGB(0, 255, 0)
				print "Aimbot target enabled; player set."
			end
		else
			if command == "maxdistance" then
				local number = tonumber(contents[3])
				if number then
					changeSetting("aimbot_maxDistance", number)
				end
				
			elseif (command == "ignorewalls" or command == "ignoreteam" or command == "aimfor" or command == "clicktolock" or command == "clicktolockdistanceoverride") then
				local value = contents[3]
				if command == "ignorewalls" then
					changeSetting("aimbot_ignoreWalls", value)
				elseif command == "ignoreteam" then
					changeSetting("aimbot_ignoreTeam", value)
				elseif command == "clicktolock" then
					changeSetting("aimbot_clickToLock", value)
				elseif command == "clicktolockdistanceoverride" then
					changeSetting("aimbot_clickToLockDistanceOverride", value)
				elseif command == "aimfor" then
					changeSetting("aimbot_aimFor", (#contents > 3 and table.concat(contents, " ", 3) or contents[3]), true)
				end
				aimbotEnabled = false; aimbotEnabled = "true"
				aimbotText.TextColor3 = Color3.fromRGB(0, 255, 0)
				print "Aimbot reset due to setting change."
		
			elseif command == "hotkey" or command == "sethotkey" then
				setHotkey("aimbot", contents[3])
				aimbotEnabled = false
				aimbotText.TextColor3 = Color3.fromRGB(48, 48, 48)
				print "Aimbot turned off due to activation change."
			end		
		end
	

	-- @some flexiblity
	elseif section == "target" then
		execute_Command({"aimbot", "target", contents[2], contents[3]})
	elseif (section == "find" or section == "hide" or section:find("dist")) then
		execute_Command({"esp", section, contents[2], (#contents > 3 and table.concat(contents, " ", 3) or contents[3])})
	
	
	-- @basic fix
	elseif section == "resetcache" then
		clear_active_espObjects()
	elseif section == "terminate" then
		ESP_RBXScriptSignal:Disconnect()
		ESP_RBXScriptSignal = nil
		AIMBOT_RbxScriptSignal:Disconnect()
		AIMBOT_RbxScriptSignal = nil
		KEYS_RbxScriptSignal:Disconnect()
		KEYS_RbxScriptSignal = nil
		
		clear_esp_Cache()
		clear_active_espObjects()
		ESPOBJF:Destroy()
		commandBar:Destroy()
	
	end		
end
local function on_FocusLost (enterPressed)
	local content = Box.Text
	Box.Text = "press `-` to type"
	Box.Font = Enum.Font.SourceSansItalic
	Box.TextTransparency = 0.5
	if enterPressed then
		if content ~= " " or content ~= "" then
			execute_Command(splitString(content, " "))
		end
	end	
end

-- @endscript
ESP_RBXScriptSignal = RunService.RenderStepped:Connect(function()
	if not script then
		return
	end
	if not settings.esp_holdHotkey then
		return
	end
	if not espEnabled and UserInputService:IsKeyDown(settings.esp_Hotkey) then
		toggle_Esp()
		espEnabled = true
	elseif espEnabled and not UserInputService:IsKeyDown(settings.esp_Hotkey) then
		toggle_Esp(true)
	end
end)
AIMBOT_RbxScriptSignal = RunService.RenderStepped:Connect(function()
	if aimbotEnabled then
		targetCamera()
	end
end)
KEYS_RbxScriptSignal = UserInputService.InputBegan:Connect(function(inputObj, gpe)	
	local key = inputObj.KeyCode
	if (key == settings.esp_Hotkey) or (key == settings.aimbot_Hotkey)  or (key == settings.commandbar_Hotkey) then
		if key == settings.commandbar_Hotkey and not gpe then
			Box:CaptureFocus()
		end
		if key == settings.aimbot_Hotkey  then
			toggle_Aimbot()
		end
		if key == settings.esp_Hotkey then
			if espEnabled then
				toggle_Esp(true)
			else
				toggle_Esp()
				espEnabled = true
			end
		end
	end	
end)
AIMBOTLOCK_RbxScriptSignal = Mouse.Button2Down:Connect(function()

	local t = Mouse.Target
	if not t then
		return
	end
	if not Players:GetPlayerFromCharacter(t.Parent) then
		local character = getCharacterFromPart(t)
		if not character then
			return
		else
			t = character:FindFirstChild("HumanoidRootPart")
			if not t then
				return
			end
		end
	end
	
	if not aimbotEnabled and settings.aimbot_clickToLock then
		local success = clickToTarget(t, settings.aimbot_clickToLockDistanceOverride)
		if success then
			currentLock = targetPlayer
			aimbotEnabled = true
			aimbotText.TextColor3 = Color3.fromRGB(0, 255, 0)
			print "Aimbot Enabled; target player set. [click to lock method]"
		end
	elseif aimbotEnabled then
		if currentLock and currentLock.Character and t:IsDescendantOf(currentLock.Character) then
			if targetPlayer ~= currentLock then
				targetPlayer = currentLock
			elseif targetPlayer == currentLock then
				targetPlayer, currentLock = nil, nil
				aimbotEnabled = false
				aimbotText.TextColor3 = Color3.fromRGB(48, 48, 48)
				print "Aimbot disabled; target player removed. [click to lock method]"
			end
		end
	end
	
end)
Box.FocusLost:Connect(on_FocusLost)
Box.Focused:Connect(function()
	Box.Font = Enum.Font.SourceSans
	Box.TextTransparency = 0
end)

ESPOBJF.Parent = CoreGui
commandBar.Parent = CoreGui
end)

push.Name = "push"
push.Parent = Scripts
push.BackgroundColor3 = Color3.new(0, 0, 0)
push.BackgroundTransparency = 0.5
push.Position = UDim2.new(0, 0, 0, 1457)
push.Size = UDim2.new(0, 200, 0, 50)
push.Font = Enum.Font.SourceSans
push.FontSize = Enum.FontSize.Size14
push.Text = "Push"
push.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
push.TextSize = 14
push.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton.Text = "Push"
end)

LimbMerger.Name = "push"
LimbMerger.Parent = Scripts
LimbMerger.BackgroundColor3 = Color3.new(0, 0, 0)
LimbMerger.BackgroundTransparency = 0.5
LimbMerger.Position = UDim2.new(0, 0, 0, 1507)
LimbMerger.Size = UDim2.new(0, 200, 0, 50)
LimbMerger.Font = Enum.Font.SourceSans
LimbMerger.FontSize = Enum.FontSize.Size14
LimbMerger.Text = "Limb Merger"
LimbMerger.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
LimbMerger.TextSize = 14
LimbMerger.MouseButton1Down:connect(function()
for i,v in pairs(game.Players:GetChildren()) do
a = Instance.new("Weld", v.Character.Torso)
a.Part0 = game.Players.LocalPlayer.Character.Torso
a.Part1 = game.Players.LocalPlayer.Character.Head
a = Instance.new("Weld", v.Character.Torso)
a.Part0 = game.Players.LocalPlayer.Character.Head
a.Part1 = game.Players.LocalPlayer.Character["Left Leg"]
a = Instance.new("Weld", v.Character.Torso)
a.Part0 = game.Players.LocalPlayer.Character.Torso
a.Part1 = game.Players.LocalPlayer.Character["Right Leg"]
a = Instance.new("Weld", v.Character.Torso)
a.Part0 = game.Players.LocalPlayer.Character.Torso
a.Part1 = game.Players.LocalPlayer.Character["Right Arm"]
a = Instance.new("Weld", v.Character.Torso)
a.Part0 = game.Players.LocalPlayer.Character.Torso
a.Part1 = game.Players.LocalPlayer.Character["Left Arm"]
end
end)

hatspin.Name = "hatspin"
hatspin.Parent = Scripts
hatspin.BackgroundColor3 = Color3.new(0, 0, 0)
hatspin.BackgroundTransparency = 0.5
hatspin.Position = UDim2.new(0, 0, 0, 1557)
hatspin.Size = UDim2.new(0, 200, 0, 50)
hatspin.Font = Enum.Font.SourceSans
hatspin.FontSize = Enum.FontSize.Size14
hatspin.Text = "Hat Spin"
hatspin.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
hatspin.TextSize = 14
hatspin.MouseButton1Down:connect(function()
local obese = game:GetService('Players')
for i,v in pairs(obese.LocalPlayer.Character:GetChildren()) do
if v.ClassName == "Accessory" then
local stg = v.Handle:FindFirstChildOfClass("BodyForce")
if stg == nil then
local a = Instance.new("BodyPosition")
local b = Instance.new("BodyAngularVelocity")
a.Parent = v.Handle
b.Parent = v.Handle
v.Handle.AccessoryWeld:Destroy()
b.AngularVelocity = Vector3.new(0,100,0)
b.MaxTorque = Vector3.new(0,200,0)
a.P = 30000
a.D = 50
game:GetService('RunService').Stepped:connect(function()
a.Position = obese.LocalPlayer.Character.Head.Position
end)
end
end
end
end)

Fling.Name = "Fling"
Fling.Parent = Scripts
Fling.BackgroundColor3 = Color3.new(0, 0, 0)
Fling.BackgroundTransparency = 0.5
Fling.Position = UDim2.new(0, 0, 0, 1607)
Fling.Size = UDim2.new(0, 200, 0, 50)
Fling.Font = Enum.Font.SourceSans
Fling.FontSize = Enum.FontSize.Size14
Fling.Text = "Fling"
Fling.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
Fling.TextSize = 14
Fling.MouseButton1Down:connect(function()
Frame.Visible = true
TextButton.Text = "Fling"
end)

Blackhole.Name = "Blackhole"
Blackhole.Parent = Scripts
Blackhole.BackgroundColor3 = Color3.new(0, 0, 0)
Blackhole.BackgroundTransparency = 0.5
Blackhole.Position = UDim2.new(0, 0, 0, 1657)
Blackhole.Size = UDim2.new(0, 200, 0, 50)
Blackhole.Font = Enum.Font.SourceSans
Blackhole.FontSize = Enum.FontSize.Size14
Blackhole.Text = "BlackHole"
Blackhole.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
Blackhole.TextSize = 14
Blackhole.MouseButton1Down:connect(function()
for i,v in pairs(game.Players:GetChildren()) do
local Target = v.Name
local R_C = Instance.new("BallSocketConstraint")
R_C.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
local hah = Instance.new("Attachment")
hah.Parent = game.Players[Target].Character.HumanoidRootPart
local hah2 = Instance.new("Attachment")
hah2.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
R_C.Attachment0 = hah
R_C.Attachment1 = hah2
R_C.Visible = false
wait(0.1)
end
end)

earraep.Name = "earraep"
earraep.Parent = Scripts
earraep.BackgroundColor3 = Color3.new(0, 0, 0)
earraep.BackgroundTransparency = 0.5
earraep.Position = UDim2.new(0, 0, 0, 1707)
earraep.Size = UDim2.new(0, 200, 0, 50)
earraep.Font = Enum.Font.SourceSans
earraep.FontSize = Enum.FontSize.Size14
earraep.Text = "Ear Rape (Car Crushers 2)"
earraep.TextColor3 = Color3.new(0.454902, 0.454902, 0.454902)
earraep.TextSize = 14
earraep.MouseButton1Down:connect(function()
cockcock = game.Players.LocalPlayer.Name
while wait() do
game.ReplicatedStorage.rE.UpdateSounds:FireServer(1, Workspace.CarCollection[cockcock].Car.Body.VehicleSeat, Workspace.CarCollection[cockcock].Car.Body.Engine.Engine, 50, 10000)
end
end)

game.StarterGui:SetCore("SendNotification", {Title = "FE Script Hub:";Text = "Successfully loaded!";Icon = "rbxassetid://920542878";Duration = 2})
wait(2)
game.StarterGui:SetCore("SendNotification", {Title = "Credits:";Text = "Migas3456#6402";Icon = "rbxassetid://920542878";Duration = 2})