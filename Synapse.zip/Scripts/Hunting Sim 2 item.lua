game:GetService("ReplicatedStorage").Remotes.ClientToServerRemoteEvent:FireServer({ ["packetId"]= 5, ["mobInstanceId"]= v.InstanceId.Value, ["damage"]= 15, ["itemInstanceId"]= "574B9EC9-9B0E-4431-B883-8EA1E59CA7CF", ["itemId"]= 1001 }) -- SlingShot

game:GetService("ReplicatedStorage").Remotes.ClientToServerRemoteEvent:FireServer({ ["packetId"]= 5, ["mobInstanceId"]= v.InstanceId.Value, ["damage"]= 20, ["itemInstanceId"]= "32DCFD66-784A-4A5C-9C80-5773A521F949", ["itemId"]= 1003 }) -- ToyGun

game:GetService("ReplicatedStorage").Remotes.ClientToServerRemoteEvent:FireServer({ ["packetId"]= 5, ["mobInstanceId"]= v.InstanceId.Value, ["damage"]= 132, ["itemInstanceId"]= "57579865-D571-49DB-95C0-C3FB99A5D86F", ["itemId"]= 1006 }) --Bow

game:GetService("ReplicatedStorage").Remotes.ClientToServerRemoteEvent:FireServer({ ["packetId"]= 5, ["mobInstanceId"]= "40f06366-8b4b-4649-8653-c7197091005a", ["damage"]= 325, ["itemInstanceId"]= "A4476EF0-16A1-414E-9FA4-2AE167BCF50B", ["itemId"]= 1008 }) -- Slipper