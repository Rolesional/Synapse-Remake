loadstring(game:HttpGet("https://pastebin.com/raw/5qsgGnxu"))()
