getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Head
pushnumber .5
setfield -2 Transparency
pcall 1 0 0
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Head
getfield -1 face
pushnumber .5
setfield -2 Transparency
pcall 1 0 0
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Torso
pushnumber .5
setfield -2 Transparency
pcall 1 0 0
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Right Arm
pushnumber .5
setfield -2 Transparency
pcall 1 0 0
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Left Arm
pushnumber .5
setfield -2 Transparency
pcall 1 0 0
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Right Leg
pushnumber .5
setfield -2 Transparency
pcall 1 0 0
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Left Leg
pushnumber .5
setfield -2 Transparency
pcall 1 0 0
settop 0