getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Head
getglobal Vector3
getfield -1 new
pushnumber 6
pushnumber 6
pushnumber 6
pcall 3 1 0
setfield -3 Size
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Head
getfield -1 Mesh
getfield -1 Destroy
pushvalue -2
pcall 1 0 0
settop 0