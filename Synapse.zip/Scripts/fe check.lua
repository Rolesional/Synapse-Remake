Check FE
getglobal workspace
getfield -1 FilteringEnabled
getglobal print
pushvalue -2
pcall 1 0 0
emptystack