getglobal game
getfield -1 Workspace
getfield -1 Events
getfield -1 ExpansionPurchase
getfield -1 InvokeServer
pushvalue -2
pushnumber 4
pushnumber 1
pcall 3 1 0