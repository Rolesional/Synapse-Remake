getglobal game
getfield -1 ReplicatedStorage
getfield -1 YourNameHereElement
pushstring ArcYouWantHere
setfield -2 Value
